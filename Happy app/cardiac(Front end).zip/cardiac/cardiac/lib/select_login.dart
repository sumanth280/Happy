import 'package:flutter/material.dart';
import 'doctor/login_doc.dart'; // Import the LoginScreen from the doctor folder
import 'patient/patient_login.dart'; // Import the PatientLoginScreen from the patient folder

class SelectionScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Doctor Section with larger image
            CircleAvatar(
              radius: 78, // Increased by 30% from 60
              backgroundImage: AssetImage('assets/images/doctor.jpg'),
              backgroundColor: Colors.transparent,
            ),
            SizedBox(height: 30),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.black,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
                padding: EdgeInsets.symmetric(horizontal: 40, vertical: 10),
              ),
              onPressed: () {
                // Navigate to LoginScreen when Doctor button is pressed
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => DoctorLoginScreen()),
                );
              },
              child: Text(
                'Doctor',
                style: TextStyle(
                  fontSize: 25,
                  color: Colors.white,
                ),
              ),
            ),

            // Increased space between Doctor and Patient sections
            SizedBox(height: 60), // Increased spacing

            // Patient Section with larger image
            CircleAvatar(
              radius: 78, // Increased by 30% from 60
              backgroundImage: AssetImage('assets/images/patient.jpg'),
              backgroundColor: Colors.transparent,
            ),
            SizedBox(height: 30),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.black,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
                padding: EdgeInsets.symmetric(horizontal: 40, vertical: 10),
              ),
              onPressed: () {
                // Navigate to PatientLoginScreen when Patient button is pressed
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => PatientLoginScreen()),
                );
              },
              child: Text(
                'Patient',
                style: TextStyle(
                  fontSize: 25,
                  color: Colors.white,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
