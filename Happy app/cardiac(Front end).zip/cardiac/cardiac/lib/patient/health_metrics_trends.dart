import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '/api.dart'; // Ensure this file contains `patient_id` and `Healthtrendsurl`

class HealthMetricsTrends extends StatefulWidget {
  @override
  _HealthMetricsTrendsState createState() => _HealthMetricsTrendsState();
}

class _HealthMetricsTrendsState extends State<HealthMetricsTrends> {
  String selectedFilter = 'today'; // Default filter
  String? startDate;
  String? endDate;
  List<dynamic> healthMetrics = [];
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    fetchTrends();
  }

  Future<void> fetchTrends() async {
    setState(() {
      isLoading = true;
    });

    final response = await fetchHealthTrends(
      filter: selectedFilter,
      startDate: startDate,
      endDate: endDate,
    );

    if (response['status'] == true) {
      setState(() {
        healthMetrics = response['data'] is List ? response['data'] : [];
      });
    } else {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(response['message'] ?? 'Failed to fetch data')),
        );
      }
    }

    setState(() {
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          // Dropdown menu
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: DropdownButton<String>(
              value: selectedFilter,
              isExpanded: true,
              items: [
                DropdownMenuItem(value: 'today', child: Text('Today')),
                DropdownMenuItem(value: 'last_week', child: Text('Last Week')),
                DropdownMenuItem(value: 'date_range', child: Text('Custom Date Range')),
              ],
              onChanged: (value) async {
                if (value == 'date_range') {
                  // Logic to handle custom date selection
                  final pickedDates = await showDateRangePicker(
                    context: context,
                    firstDate: DateTime(2020),
                    lastDate: DateTime.now(),
                  );
                  if (pickedDates != null) {
                    startDate = pickedDates.start.toIso8601String();
                    endDate = pickedDates.end.toIso8601String();
                  }
                }
                setState(() {
                  selectedFilter = value!;
                });
                await fetchTrends();
              },
            ),
          ),

          // Display health metrics or loading indicator
          isLoading
              ? Center(child: CircularProgressIndicator())
              : Expanded(
                  child: healthMetrics.isEmpty
                      ? Center(
                          child: Text(
                            'No data available',
                            style: TextStyle(fontSize: 16, color: Colors.grey),
                          ),
                        )
                      : ListView.builder(
                          itemCount: healthMetrics.length,
                          itemBuilder: (context, index) {
                            final metric = healthMetrics[index];
                            return Padding(
                              padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
                              child: Container(
                                decoration: BoxDecoration(
                                  color: Colors.lightGreen.shade50,
                                  borderRadius: BorderRadius.circular(12.0),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black12,
                                      blurRadius: 6.0,
                                      offset: Offset(0, 3),
                                    ),
                                  ],
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(16.0),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Text(
                                            'Date & Time:',
                                            style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              color: Colors.green.shade700,
                                            ),
                                          ),
                                          Text(
                                            metric['time_stamp'],
                                            style: TextStyle(
                                              color: Colors.black54,
                                            ),
                                          ),
                                        ],
                                      ),
                                      SizedBox(height: 8.0),
                                      Divider(),
                                      Wrap(
                                        spacing: 10,
                                        runSpacing: 8,
                                        children: [
                                          _buildMetricChip('Pulse Rate', '${metric['pulse_rate']} bpm'),
                                          _buildMetricChip('SPO2', '${metric['spo2']}%'),
                                          _buildMetricChip('BP(SBP/DBP)', '${metric['bp']} mm/Hg'),
                                          _buildMetricChip('Weight', '${metric['weight']} kg'),
                                          _buildMetricChip('Activity', '${metric['activity']} km'),
                                          _buildMetricChip('Fluid Intake', '${metric['fluid_intake']} ml'),
                                          _buildMetricChip('Salt Intake', '${metric['salt_intake']} mg'),
                                          _buildMetricChip('Urine Output', '${metric['urine_output'] ?? 'N/A'} ml'),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                ),
        ],
      ),
    );
  }

  Widget _buildMetricChip(String label, String value) {
    return Chip(
      label: Text('$label: $value',
          style: TextStyle(
            fontSize: 14,
            color: Colors.black87,
          )),
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8.0),
        side: BorderSide(color: Colors.green.shade300),
      ),
    );
  }
}

Future<Map<String, dynamic>> fetchHealthTrends({
  required String filter,
  String? startDate,
  String? endDate,
}) async {
  try {
    if (patient_id == null || patient_id.isEmpty) {
      throw Exception("Patient ID is not available.");
    }

    // Prepare the body of the request
    final Map<String, String> body = {
      'patient_id': patient_id,
      'filter': filter,
    };

    // Include dates if `filter` is 'date_range'
    if (filter == 'date_range' && startDate != null && endDate != null) {
      body['start_date'] = startDate.split('T').first; // Ensure proper format
      body['end_date'] = endDate.split('T').first;    // Ensure proper format
    }

    final response = await http.post(
      Uri.parse(Healthtrendsurl),
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: body,
    );

    if (response.statusCode == 200) {
      final jsonResponse = json.decode(response.body);
      if (jsonResponse['status'] == true) {
        return {
          'status': true,
          'data': jsonResponse['data'],
        };
      } else {
        return {
          'status': false,
          'message': jsonResponse['message'] ?? 'Unknown error occurred.',
        };
      }
    } else {
      throw Exception('Failed to fetch data. Status Code: ${response.statusCode}');
    }
  } catch (e) {
    return {
      'status': false,
      'message': e.toString(),
    };
  }
}
