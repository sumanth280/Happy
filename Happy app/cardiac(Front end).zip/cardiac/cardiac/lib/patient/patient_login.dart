import '/provider/login.dart';
import 'package:flutter/material.dart';
import '/patient/patient_login.dart'; // Import login function
import 'home.dart'; // Import home screen
import 'patient_signup.dart'; // Import the correct sign-up screen file
import '/api.dart';
class PatientLoginScreen extends StatefulWidget {
  @override
  _PatientLoginScreenState createState() => _PatientLoginScreenState();
}

class _PatientLoginScreenState extends State<PatientLoginScreen> {
  bool _isPasswordVisible = false; // Password visibility state
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  bool _isLoading = false;

  
  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Login Failed"),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: Text("OK"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(height: 40),
              Text(
                'Welcome',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w500),
              ),
              SizedBox(height: 10),
              Text(
                'Cardio care - Patient',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 20),

              // Logo Container with Circular Background
              Container(
                width: 160,
                height: 160,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white,
                ),
                child: Center(
                  child: Image.asset(
                    'assets/images/logo.jpg',
                    width: 110,
                    height: 110,
                  ),
                ),
              ),
              SizedBox(height: 20),

              TextField(
                controller: _phoneController,
                decoration: InputDecoration(
                  labelText: 'Username',
                  hintText: 'Enter your Mobile Number',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 20),
              
              // Password TextField with visibility toggle
              TextField(
                controller: _passwordController,
                obscureText: !_isPasswordVisible,
                decoration: InputDecoration(
                  labelText: 'Password',
                  hintText: 'Enter your Password',
                  border: OutlineInputBorder(),
                  suffixIcon: IconButton(
                    icon: Icon(
                      _isPasswordVisible ? Icons.visibility : Icons.visibility_off,
                    ),
                    onPressed: () {
                      setState(() {
                        _isPasswordVisible = !_isPasswordVisible;
                      });
                    },
                  ),
                ),
              ),
              SizedBox(height: 10),
              
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                  onPressed: () {
                    // Forgot password functionality
                  },
                  child: Text('Forget Password'),
                ),
              ),
              SizedBox(height: 20),
              
              _isLoading
                  ? CircularProgressIndicator() // Show loading spinner
                  : ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.black,
                        padding: EdgeInsets.symmetric(horizontal: 80, vertical: 15),
                      ),
                      onPressed: () {
                        // Call login function with entered credentials
                        final phoneNumber = _phoneController.text;
                        final password = _passwordController.text;

                        if (phoneNumber.isNotEmpty && password.isNotEmpty) {
                          login(phoneNumber, password,context);
                        } else {
                          _showErrorDialog("Please enter both username and password.");
                        }
                      },
                      child: Text('Sign In'),
                    ),
              SizedBox(height: 20),
              
              TextButton(
                onPressed: () {
                  // Navigate to Sign Up page in patient_signup.dart
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => CreateAccountScreen()), // Use correct class name for Sign Up screen
                  );
                },
                child: Text("Don't have an account? Sign Up"),
              ),
              SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }
}
