import '../provider/symptom_monitoring.dart';
import 'package:flutter/material.dart';
import 'symptom_trends.dart'; // Ensure this import is correct
import '../api.dart'; // Importing api.dart to fetch patient_id

class SymptomMonitoring extends StatefulWidget {
  @override
  _SymptomMonitoringState createState() => _SymptomMonitoringState();
}

class _SymptomMonitoringState extends State<SymptomMonitoring> {
  Map<String, bool?> symptoms = {
    'Shortness of Breath': null,
    'Cough': null,
    'Fatigue/Weakness': null,
    'Chest Pain': null,
    'Palpitations': null,
    'Abdomen Discomfort': null,
    'Confusion': null,
    'Weight Gain/Pedal Edema': null,
    'Sleep Difficulty': null,
  };

  String? shortnessOfBreathDetail;
  String? coughDetail;

  Future<void> _submitSymptomData() async {
    String whileWorking = shortnessOfBreathDetail == 'While Working' ? 'yes' : 'no';
    String whileRest = shortnessOfBreathDetail == 'While at Rest' ? 'yes' : 'no';
    String occasional = coughDetail == 'Occasional' ? 'yes' : 'no';
    String frequent = coughDetail == 'Frequent' ? 'yes' : 'no';

    String patientId = patient_id; // Fetching patient_id from api.dart

    Map<String, dynamic> response = await submitSymptomMonitoring(
      patientId: patientId,
      shortnessOfBreath: symptoms['Shortness of Breath'] == true ? 'yes' : 'no',
      cough: symptoms['Cough'] == true ? 'yes' : 'no',
      whileWorking: whileWorking,
      whileRest: whileRest,
      occasional: occasional,
      frequent: frequent,
      fatigueWeakness: symptoms['Fatigue/Weakness'] == true ? 'yes' : 'no',
      chestPain: symptoms['Chest Pain'] == true ? 'yes' : 'no',
      palpatations: symptoms['Palpitations'] == true ? 'yes' : 'no',
      abdomenDiscomfort: symptoms['Abdomen Discomfort'] == true ? 'yes' : 'no',
      confusion: symptoms['Confusion'] == true ? 'yes' : 'no',
      weightGain: symptoms['Weight Gain/Pedal Edema'] == true ? 'yes' : 'no',
      sleepDifficulty: symptoms['Sleep Difficulty'] == true ? 'yes' : 'no',
    );

    if (response['status'] == 'true') {
      _showSuccessDialog(response['message']);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to save symptoms: ${response['message']}')),
      );
    }
  }

  void _showSuccessDialog(String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Success"),
          content: Text(message),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text("OK"),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 0,
          title: Text('Symptom Monitoring', style: TextStyle(color: Colors.black)),
          centerTitle: true,
          bottom: TabBar(
            labelColor: Colors.black,
            indicatorColor: Colors.lightGreen,
            tabs: [
              Tab(text: 'Today'),
              Tab(text: 'Trends'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _buildTodayView(),
            SymptomTrends(),
          ],
        ),
      ),
    );
  }

  Widget _buildTodayView() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Symptoms',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              Spacer(),
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text("Yes", style: TextStyle(color: Colors.red, fontSize: 16)),
                  SizedBox(width: 40),
                  Text("No    ", style: TextStyle(color: Colors.green, fontSize: 16)),
                ],
              ),
            ],
          ),
          Expanded(
            child: ListView(
              children: symptoms.keys.map((symptom) {
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildSymptomRow(symptom),
                    if (symptom == 'Shortness of Breath' && symptoms[symptom] == true)
                      _buildFollowUpQuestion(
                        'While working or while at rest?',
                        ['While Working', 'While at Rest'],
                        (value) {
                          setState(() {
                            shortnessOfBreathDetail = value;
                          });
                        },
                        selectedOption: shortnessOfBreathDetail,
                      ),
                    if (symptom == 'Cough' && symptoms[symptom] == true)
                      _buildFollowUpQuestion(
                        'Occasional or frequent?',
                        ['Occasional', 'Frequent'],
                        (value) {
                          setState(() {
                            coughDetail = value;
                          });
                        },
                        selectedOption: coughDetail,
                      ),
                  ],
                );
              }).toList(),
            ),
          ),
          SizedBox(height: 16.0),
          ElevatedButton(
            onPressed: _submitSymptomData,
            child: Text('Save'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.black,
              padding: EdgeInsets.symmetric(vertical: 16.0, horizontal: 64.0),
            ),
          ),
          SizedBox(height: 24.0),
        ],
      ),
    );
  }

  Widget _buildSymptomRow(String symptom) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
      margin: EdgeInsets.symmetric(vertical: 8.0),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey.shade300),
        borderRadius: BorderRadius.circular(8.0),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(symptom, style: TextStyle(fontSize: 16)),
          Row(
            children: [
              IconButton(
                icon: symptoms[symptom] == true
                    ? Icon(Icons.check_circle, color: Colors.red)
                    : Icon(Icons.radio_button_unchecked, color: Colors.grey),
                onPressed: () {
                  setState(() {
                    symptoms[symptom] = true;
                    if (symptom == 'Shortness of Breath') shortnessOfBreathDetail = null;
                    if (symptom == 'Cough') coughDetail = null;
                  });
                },
              ),
              IconButton(
                icon: symptoms[symptom] == false
                    ? Icon(Icons.check_circle, color: Colors.green)
                    : Icon(Icons.radio_button_unchecked, color: Colors.grey),
                onPressed: () {
                  setState(() {
                    symptoms[symptom] = false;
                    if (symptom == 'Shortness of Breath') shortnessOfBreathDetail = null;
                    if (symptom == 'Cough') coughDetail = null;
                  });
                },
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildFollowUpQuestion(
    String question,
    List<String> options,
    Function(String?) onChanged, {
    String? selectedOption,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(question, style: TextStyle(fontSize: 16)),
          SizedBox(height: 8.0),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: options.map((option) {
              return Row(
                children: [
                  Radio<String>(
                    value: option,
                    groupValue: selectedOption,
                    onChanged: onChanged,
                  ),
                  Text(option),
                  SizedBox(width: 10),
                ],
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}
