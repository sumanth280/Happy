import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '/api.dart';
import 'health_metrics_trends.dart';

class HealthMetricsPage extends StatefulWidget {
  @override
  _HealthMetricsPageState createState() => _HealthMetricsPageState();
}

class _HealthMetricsPageState extends State<HealthMetricsPage> {
  bool isLoading = false;
  Map<String, String> healthMetrics = {
    'pulse_rate': '',
    'spo2': '',
    'bp': '',
    'weight': '',
    'activity': '',
    'fluid_intake': '',
    'salt_intake': '',
    'urine_output': '',
  };

  // TextEditingControllers for each field
  TextEditingController pulseRateController = TextEditingController();
  TextEditingController spo2Controller = TextEditingController();
  TextEditingController bpController = TextEditingController();
  TextEditingController weightController = TextEditingController();
  TextEditingController activityController = TextEditingController();
  TextEditingController fluidIntakeController = TextEditingController();
  TextEditingController saltIntakeController = TextEditingController();
  TextEditingController urineOutputController = TextEditingController();

  // Helper function to validate fields
  bool validateFields() {
    for (var key in healthMetrics.keys) {
      if (healthMetrics[key]!.isEmpty) {
        showMessage("Missing fields: $key");
        return false;
      }
    }
    return true;
  }

  // Function to save health metrics data
  Future<void> saveHealthMetrics() async {
    if (!validateFields()) return;

    setState(() {
      isLoading = true;
    });

    try {
      String patientId = patient_id; // Ensure patient_id is fetched correctly

      final data = await submitHealthMetrics(
        patientId: patientId,
        pulseRate: healthMetrics['pulse_rate']!,
        spo2: healthMetrics['spo2']!,
        bp: healthMetrics['bp']!,
        weight: healthMetrics['weight']!,
        activity: healthMetrics['activity']!,
        fluidIntake: healthMetrics['fluid_intake']!,
        saltIntake: healthMetrics['salt_intake']!,
        urineInput: healthMetrics['urine_output']!,
      );

      if (data['status'] == 'true') {
        showMessage('Data saved successfully', shouldNavigateBack: true);
      } else {
        showMessage('${data['message']}');
      }
    } catch (e) {
      showMessage('Error: $e');
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  // API Call to submit health metrics
  Future<Map<String, dynamic>> submitHealthMetrics({
    required String pulseRate,
    required String spo2,
    required String bp,
    required String weight,
    required String activity,
    required String fluidIntake,
    required String saltIntake,
    required String urineInput,
    required String patientId,
  }) async {
    final Map<String, dynamic> data = {
      'patient_id': patientId,
      'pulse_rate': pulseRate,
      'spo2': spo2,
      'bp': bp,
      'weight': weight,
      'activity': activity,
      'fluid_intake': fluidIntake,
      'salt_intake': saltIntake,
      'urine_output': urineInput,
    };

    try {
      final response = await http.post(
        Uri.parse(Health_metricsurl),
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: data,
      );

      if (response.statusCode == 200) {
        final responseData = json.decode(response.body);
        return responseData;
      } else {
        return {
          'status': 'false',
          'message': 'Server returned status code ${response.statusCode}',
        };
      }
    } catch (error) {
      return {
        'status': 'false',
        'message': 'An error occurred: $error',
      };
    }
  }

  // Function to show a popup message
  void showMessage(String message, {bool shouldNavigateBack = false}) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Message"),
          content: Text(message),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close the popup
                if (shouldNavigateBack) {
                  Navigator.of(context).pop(); // Navigate back to the previous screen
                }
              },
              child: Text("OK"),
            ),
          ],
        );
      },
    );
  }

  Widget _buildMetricRow(String metric, String hintText, String unit, TextEditingController controller) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
      margin: EdgeInsets.symmetric(vertical: 8.0),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey.shade300),
        borderRadius: BorderRadius.circular(8.0),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            metric,
            style: TextStyle(fontSize: 16),
          ),
          Container(
            width: 150.0, // Adjust width as needed
            child: TextField(
              controller: controller,
              keyboardType: TextInputType.text,
              decoration: InputDecoration(
                hintText: hintText,
                suffixText: unit, // Add unit as suffix
                suffixStyle: TextStyle(color: Colors.grey, fontSize: 14),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8.0),
                  borderSide: BorderSide(color: Colors.grey.shade300),
                ),
                contentPadding: EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
              ),
              onChanged: (newValue) {
                setState(() {
                  healthMetrics[metric.toLowerCase().replaceAll(' ', '_')] = newValue;
                });
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTodayView() {
    return isLoading
        ? Center(child: CircularProgressIndicator())
        : ListView(
            padding: EdgeInsets.symmetric(horizontal: 16.0),
            children: [
              _buildMetricRow('Pulse Rate', '', 'bpm', pulseRateController),
              _buildMetricRow('SPO2', '', '%', spo2Controller),
              _buildMetricRow('BP', '', 'mm/hg', bpController),
              _buildMetricRow('Weight', '', 'kg', weightController),
              _buildMetricRow('Activity', '', 'km', activityController),
              _buildMetricRow('Fluid Intake', '', 'ml/L', fluidIntakeController),
              _buildMetricRow('Salt Intake', '', 'mg', saltIntakeController),
              _buildMetricRow('Urine Output', '', 'ml', urineOutputController),
              SizedBox(height: 16.0),
              ElevatedButton(
                onPressed: saveHealthMetrics,
                child: Text('Save'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.black,
                  padding: EdgeInsets.symmetric(vertical: 16.0, horizontal: 64.0),
                ),
              ),
              SizedBox(height: 24.0),
            ],
          );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 0,
          title: Text('Health Metrics', style: TextStyle(color: Colors.black)),
          centerTitle: true,
          bottom: TabBar(
            labelColor: Colors.black,
            indicatorColor: Colors.lightGreen,
            tabs: [
              Tab(text: 'Today'),
              Tab(text: 'Trends'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _buildTodayView(),
            HealthMetricsTrends(),
          ],
        ),
      ),
    );
  }
}
