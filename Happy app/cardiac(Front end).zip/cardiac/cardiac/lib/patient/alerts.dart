import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '/api.dart'; // Ensure Createalerturl, Alertsshowurl, Markasreadurl, and patient_id are defined here

class AlertsScreen extends StatefulWidget {
  @override
  _AlertsScreenState createState() => _AlertsScreenState();
}

class _AlertsScreenState extends State<AlertsScreen> {
  List<dynamic> alerts = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _initializeAlerts();
  }

  // Initialize alerts by calling CreateAlert API and then fetching alerts
  Future<void> _initializeAlerts() async {
    await _createAlert();
    await _fetchAlerts();
  }

  // Call Createalerturl API
  Future<void> _createAlert() async {
    final uri = Uri.parse(Createalerturl);
    final patientId = patient_id; // Fetch from api.dart

    try {
      await http.post(uri, body: {'patient_id': patientId});
    } catch (e) {
      print('Error creating alerts: $e');
    }
  }

  // Call Alertsshowurl API to fetch alerts
  Future<void> _fetchAlerts() async {
    setState(() {
      isLoading = true;
    });

    final uri = Uri.parse(Alertsshowurl);
    final patientId = patient_id; // Fetch from api.dart

    try {
      final response = await http.post(uri, body: {'patient_id': patientId});

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status'] == true) {
          setState(() {
            alerts = data['data'];
          });
        } else {
          setState(() {
            alerts = [];
          });
        }
      }
    } catch (e) {
      print('Error fetching alerts: $e');
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  // Call Markasreadurl API to mark an alert as read
  Future<void> _markAsRead(String notificationId) async {
    final uri = Uri.parse(Markasreadurl);
    final patientId = patient_id; // Fetch from api.dart

    try {
      final response = await http.post(uri, body: {
        'patient_id': patientId,
        'notification_id': notificationId,
      });

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status'] == true) {
          // Refresh alerts after marking as read
          await _fetchAlerts();
        } else {
          print('Error marking alert as read: ${data['message']}');
        }
      }
    } catch (e) {
      print('Error marking alert as read: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Alerts',
          style: TextStyle(color: Colors.black),
        ),
        centerTitle: true,
        backgroundColor: Colors.white, // AppBar color set to white
        iconTheme: IconThemeData(color: Colors.black), // Ensure icons remain visible
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : alerts.isEmpty
              ? Center(
                  child: Text(
                    'No alerts available',
                    style: TextStyle(fontSize: 16, color: Colors.grey),
                  ),
                )
              : ListView.builder(
                  itemCount: alerts.length,
                  itemBuilder: (context, index) {
                    final alert = alerts[index];
                    return Card(
                      color: Colors.white, // Card background color set to white
                      margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              alert['medicine_name'] ?? 'Unknown Medicine',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.teal,
                              ),
                            ),
                            SizedBox(height: 8),
                            Text(
                              'Time: ${alert['time_med'] ?? 'Unknown Time'}',
                              style: TextStyle(fontSize: 14, color: Colors.black54),
                            ),
                            SizedBox(height: 8),
                            Text(
                              'Message: Time to take medicine!',
                              style: TextStyle(fontSize: 14, color: Colors.black87),
                            ),
                            SizedBox(height: 16),
                            Align(
                              alignment: Alignment.centerRight,
                              child: ElevatedButton(
                                onPressed: () async {
                                  await _markAsRead(alert['notification_id']);
                                },
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.black, // Button color set to black
                                ),
                                child: Text('Mark as Read'),
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}
