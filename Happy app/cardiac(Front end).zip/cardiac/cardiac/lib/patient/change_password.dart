import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '/api.dart';

class ChangePasswordScreen extends StatefulWidget {
  @override
  _ChangePasswordScreenState createState() => _ChangePasswordScreenState();
}

class _ChangePasswordScreenState extends State<ChangePasswordScreen> {
  bool isLoading = false;
  final _formKey = GlobalKey<FormState>();
  final TextEditingController currentPasswordController = TextEditingController();
  final TextEditingController newPasswordController = TextEditingController();
  final TextEditingController confirmPasswordController = TextEditingController();

  Future<void> changePassword(String patientId, String currentPassword, String newPassword) async {
    final url = Uri.parse(Changepasswordurl);

    setState(() {
      isLoading = true;
    });

    try {
      final response = await http.post(
        url,
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: {
          "patient_id": patientId,
          "password": currentPassword,
          "confirm_password": newPassword,
        },
      );

      final data = json.decode(response.body);
      setState(() {
        isLoading = false;
      });

      if (data['status'] == true) {
        // Show success dialog and navigate back on "OK"
        showMessageDialog('Success', 'Password changed successfully!', true);
      } else if (data['message'] == 'Current password is incorrect') { 
        // Display custom message for password mismatch
        showMessageDialog('Error', 'Current password does not match with existing password.', false);
      } else {
        // Show error dialog with the provided message
        showMessageDialog('Error', data['message'] ?? 'Failed to change password.', false);
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      showMessageDialog('Error', 'An error occurred: $e', false);
    }
  }

  void showMessageDialog(String title, String message, bool isSuccess) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(title),
          content: Text(message),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                if (isSuccess) {
                  Navigator.of(context).pop(); // Navigate back on success
                }
              },
              child: Text('OK'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF7F7F7),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: IconThemeData(color: Colors.black),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(height: 20),
              Icon(
                Icons.lock,
                size: 100,
                color: Colors.grey.shade800,
              ),
              SizedBox(height: 20),
              Text(
                'Change Password',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 10),
              Text(
                'Please change your password',
                style: TextStyle(fontSize: 16, color: Colors.grey),
              ),
              SizedBox(height: 30),
              Form(
                key: _formKey,
                child: Column(
                  children: [
                    _buildPasswordField('Current Password', currentPasswordController),
                    SizedBox(height: 16),
                    _buildPasswordField('New Password', newPasswordController),
                    SizedBox(height: 16),
                    _buildPasswordField('Confirm Password', confirmPasswordController),
                  ],
                ),
              ),
              SizedBox(height: 30),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    String patientId = patient_id; // Replace with dynamic patient_id from api.dart
                    String currentPassword = currentPasswordController.text;
                    String newPassword = confirmPasswordController.text;

                    if (newPassword != confirmPasswordController.text) {
                      // Show dialog for password mismatch
                      showMessageDialog('Error', 'New password and confirm password do not match.', false);
                    } else {
                      changePassword(patientId, currentPassword, newPassword);
                    }
                  }
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.black,
                  minimumSize: Size(double.infinity, 50),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: isLoading
                    ? CircularProgressIndicator(color: Colors.white)
                    : Text('Submit', style: TextStyle(fontSize: 16)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPasswordField(String label, TextEditingController controller) {
    return TextFormField(
      controller: controller,
      obscureText: true,
      decoration: InputDecoration(
        labelText: label,
        hintText: 'Enter your $label',
        prefixIcon: Icon(Icons.lock),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
        ),
      ),
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Please enter your $label';
        }
        if (label == 'Confirm Password' && value != newPasswordController.text) {
          // Show dialog for password mismatch in the confirmation field
          showMessageDialog('Error', 'current Password and confirm password do not match', false);
          return ''; // Return empty string so validation fails without returning the normal error message
        }
        return null;
      },
    );
  }
}
