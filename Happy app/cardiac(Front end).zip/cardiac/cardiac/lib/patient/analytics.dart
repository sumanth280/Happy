import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '/api.dart'; // Import for Analyticsurl and patient_id
import 'notification.dart'; // Import the notifications screen
import 'add_notification.dart'; // Import the RemainderScreen for reminder functionality

class CurrentDosageScreen extends StatefulWidget {
  @override
  _CurrentDosageScreenState createState() => _CurrentDosageScreenState();
}

class _CurrentDosageScreenState extends State<CurrentDosageScreen> {
  bool _hasShownReminderPopup = false; // Track popup status

  // Function to fetch medicines using patient_id from api.dart
  Future<Map<String, dynamic>> fetchMedicines() async {
    final url = Uri.parse(Analyticsurl); // Use Analyticsurl from api.dart

    try {
      // Send POST request with patient_id from api.dart
      final response = await http.post(
        url,
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: {
          "patient_id": patient_id, // Use the patient_id directly from api.dart
        },
      );

      // Check for success response code (200)
      if (response.statusCode == 200) {
        // Decode the JSON response
        final data = json.decode(response.body);

        // Check status in the response
        if (data['status'] == true) {
          // Medicines found, return the data
          return {
            'success': true,
            'message': data['message'],
            'medicines': data['medicines'], // List of medicines
          };
        } else {
          // No medicines found or error in fetching
          return {
            'success': false,
            'message': data['message'],
          };
        }
      } else {
        // Handle other status codes
        return {
          'success': false,
          'message': 'Error: ${response.statusCode}',
        };
      }
    } catch (e) {
      // Handle any errors (e.g., network errors)
      return {
        'success': false,
        'message': 'An error occurred: $e',
      };
    }
  }

  void _showReminderPopup(BuildContext context, String medicineName) {
    // Set the flag to false before showing the popup
    setState(() {
      _hasShownReminderPopup = false;
    });

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Set Reminder'),
          content: Text('Would you like to set a reminder for this medicine?'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => RemainderScreen(
                      medicineName: medicineName,
                    ),
                  ),
                );
              },
              child: Text('Set Reminder'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Current Medication', style: TextStyle(color: Colors.black)),
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
        automaticallyImplyLeading: false, // Hides the default back button
        actions: [
          IconButton(
            icon: Icon(Icons.notifications, color: Colors.black),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => NotificationsScreen()),
              );
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: FutureBuilder<Map<String, dynamic>>(
          future: fetchMedicines(), // Call the fetchMedicines function
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return Center(child: CircularProgressIndicator());
            } else if (snapshot.hasError) {
              return Center(
                child: Text('Error: ${snapshot.error}', style: TextStyle(fontSize: 18, color: Colors.red)),
              );
            } else if (!snapshot.hasData || !snapshot.data!['success']) {
              return Center(
                child: Text(
                  snapshot.data?['message'] ?? 'No current dosage data available.',
                  style: TextStyle(fontSize: 18, color: Colors.grey),
                ),
              );
            } else {
              final medicines = List<Map<String, dynamic>>.from(snapshot.data!['medicines']);
              return ListView.builder(
                itemCount: medicines.length,
                itemBuilder: (context, index) {
                  final medicine = medicines[index];
                  return Container(
                    margin: EdgeInsets.symmetric(vertical: 8.0), // Space between items
                    decoration: BoxDecoration(
                      color: Colors.white, // White background
                      borderRadius: BorderRadius.circular(10), // Rounded corners
                      border: Border.all(color: Colors.grey, width: 1), // Border around the item
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // First Line: Medicine name, Days left, and Three dots button
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              // Move medicine name a little to the right
                              Container(
                                margin: EdgeInsets.only(left: 16.0),
                                child: Text(
                                  medicine['medicine_name'],
                                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                                ),
                              ),
                              Row(
                                children: [
                                  Text(
                                    '${medicine['days_left']} days left',
                                    style: TextStyle(color: Colors.grey, fontSize: 16),
                                  ),
                                  IconButton(
                                    icon: Icon(Icons.more_vert),
                                    onPressed: () {
                                      _showReminderPopup(context, medicine['medicine_name']);
                                    },
                                  ),
                                ],
                              ),
                            ],
                          ),
                          // Second Line: Checkboxes for morning, afternoon, and night
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              Row(
                                children: [
                                  Transform.scale(
                                    scale: 0.7, // Make checkbox smaller
                                    child: Checkbox(
                                      shape: CircleBorder(), // Round shape for the checkbox
                                      value: medicine['morning'] == 'yes',
                                      onChanged: (bool? value) {},
                                      activeColor: Colors.green, // Green tick color
                                    ),
                                  ),
                                  Text('Morning', style: TextStyle(fontSize: 16)),
                                ],
                              ),
                              Row(
                                children: [
                                  Transform.scale(
                                    scale: 0.7, // Make checkbox smaller
                                    child: Checkbox(
                                      shape: CircleBorder(), // Round shape for the checkbox
                                      value: medicine['afternoon'] == 'yes',
                                      onChanged: (bool? value) {},
                                      activeColor: Colors.green, // Green tick color
                                    ),
                                  ),
                                  Text('Afternoon', style: TextStyle(fontSize: 16)),
                                ],
                              ),
                              Row(
                                children: [
                                  Transform.scale(
                                    scale: 0.7, // Make checkbox smaller
                                    child: Checkbox(
                                      shape: CircleBorder(), // Round shape for the checkbox
                                      value: medicine['night'] == 'yes',
                                      onChanged: (bool? value) {},
                                      activeColor: Colors.green, // Green tick color
                                    ),
                                  ),
                                  Text('Night', style: TextStyle(fontSize: 16)),
                                ],
                              ),
                            ],
                          ),
                          // Third Line: Checkboxes for before food and after food
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              Row(
                                children: [
                                  Transform.scale(
                                    scale: 0.7, // Make checkbox smaller
                                    child: Checkbox(
                                      shape: CircleBorder(), // Round shape for the checkbox
                                      value: medicine['before_food'] == 'yes',
                                      onChanged: (bool? value) {},
                                      activeColor: Colors.green, // Green tick color
                                    ),
                                  ),
                                  Text('Before Food', style: TextStyle(fontSize: 16)),
                                ],
                              ),
                              Row(
                                children: [
                                  Transform.scale(
                                    scale: 0.7, // Make checkbox smaller
                                    child: Checkbox(
                                      shape: CircleBorder(), // Round shape for the checkbox
                                      value: medicine['after_food'] == 'yes',
                                      onChanged: (bool? value) {},
                                      activeColor: Colors.green, // Green tick color
                                    ),
                                  ),
                                  Text('After Food', style: TextStyle(fontSize: 16)),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                },
              );
            }
          },
        ),
      ),
    );
  }
}
