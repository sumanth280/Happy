import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'patient_edit_profile.dart';
import 'change_password.dart';
import 'patient_login.dart';
import '/provider/profile_upload.dart';
import '/provider/profile_view.dart';
import '/api.dart'; // Ensure api.dart includes Baseurl, Profileviewurl, and patient_id

class ProfilePage extends StatefulWidget {
  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  String? profileImageUrl;
  String userName = '';
  String userId = '';
  File? _selectedImage;
  final ImagePicker _picker = ImagePicker();
  int _emojiClickCount = 0; // Counter for emoji clicks

  @override
  void initState() {
    super.initState();
    _loadPatientProfile(); // Fetch profile when the page is loaded
  }

  // Pick image from gallery
  Future<void> _pickImage() async {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Allow Media Access"),
          content: Text("This app needs access to your gallery to upload a profile picture."),
          actions: [
            TextButton(
              onPressed: () async {
                Navigator.pop(context); // Close the dialog
                final pickedFile = await _picker.pickImage(source: ImageSource.gallery);
                if (pickedFile != null) {
                  setState(() {
                    _selectedImage = File(pickedFile.path);
                  });
                  await _uploadProfilePicture(); // Call the upload API after image is selected
                }
              },
              child: Text("Allow"),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(context); // Close the dialog without action
              },
              child: Text("Don't Allow"),
            ),
          ],
        );
      },
    );
  }

  // Upload selected image
  Future<void> _uploadProfilePicture() async {
    if (_selectedImage == null) return;

    final patientId = patient_id; // Fetch patient_id directly from api.dart

    // Call the upload API
    final response = await ProfileApi.uploadProfilePicture(
      patient_id: patientId,
      profilePicture: _selectedImage!,
    );

    if (response['status'] == true) {
      setState(() {
        profileImageUrl = '${response['profile_pic']}?v=${DateTime.now().millisecondsSinceEpoch}';
        // Add a cache-busting parameter to the URL to force reload
      });

      // Show dialog to confirm upload
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text("Success"),
            content: Text("Profile picture uploaded successfully!"),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context); // Close dialog
                  _loadPatientProfile(); // Reload profile data to refresh the page
                },
                child: Text("OK"),
              ),
            ],
          );
        },
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to upload profile picture: ${response['message']}')),
      );
    }
  }

  // Fetch patient profile and image URL from DB
  Future<void> _loadPatientProfile() async {
    final patientId = patient_id; // Fetch patient_id directly from api.dart

    // Call the profile view API to fetch the profile data
    final response = await fetchPatientProfile(patientId);

    if (response['status'] == true) {
      setState(() {
        userName = response['name'];
        userId = patientId; // Set userId to patient_id for display

        // Check if profileImageUrl is provided and valid
        profileImageUrl = response['profile_pic'];
        if (profileImageUrl != null && profileImageUrl!.isNotEmpty) {
          // Add cache-busting parameter to the URL
          profileImageUrl = '$Baseurl$profileImageUrl?v=${DateTime.now().millisecondsSinceEpoch}';
        } else {
          // If no image URL is provided, fallback to default image from assets
          profileImageUrl = null;
        }
      });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to load profile: ${response['message']}')),
      );
    }
  }

  // Show popup when emoji is clicked 5 times
  void _showDeveloperPopup() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Developer Mark"),
          content: Text("App developed by - Sumanth Nerella\nHackcode - 2806S"),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context); // Close dialog
              },
              child: Text("OK"),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
  backgroundColor: Colors.white,
  elevation: 0,
  automaticallyImplyLeading: false,
  title: GestureDetector(
    onTap: () {
      setState(() {
        _emojiClickCount++;
        if (_emojiClickCount == 5) {
          _emojiClickCount = 0; // Reset the counter
          _showDeveloperPopup(); // Show the popup
        }
      });
    },
    child: Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          "Profile", // Emoji
          style: TextStyle(fontSize: 24),
        ),
        SizedBox(width: 8), // Add some spacing between the emoji and text
        Text(
          '🙂',
          style: TextStyle(color: Colors.black, fontSize: 20),
        ),
      ],
    ),
  ),
  centerTitle: true,
),

      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(height: 30),
            Stack(
              alignment: Alignment.bottomRight,
              children: [
                // Show either the fetched image URL or default image
                CircleAvatar(
                  radius: 65,
                  backgroundImage: profileImageUrl != null && profileImageUrl!.isNotEmpty
                      ? NetworkImage(profileImageUrl!) // If profileImageUrl is not null or empty, load the network image
                      : AssetImage('assets/images/dp.jpg') as ImageProvider, // Fallback to default image if profileImageUrl is null or empty
                  backgroundColor: Colors.grey[300],
                ),
                IconButton(
                  icon: Icon(Icons.camera_alt, color: Colors.black),
                  onPressed: _pickImage,
                ),
              ],
            ),
            SizedBox(height: 15),
            Text(
              userName,
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.w600),
            ),
            SizedBox(height: 5),
            Text(
              userId,
              style: TextStyle(fontSize: 16, color: Colors.black54),
            ),
            SizedBox(height: 5),
            Text(
              'Patient',
              style: TextStyle(fontSize: 16, color: Colors.black54),
            ),
            SizedBox(height: 20),
            ProfileOption(
              icon: Icons.info_outline,
              text: 'Personal Details',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => PatientEditProfile()),
                );
              },
            ),
            ProfileOption(
              icon: Icons.lock_outline,
              text: 'Change Password',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ChangePasswordScreen()),
                );
              },
            ),
            ProfileOption(
              icon: Icons.logout,
              text: 'Logout',
              onTap: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => PatientLoginScreen()),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class ProfileOption extends StatelessWidget {
  final IconData icon;
  final String text;
  final VoidCallback onTap;

  ProfileOption({required this.icon, required this.text, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: InkWell(
        onTap: onTap,
        child: Container(
          padding: EdgeInsets.symmetric(vertical: 15, horizontal: 20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(8),
            boxShadow: [
              BoxShadow(
                color: Colors.black12,
                blurRadius: 5,
                offset: Offset(0, 2),
              ),
            ],
          ),
          child: Row(
            children: [
              Icon(icon, color: Colors.black),
              SizedBox(width: 20),
              Expanded(
                child: Text(
                  text,
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                ),
              ),
              Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey),
            ],
          ),
        ),
      ),
    );
  }
}