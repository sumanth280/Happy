import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:http/http.dart' as http;
import '/api.dart';  // Import the api.dart file for PatientSignupUrl
import 'patient_login.dart';  // Import the patient_login.dart file

class CreateAccountScreen extends StatefulWidget {
  @override
  _CreateAccountScreenState createState() => _CreateAccountScreenState();
}

class _CreateAccountScreenState extends State<CreateAccountScreen> {
  // Text controllers for form fields
  TextEditingController nameController = TextEditingController();
  TextEditingController ageController = TextEditingController();
  TextEditingController weightController = TextEditingController();
  TextEditingController heightController = TextEditingController();
  TextEditingController bmiController = TextEditingController();
  TextEditingController professionController = TextEditingController();
  TextEditingController phone1Controller = TextEditingController();
  TextEditingController phone2Controller = TextEditingController();
  TextEditingController addressController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController confirmPasswordController = TextEditingController();

  // Gender selection variable
  String? selectedGender;

  // Gender options
  List<String> genderOptions = ['Male', 'Female', 'Transgender'];

  // Function to open date picker and set selected date in age field
  Future<void> _selectDate(BuildContext context) async {
    DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
    );
    if (pickedDate != null) {
      setState(() {
        ageController.text = DateFormat('yyyy-MM-dd').format(pickedDate);
      });
    }
  }

  // Function to calculate BMI based on weight and height inputs
  void _calculateBMI() {
    double? weight = double.tryParse(weightController.text);
    double? height = double.tryParse(heightController.text);

    if (weight != null && height != null && height > 0) {
      double bmi = weight / (height * height);
      bmiController.text = bmi.toStringAsFixed(2);
    } else {
      bmiController.clear(); // Clear the BMI field if input is invalid
    }
  }

  // Function to show account creation success popup with patient_id
  void _showSuccessPopup(BuildContext context, String patientId) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Account Created Successfully'),
          content: Text('Your account has been created successfully!\nPatient ID: $patientId'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (context) => PatientLoginScreen(),
                  ),
                );
              },
              child: Text('Done'),
            ),
          ],
        );
      },
    );
  }

  // Function to call the API for account creation
  Future<void> _createAccount() async {
    final response = await http.post(
      Uri.parse(PatientSignupurl),
      body: {
        'name': nameController.text,
        'age': ageController.text,
        'gender': selectedGender ?? '', // Use selectedGender
        'phone_number_1': phone1Controller.text,
        'profession': professionController.text,
        'weight': weightController.text,
        'height': heightController.text,
        'phone_number_2': phone2Controller.text,
        'address': addressController.text,
        'password': passwordController.text,
        'confirm_password': confirmPasswordController.text,
      },
    );

    final jsonResponse = jsonDecode(response.body);

    if (jsonResponse['status'] == true) {
      String patientId = jsonResponse['patient_id'];
      _showSuccessPopup(context, patientId);
    } else {
      // Show error if account creation fails
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(jsonResponse['message'] ?? 'Failed to create account')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF7F7F7),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(height: 40),
              Center(
                child: Text(
                  'Create New Account',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                ),
              ),
              SizedBox(height: 20),
              _buildTextField('Full Name', nameController, 'Enter Your Full Name'),
              _buildDatePickerField(context, 'Age', ageController),
              _buildGenderField(), // Gender selection dropdown
              _buildTextField('Weight', weightController, 'Weight (kg)', onChanged: _calculateBMI),
              _buildTextField('Height', heightController, 'Height (m)', onChanged: _calculateBMI),
              _buildTextField('BMI', bmiController, 'Body Mass Index', enabled: false),
              _buildTextField('Profession', professionController, 'Profession'),
              _buildTextField('Phone number 1', phone1Controller, 'Phone number 1'),
              _buildTextField('Phone number 2', phone2Controller, 'Phone number 2'),
              _buildTextField('Address', addressController, 'Enter your Address'),
              _buildTextField('Password', passwordController, 'Enter Your Password', obscureText: true),
              _buildTextField('Confirm Password', confirmPasswordController, 'Confirm Your Password', obscureText: true),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _createAccount,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.black,
                  minimumSize: Size(double.infinity, 50),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: Text(
                  'Sign Up',
                  style: TextStyle(fontSize: 16),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(String label, TextEditingController controller, String hint,
      {bool obscureText = false, bool enabled = true, void Function()? onChanged}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: TextField(
        controller: controller,
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
        ),
        obscureText: obscureText,
        enabled: enabled,
        onChanged: onChanged != null ? (value) => onChanged() : null,
      ),
    );
  }

  Widget _buildDatePickerField(BuildContext context, String label, TextEditingController controller) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: GestureDetector(
        onTap: () => _selectDate(context),
        child: AbsorbPointer(
          child: TextField(
            controller: controller,
            decoration: InputDecoration(
              labelText: label,
              hintText: 'Date of birth',
              suffixIcon: Icon(Icons.calendar_today),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
            ),
          ),
        ),
      ),
    );
  }

  // Gender dropdown field
  Widget _buildGenderField() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: DropdownButtonFormField<String>(
        value: selectedGender,
        decoration: InputDecoration(
          labelText: 'Gender',
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
        ),
        onChanged: (String? newValue) {
          setState(() {
            selectedGender = newValue;
          });
        },
        items: genderOptions.map((String gender) {
          return DropdownMenuItem<String>(
            value: gender,
            child: Text(gender),
          );
        }).toList(),
        hint: Text('Select Gender'),
      ),
    );
  }
}
