import 'package:flutter/material.dart';
import 'appointment_history.dart'; // Import the AppointmentHistoryScreen from appointment_history.dart
import '/api.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class MyAppointments extends StatefulWidget {
  @override
  _MyAppointmentsState createState() => _MyAppointmentsState();
}

class _MyAppointmentsState extends State<MyAppointments> {
  List<Map<String, dynamic>> appointments = [];
  bool isLoading = true;
  String message = '';

  // Function to fetch pending appointments from my_appointments.dart
  Future<void> fetchAppointments() async {
    final url = Uri.parse(My_appointmentsurl);  // Use the URL from my_appointments.dart

    try {
      // Send POST request with patient_id from my_appointments.dart
      final response = await http.post(
        url,
        body: {
          'patient_id': patient_id,  // Use the patient_id from my_appointments.dart
        },
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        if (data['status'] == true) {
          setState(() {
            appointments = List<Map<String, dynamic>>.from(data['data']);
            isLoading = false;
            message = data['message'];
          });
        } else {
          setState(() {
            isLoading = false;
            message = data['message'];
          });
        }
      } else {
        setState(() {
          isLoading = false;
          message = 'Failed to load appointments. Please try again later.';
        });
      }
    } catch (e) {
      setState(() {
        isLoading = false;
        message = 'An error occurred: $e';
      });
    }
  }

  @override
  void initState() {
    super.initState();
    fetchAppointments(); // Fetch the appointments when the screen loads
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('My Appointments', style: TextStyle(color: Colors.black)),
        backgroundColor: Colors.white,
        centerTitle: true,
        elevation: 0,
        automaticallyImplyLeading: false, // Hides the default back button
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Upcoming',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8.0),
            Expanded(
              child: isLoading
                  ? Center(child: CircularProgressIndicator())
                  : appointments.isEmpty
                      ? Center(
                          child: Text(
                            'No upcoming appointments.',
                            style: TextStyle(fontSize: 16, color: Colors.grey),
                          ),
                        )
                      : ListView.builder(
                          itemCount: appointments.length,
                          itemBuilder: (context, index) {
                            return Container(
                              margin: EdgeInsets.symmetric(vertical: 8.0),
                              decoration: BoxDecoration(
                                color: Colors.white,  // Set background to white
                                borderRadius: BorderRadius.circular(8.0),
                                border: Border.all(
                                  color: Colors.grey,  // Set border color to grey
                                  width: 1.0,
                                ),
                              ),
                              child: AppointmentCard(
                                name: appointments[index]['name'] ?? 'N/A',
                                date: appointments[index]['date'] ?? 'N/A',
                                time: appointments[index]['time'] ?? 'N/A',
                                profilePic: appointments[index]['profile_pic'] ?? '',  // It won't be used now
                              ),
                            );
                          },
                        ),
            ),
            SizedBox(height: 16.0),
            Align(
              alignment: Alignment.center,
              child: Text(
                'Appointment History',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
            SizedBox(height: 8.0),
            Padding(
              padding: const EdgeInsets.only(bottom: 70.0),
              child: Center(
                child: ElevatedButton.icon(
                  onPressed: () {
                    // Navigate to the AppointmentHistoryScreen from the appointment_history.dart file
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => AppointmentHistoryScreen(),
                      ),
                    );
                  },
                  icon: Icon(Icons.history),
                  label: Text('Appointment history'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.black,
                    padding: EdgeInsets.symmetric(vertical: 16.0, horizontal: 24.0),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class AppointmentCard extends StatelessWidget {
  final String name;
  final String date;
  final String time;
  final String profilePic;

  AppointmentCard({required this.name, required this.date, required this.time, this.profilePic = ''});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Row(
        children: [
          // Always display the profile icon
          Icon(Icons.person, size: 40, color: Colors.grey),
          SizedBox(width: 16.0),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Text('Name :', style: TextStyle(fontSize: 16)),
                  SizedBox(width: 8),
                  Text(name, style: TextStyle(fontSize: 16)),
                ],
              ),
              Row(
                children: [
                  Text('Date   :', style: TextStyle(fontSize: 16)),
                  SizedBox(width: 8),
                  Text(date, style: TextStyle(fontSize: 16)),
                ],
              ),
              Row(
                children: [
                  Text('Time  :', style: TextStyle(fontSize: 16)),
                  SizedBox(width: 8),
                  Text(time, style: TextStyle(fontSize: 16)),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}
