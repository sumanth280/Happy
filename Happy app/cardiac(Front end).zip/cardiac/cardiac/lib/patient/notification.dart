import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '/api.dart'; // Import api.dart for Notificationurl and patient_id

class NotificationsScreen extends StatefulWidget {
  @override
  _NotificationsScreenState createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  bool isLoading = true;
  String message = '';
  List<Map<String, dynamic>> notifications = [];

  // Function to fetch notifications using patient_id from api.dart
  Future<void> fetchNotifications() async {
    final url = Uri.parse(Notificationurl);

    try {
      // Send POST request with patient_id from api.dart
      final response = await http.post(
        url,
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: {
          "patient_id": patient_id,
        },
      );

      // Check for success response code (200)
      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        if (data['status'] == true && data['notifications'] != null) {
          setState(() {
            notifications = List<Map<String, dynamic>>.from(data['notifications']);
            isLoading = false;
          });
        } else {
          setState(() {
            isLoading = false;
            message = data['message'] ?? 'No notifications found.';
          });
        }
      } else {
        setState(() {
          isLoading = false;
          message = 'Failed to load notifications. Server error.';
        });
      }
    } catch (e) {
      setState(() {
        isLoading = false;
        message = 'An error occurred: $e';
      });
    }
  }

  // Function to delete the medicine reminder by notification_id
  Future<void> deleteMedicine(String notificationId) async {
    final url = Uri.parse(Delete_remainderurl); // Use the delete URL from api.dart

    try {
      // Send POST request with patient_id and notification_id to delete the reminder
      final response = await http.post(
        url,
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: {
          'patient_id': patient_id, // patient_id from api.dart
          'notification_id': notificationId, // notification_id passed from the notification list
        },
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        if (data['status'] == true) {
          // Successfully deleted the notification
          setState(() {
            notifications.removeWhere((notif) => notif['notification_id'] == notificationId);
            message = 'Reminder deleted successfully';
          });
        } else {
          setState(() {
            message = data['message'] ?? 'Failed to delete reminder.';
          });
        }
      } else {
        setState(() {
          message = 'Failed to delete reminder. Server error.';
        });
      }
    } catch (e) {
      setState(() {
        message = 'An error occurred while deleting the reminder: $e';
      });
    }
  }

  // Function to show delete confirmation dialog
  void _showDeleteConfirmation(BuildContext context, String notificationId) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Delete Reminder'),
          content: Text('Are you sure you want to delete this reminder?'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                // Call the deleteMedicine function with the notification_id
                deleteMedicine(notificationId);
                Navigator.pop(context);
              },
              child: Text('Delete', style: TextStyle(color: Colors.red)),
            ),
          ],
        );
      },
    );
  }

  @override
  void initState() {
    super.initState();
    fetchNotifications(); // Fetch notifications when the screen is loaded
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Notification Alerts', style: TextStyle(color: Colors.black)),
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.notifications, color: Colors.black),
            onPressed: () {},
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: isLoading
            ? Center(child: CircularProgressIndicator())
            : notifications.isEmpty
                ? Center(
                    child: Text(
                      message.isEmpty ? 'No notifications available.' : message,
                      style: TextStyle(fontSize: 18, color: Colors.grey),
                    ),
                  )
                : ListView.builder(
                    itemCount: notifications.length,
                    itemBuilder: (context, index) {
                      final notification = notifications[index];

                      // Extract medicine_name, time_med
                      final medicineName = notification['medicine_name'] ?? 'No medicine name provided';
                      final timeMed = notification['time_med'] ?? 'No time specified';

                      // Format time (HH:MM AM/PM)
                      final formattedTime = _formatTime(timeMed);

                      return Container(
                        margin: EdgeInsets.symmetric(vertical: 8.0),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Colors.grey, width: 1),
                        ),
                        child: ListTile(
                          contentPadding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
                          title: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              // Display medicine_name and time on the same line
                              Expanded(
                                child: Text(
                                  medicineName,
                                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                                  overflow: TextOverflow.ellipsis, // Handle overflow of long names
                                ),
                              ),
                              // Display formatted time
                              SizedBox(width: 8),
                              Text(
                                formattedTime,
                                style: TextStyle(fontSize: 16, color: Colors.grey),
                              ),
                            ],
                          ),
                          trailing: IconButton(
                            icon: Icon(Icons.more_vert),
                            onPressed: () {
                              // Show delete confirmation dialog with notification_id
                              _showDeleteConfirmation(context, notification['notification_id']);
                            },
                          ),
                        ),
                      );
                    },
                  ),
      ),
    );
  }

  // Function to format time to HH:MM AM/PM
  String _formatTime(String time) {
    try {
      final timeParts = time.split(':');
      int hour = int.parse(timeParts[0]);
      int minute = int.parse(timeParts[1]);

      String period = hour >= 12 ? 'PM' : 'AM';
      if (hour > 12) hour -= 12; // Convert to 12-hour format
      if (hour == 0) hour = 12; // Handle midnight as 12 AM

      return '$hour:${minute.toString().padLeft(2, '0')} $period';
    } catch (e) {
      return 'Invalid time format';
    }
  }
}
