import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '/api.dart'; // Ensure this file contains patient_id and Symptomtrendsurl

Future<Map<String, dynamic>> fetchSymptomTrends({
  required String filter,
  String? startDate,
  String? endDate,
}) async {
  try {
    if (patient_id == null || patient_id.isEmpty) {
      throw Exception("Patient ID is not available.");
    }

    final Map<String, String> body = {
      'patient_id': patient_id,
      'filter': filter,
    };

    if (filter == 'date_range' && startDate != null && endDate != null) {
      body['start_date'] = startDate;
      body['end_date'] = endDate;
    }

    final response = await http.post(
      Uri.parse(Symptomtrendsurl),
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: body,
    );

    if (response.statusCode == 200) {
      final Map<String, dynamic> jsonResponse = json.decode(response.body);
      if (jsonResponse['status'] == true) {
        return {
          'status': true,
          'data': jsonResponse['data'],
        };
      } else {
        return {
          'status': false,
          'message': jsonResponse['message'] ?? 'No data available.',
        };
      }
    } else {
      throw Exception('Failed to fetch data. Status Code: ${response.statusCode}');
    }
  } catch (e) {
    return {
      'status': false,
      'message': e.toString(),
    };
  }
}

class SymptomTrends extends StatefulWidget {
  @override
  _SymptomTrendsState createState() => _SymptomTrendsState();
}

class _SymptomTrendsState extends State<SymptomTrends> {
  List<Map<String, dynamic>> symptomData = [];
  String selectedFilter = "today";
  bool isLoading = true;
  DateTime? startDate;
  DateTime? endDate;

  @override
  void initState() {
    super.initState();
    _fetchSymptomTrends(selectedFilter);
  }

  Future<void> _fetchSymptomTrends(String filter) async {
    setState(() {
      isLoading = true;
    });

    try {
      Map<String, dynamic> response = await fetchSymptomTrends(
        filter: filter,
        startDate: startDate?.toIso8601String(),
        endDate: endDate?.toIso8601String(),
      );

      if (response['status'] == true) {
        setState(() {
          symptomData = List<Map<String, dynamic>>.from(response['data'] ?? []);
        });
      } else {
        setState(() {
          symptomData = [];
        });
      }
    } catch (e) {
      setState(() {
        symptomData = [];
      });
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  Future<void> _selectDateRange() async {
    final picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2000),
      lastDate: DateTime.now(),
    );

    if (picked != null && picked.start != null && picked.end != null) {
      setState(() {
        startDate = picked.start;
        endDate = picked.end;
      });
      await _fetchSymptomTrends("date_range");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: DropdownButton<String>(
              value: selectedFilter,
              items: ["today", "last_week", "date_range"].map((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value.replaceAll('_', ' ').toUpperCase()),
                );
              }).toList(),
              onChanged: (value) async {
                if (value != null) {
                  setState(() {
                    selectedFilter = value;
                  });

                  if (value == "date_range") {
                    await _selectDateRange();
                  } else {
                    await _fetchSymptomTrends(value);
                  }
                }
              },
              isExpanded: true,
            ),
          ),
          Expanded(
            child: isLoading
                ? Center(child: CircularProgressIndicator())
                : symptomData.isEmpty
                    ? Center(
                        child: Text(
                          "No data available.",
                          style: TextStyle(fontSize: 16, color: Colors.red),
                        ),
                      )
                    : ListView.builder(
                        itemCount: symptomData.length,
                        itemBuilder: (context, index) {
                          final entry = symptomData[index];
                          return _buildSymptomEntry(entry);
                        },
                      ),
          ),
        ],
      ),
    );
  }

  Widget _buildSymptomEntry(Map<String, dynamic> entry) {
    String formattedTimestamp = entry['time_stamp'];
    Map<String, String> symptoms = {
      'Shortness of Breath': entry['shortness_of_breath'],
      'Cough': entry['cough'],
      'Fatigue/Weakness': entry['fatigue_weakness'],
      'Chest Pain': entry['chest_pain'],
      'Palpitations': entry['palpatations'],
      'Abdomen Discomfort': entry['abdomen_discomfort'],
      'Confusion': entry['confusion'],
      'Weight Gain/Pedal Edema': entry['weight_gain'],
      'Sleep Difficulty': entry['sleep_difficulty'],
    };

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
      child: Card(
        color: Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8.0),
        ),
        elevation: 3,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Date & Time: $formattedTimestamp",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 8),
              Column(
                children: symptoms.entries.map((symptom) {
                  return _buildSymptomRow(symptom.key, symptom.value);
                }).toList(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSymptomRow(String symptom, String? status) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(symptom, style: TextStyle(fontSize: 16)),
          Icon(
            status == 'yes'
                ? Icons.check_circle
                : Icons.cancel,
            color: status == 'yes' ? Colors.green : Colors.red,
          ),
        ],
      ),
    );
  }
}
