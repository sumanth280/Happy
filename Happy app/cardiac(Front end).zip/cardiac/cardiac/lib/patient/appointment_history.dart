import 'package:flutter/material.dart';
import '/api.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class AppointmentHistoryScreen extends StatefulWidget {
  @override
  _AppointmentHistoryScreenState createState() => _AppointmentHistoryScreenState();
}

class _AppointmentHistoryScreenState extends State<AppointmentHistoryScreen> {
  List<Map<String, dynamic>> appointmentsHistory = [];
  bool isLoading = true;
  String message = '';

  // Function to fetch appointment history
  Future<void> fetchAppointmentHistory() async {
    final url = Uri.parse(Appointmenthistoryurl);  // Use the correct URL for appointment history

    try {
      // Send POST request with patient_id
      final response = await http.post(
        url,
        body: {
          'patient_id': patient_id,  // Use the patient_id
        },
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        if (data['status'] == true) {
          setState(() {
            appointmentsHistory = List<Map<String, dynamic>>.from(data['data']);
            isLoading = false;
            message = data['message'];
          });
        } else {
          setState(() {
            isLoading = false;
            message = data['message'];
          });
        }
      } else {
        setState(() {
          isLoading = false;
          message = 'Failed to load appointment history. Please try again later.';
        });
      }
    } catch (e) {
      setState(() {
        isLoading = false;
        message = 'An error occurred: $e';
      });
    }
  }

  @override
  void initState() {
    super.initState();
    fetchAppointmentHistory();  // Fetch appointment history when the screen loads
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Appointment History', style: TextStyle(color: Colors.black)),
        backgroundColor: Colors.white,
        centerTitle: true,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'History',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8.0),
            Expanded(
              child: isLoading
                  ? Center(child: CircularProgressIndicator())
                  : appointmentsHistory.isEmpty
                      ? Center(
                          child: Text(
                            'No appointment history.',
                            style: TextStyle(fontSize: 16, color: Colors.grey),
                          ),
                        )
                      : ListView.builder(
                          itemCount: appointmentsHistory.length,
                          itemBuilder: (context, index) {
                            return Container(
                              margin: EdgeInsets.symmetric(vertical: 8.0),
                              decoration: BoxDecoration(
                                color: Colors.white,  // Set background to white
                                borderRadius: BorderRadius.circular(8.0),
                                border: Border.all(
                                  color: Colors.grey,  // Set border color to grey
                                  width: 1.0,
                                ),
                              ),
                              child: AppointmentCard(
                                name: appointmentsHistory[index]['name'] ?? 'N/A',
                                date: appointmentsHistory[index]['date'] ?? 'N/A',
                                time: appointmentsHistory[index]['time'] ?? 'N/A',
                                profilePic: appointmentsHistory[index]['profile_pic'] ?? '',
                              ),
                            );
                          },
                        ),
            ),
          ],
        ),
      ),
    );
  }
}

class AppointmentCard extends StatelessWidget {
  final String name;
  final String date;
  final String time;
  final String profilePic;

  AppointmentCard({required this.name, required this.date, required this.time, this.profilePic = ''});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Row(
        children: [
          // Always display the profile icon
          Icon(Icons.person, size: 40, color: Colors.grey),
          SizedBox(width: 16.0),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Text('Name :', style: TextStyle(fontSize: 16)),
                  SizedBox(width: 8),
                  Text(name, style: TextStyle(fontSize: 16)),
                ],
              ),
              Row(
                children: [
                  Text('Date   :', style: TextStyle(fontSize: 16)),
                  SizedBox(width: 8),
                  Text(date, style: TextStyle(fontSize: 16)),
                ],
              ),
              Row(
                children: [
                  Text('Time  :', style: TextStyle(fontSize: 16)),
                  SizedBox(width: 8),
                  Text(time, style: TextStyle(fontSize: 16)),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}
