import 'package:flutter/material.dart';
import '../provider/add_remainder.dart';
import '/api.dart'; // Import the API functions from api.dart
import 'analytics.dart'; // Import your Analytics page

class RemainderScreen extends StatefulWidget {
  final String medicineName; // Accept medicine name as parameter

  RemainderScreen({required this.medicineName});

  @override
  _MyNotificationsState createState() => _MyNotificationsState();
}

class _MyNotificationsState extends State<RemainderScreen> {
  List<bool> _selectedDays = List.generate(7, (_) => false);
  TimeOfDay _selectedTime = TimeOfDay(hour: 20, minute: 0);
  late String _medicineName;

  @override
  void initState() {
    super.initState();
    _medicineName = widget.medicineName; // Initialize _medicineName with the passed value
  }

  // Function to select the time
  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: _selectedTime,
      builder: (BuildContext context, Widget? child) {
        return MediaQuery(
          data: MediaQuery.of(context).copyWith(alwaysUse24HourFormat: true),
          child: child!,
        );
      },
    );
    if (picked != null && picked != _selectedTime)
      setState(() {
        _selectedTime = picked;
      });
  }

  // Function to handle the API call when user presses the "Set Reminder" button
  Future<void> _setReminder() async {
    if (_medicineName.isEmpty) {
      // Show error if medicine name is empty
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please enter the medicine name')),
      );
      return;
    }

    final result = await addMedicationReminder(
      medicineName: _medicineName,
      timeMed: '${_selectedTime.hour.toString().padLeft(2, '0')}:${_selectedTime.minute.toString().padLeft(2, '0')}',
      monday: _selectedDays[0] ? 'yes' : 'no',
      tuesday: _selectedDays[1] ? 'yes' : 'no',
      wednesday: _selectedDays[2] ? 'yes' : 'no',
      thursday: _selectedDays[3] ? 'yes' : 'no',
      friday: _selectedDays[4] ? 'yes' : 'no',
      saturday: _selectedDays[5] ? 'yes' : 'no',
      sunday: _selectedDays[6] ? 'yes' : 'no',
    );

    if (result['status'] == true) {
      // Show success message in a popup dialog and navigate back on OK
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Success'),
            content: Text('Reminder set successfully!'),
            actions: <Widget>[
              TextButton(
                onPressed: () {
                  // Close the dialog and go back to the previous screen
                  Navigator.of(context).pop(); // Close dialog
                  Navigator.of(context).pop(); // Return to previous screen with tab bar
                },
                child: Text('OK'),
              ),
            ],
          );
        },
      );
    } else {
      // Show error message if there was an issue
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: ${result['message']}')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Set Medication Reminder'),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(vertical: 30.0, horizontal: 20.0),
        child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              SizedBox(height: 50), // Space above the "Remainder" heading
              Text(
                "Remainder",
                style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 40), // Space between heading and other sections

              // Medicine Name Input (Uneditable)
              TextField(
                controller: TextEditingController(text: _medicineName),
                enabled: false,  // This makes the TextField uneditable
                decoration: InputDecoration(
                  labelText: 'Enter Medicine Name',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 30), // Space between medicine input and day selection

              // Select Days Section
              Text(
                "Select Days",
                style: TextStyle(fontSize: 22),
              ),
              SizedBox(height: 30),

              // Scrollable Day Buttons Row
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: List.generate(7, (index) {
                    return GestureDetector(
                      onTap: () {
                        setState(() {
                          _selectedDays[index] = !_selectedDays[index];
                        });
                      },
                      child: Container(
                        margin: EdgeInsets.all(12),
                        padding: EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: _selectedDays[index] ? Colors.green : Colors.black,
                          shape: BoxShape.circle,
                        ),
                        child: Text(
                          ["S", "M", "T", "W", "T", "F", "S"][index],
                          style: TextStyle(color: Colors.white, fontSize: 18),
                        ),
                      ),
                    );
                  }),
                ),
              ),
              SizedBox(height: 30),

              // Select Time Section
              Text(
                "Select Time",
                style: TextStyle(fontSize: 22),
              ),
              SizedBox(height: 20),

              // Time Picker Section
              GestureDetector(
                onTap: () => _selectTime(context),
                child: Container(
                  margin: EdgeInsets.all(20),
                  padding: EdgeInsets.symmetric(vertical: 15, horizontal: 60),
                  decoration: BoxDecoration(
                    color: Colors.grey[200],
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    "${_selectedTime.hour.toString().padLeft(2, '0')}:${_selectedTime.minute.toString().padLeft(2, '0')}",
                    style: TextStyle(fontSize: 30),
                  ),
                ),
              ),
              SizedBox(height: 40),

              // Set Reminder Button
              ElevatedButton(
                onPressed: _setReminder,
                child: Text(
                  "Set Reminder",
                  style: TextStyle(fontSize: 20),
                ),
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                  backgroundColor: Colors.blue,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
