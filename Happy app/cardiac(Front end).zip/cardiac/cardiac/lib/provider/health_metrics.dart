import 'package:http/http.dart' as http;
import 'dart:convert';
import '/api.dart'; // Ensure Health_metricsurl and Health_metricsviewurl are defined here

Future<Map<String, dynamic>> submitHealthMetrics({
  required String pulseRate,
  required String spo2,
  required String bp,
  required String weight,
  required String activity,
  required String fluidIntake,
  required String saltIntake,
  required String urineInput,
  required String patientId,
}) async {
  final Map<String, dynamic> data = {
    'patient_id': patientId,
    'pulse_rate': pulseRate,
    'spo2': spo2,
    'bp': bp,
    'weight': weight,
    'activity': activity,
    'fluid_intake': fluidIntake,
    'salt_intake': saltIntake,
    'urine_output':urineInput,
  };

  try {
    final response = await http.post(
      Uri.parse(Health_metricsurl),
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: data,
    );

    if (response.statusCode == 200) {
      final responseData = json.decode(response.body);
      return responseData;
    } else {
      return {
        'status': 'false',
        'message': 'Server returned status code ${response.statusCode}',
      };
    }
  } catch (error) {
    return {
      'status': 'false',
      'message': 'An error occurred: $error',
    };
  }
}

Future<Map<String, dynamic>> fetchHealthMetrics({
  required String patientId,
}) async {
  final Map<String, dynamic> data = {
    'patient_id': patientId,
  };

  try {
    final response = await http.post(
      Uri.parse(Health_metricsviewurl),
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: data,
    );

    if (response.statusCode == 200) {
      final responseData = json.decode(response.body);
      return responseData;
    } else {
      return {
        'status': 'false',
        'message': 'Server returned status code ${response.statusCode}',
      };
    }
  } catch (error) {
    return {
      'status': 'false',
      'message': 'An error occurred: $error',
    };
  }
}
