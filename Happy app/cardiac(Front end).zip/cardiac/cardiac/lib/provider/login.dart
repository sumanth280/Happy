import '/patient/home.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../api.dart';
import 'package:flutter/material.dart';
 // Import HomeScreen

Future<Map<String, dynamic>> login(
    String phoneNumber, String password, BuildContext context) async {
  final url = Uri.parse(PatientLoginurl); // Replace with your actual server URL

  try {
    // Send POST request with phone number and password as body
    final response = await http.post(
      url,
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: {
        "phone_number_1": phoneNumber,
        "password": password,
      },
    );

    // Check for success response code (200)
    if (response.statusCode == 200) {
      // Decode JSON response
      final data = json.decode(response.body);
     
      // Check status in response and return data accordingly
      if (data["status"] == true) {
        patient_id = data["data"]["patient_id"];
        name=data["data"]["name"];
        print(patient_id,);
        print(name);
        // Successful login, navigate to HomeScreen
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => MainScreen()), // Replace with your HomeScreen widget
        );
        
        return {
          "success": true,
          "message": data["message"],
        };
      } else {
        // If login fails, show error message
        String errorMessage = data["message"] ?? "Unknown error";
        
        // Check if it's due to incorrect credentials
        if (errorMessage.contains("incorrect") || errorMessage.contains("Invalid")) {
          // Handle incorrect username or password
          _showErrorDialog(context, "Invalid username or password. Please try again.");
        } else {
          _showErrorDialog(context, errorMessage);
        }

        return {
          "success": false,
          "message": errorMessage,
        };
      }
    } else {
      // Handle other status codes
      _showErrorDialog(context, "Error: ${response.statusCode}");
      return {
        "success": false,
        "message": "Error: ${response.statusCode}",
      };
    }
  } catch (e) {
    // Handle any errors (e.g., network errors)
    _showErrorDialog(context, "An error occurred: $e");
    return {
      "success": false,
      "message": "An error occurred: $e",
    };
  }
}

// Function to show error dialog
void _showErrorDialog(BuildContext context, String message) {
  showDialog(
    context: context,
    builder: (context) => AlertDialog(
      title: Text("Login Failed"),
      content: Text(message),
      actions: [
        TextButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          child: Text("OK"),
        ),
      ],
    ),
  );
}
