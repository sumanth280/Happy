import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '/api.dart'; // Import the api.dart file where the URL and patient_id are defined

class MyAppointments extends StatefulWidget {
  @override
  _MyAppointmentsState createState() => _MyAppointmentsState();
}

class _MyAppointmentsState extends State<MyAppointments> {
  List<Map<String, dynamic>> appointments = [];
  bool isLoading = true;
  String message = '';

  // Function to fetch pending appointments
  Future<void> fetchAppointments() async {
    final url = Uri.parse(My_appointmentsurl); // Use the URL from api.dart

    try {
      // Send POST request with patient_id from api.dart
      final response = await http.post(
        url,
        body: {
          'patient_id': patient_id, // Use the patient_id from api.dart
        },
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        if (data['status'] == true) {
          // Successfully fetched appointments
          setState(() {
            appointments = List<Map<String, dynamic>>.from(data['data']);
            isLoading = false;
            message = data['message'];
          });
        } else {
          // Error in fetching data
          setState(() {
            isLoading = false;
            message = data['message'];
          });
        }
      } else {
        setState(() {
          isLoading = false;
          message = 'Failed to load appointments. Please try again later.';
        });
      }
    } catch (e) {
      setState(() {
        isLoading = false;
        message = 'An error occurred: $e';
      });
    }
  }

  @override
  void initState() {
    super.initState();
    fetchAppointments(); // Fetch the appointments when the screen loads
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('My Appointments', style: TextStyle(color: Colors.black)),
        backgroundColor: Colors.white,
        centerTitle: true,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Upcoming',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8.0),
            Expanded(
              child: isLoading
                  ? Center(child: CircularProgressIndicator())
                  : appointments.isEmpty
                      ? Center(
                          child: Text(
                            'No upcoming appointments.',
                            style: TextStyle(fontSize: 16, color: Colors.grey),
                          ),
                        )
                      : ListView.builder(
                          itemCount: appointments.length,
                          itemBuilder: (context, index) {
                            return AppointmentCard(
                              patientId: appointments[index]['patient_id'] ?? 'N/A',
                              date: appointments[index]['date'] ?? 'N/A',
                              time: appointments[index]['time'] ?? 'N/A',
                              profilePic: appointments[index]['profile_pic'] ?? '',
                            );
                          },
                        ),
            ),
            SizedBox(height: 16.0),
            Align(
              alignment: Alignment.center,
              child: Text(
                'Appointment History',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
            SizedBox(height: 8.0),
            Padding(
              padding: const EdgeInsets.only(bottom: 70.0),
              child: Center(
                child: ElevatedButton.icon(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => AppointmentHistoryScreen(),
                      ),
                    );
                  },
                  icon: Icon(Icons.history),
                  label: Text('Appointment history'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.black,
                    padding: EdgeInsets.symmetric(vertical: 16.0, horizontal: 24.0),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class AppointmentCard extends StatelessWidget {
  final String patientId;
  final String date;
  final String time;
  final String profilePic;

  AppointmentCard({
    required this.patientId,
    required this.date,
    required this.time,
    this.profilePic = '',
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.symmetric(vertical: 8.0),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          children: [
            profilePic.isNotEmpty
                ? CircleAvatar(
                    backgroundImage: NetworkImage(profilePic),
                    radius: 20,
                  )
                : Icon(Icons.person, size: 40, color: Colors.grey),
            SizedBox(width: 16.0),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Patient ID: $patientId', style: TextStyle(fontSize: 16)),
                Text('Date      : $date', style: TextStyle(fontSize: 16)),
                Text('Time      : $time', style: TextStyle(fontSize: 16)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class AppointmentHistoryScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Appointment History'),
        backgroundColor: Colors.white,
        centerTitle: true,
      ),
      body: Center(
        child: Text(
          'Appointment history details go here.',
          style: TextStyle(fontSize: 18),
        ),
      ),
    );
  }
}
