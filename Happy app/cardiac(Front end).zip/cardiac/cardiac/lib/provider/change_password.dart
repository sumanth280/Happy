import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '/api.dart';
class ChangePasswordScreen extends StatelessWidget {
  final TextEditingController currentPasswordController = TextEditingController();
  final TextEditingController newPasswordController = TextEditingController();
  final TextEditingController confirmPasswordController = TextEditingController();

  // Replace with your API URL
  final String changePasswordUrl = Changepasswordurl;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF7F7F7),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: IconThemeData(color: Colors.black),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(height: 20),
              Icon(
                Icons.lock,
                size: 100,
                color: Colors.grey.shade800,
              ),
              SizedBox(height: 20),
              Text(
                'Change Password',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 10),
              Text(
                'Please Change your Password',
                style: TextStyle(fontSize: 16, color: Colors.grey),
              ),
              SizedBox(height: 30),
              _buildPasswordField('Current Password', currentPasswordController),
              SizedBox(height: 16),
              _buildPasswordField('New Password', newPasswordController),
              SizedBox(height: 16),
              _buildPasswordField('Confirm Password', confirmPasswordController),
              SizedBox(height: 30),
              ElevatedButton(
                onPressed: () {
                  _validatePassword(context);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.black,
                  minimumSize: Size(double.infinity, 50),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: Text(
                  'Submit',
                  style: TextStyle(fontSize: 16),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPasswordField(String label, TextEditingController controller) {
    return TextField(
      controller: controller,
      obscureText: true,
      decoration: InputDecoration(
        labelText: label,
        hintText: 'Enter Your $label',
        prefixIcon: Icon(Icons.lock),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
        ),
      ),
    );
  }

  void _validatePassword(BuildContext context) {
    // Check if each field is filled
    if (currentPasswordController.text.isEmpty) {
      _showErrorDialog(context, 'Current Password is required.');
      return;
    } else if (newPasswordController.text.isEmpty) {
      _showErrorDialog(context, 'New Password is required.');
      return;
    } else if (confirmPasswordController.text.isEmpty) {
      _showErrorDialog(context, 'Confirm Password is required.');
      return;
    }
    
    // Check if new password and confirm password match
    if (newPasswordController.text == confirmPasswordController.text) {
      _changePassword(context);
    } else {
      _showErrorDialog(context, 'New password and confirm password do not match.');
    }
  }

  Future<void> _changePassword(BuildContext context) async {
    final currentPassword = currentPasswordController.text;
    final newPassword = newPasswordController.text;

    try {
      final response = await http.post(
        Uri.parse(changePasswordUrl),
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: {
          'current_password': currentPassword,
          'new_password': newPassword,
        },
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status'] == true) {
          _showConfirmationDialog(context);
        } else {
          _showErrorDialog(context, data['message'] ?? 'Failed to change password');
        }
      } else {
        _showErrorDialog(context, 'Server error. Please try again later.');
      }
    } catch (error) {
      _showErrorDialog(context, 'An error occurred: $error');
    }
  }

  void _showErrorDialog(BuildContext context, String message) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Error'),
          content: Text(message),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('OK'),
            ),
          ],
        );
      },
    );
  }

  void _showConfirmationDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Success'),
          content: Text('Password changed successfully.'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                Navigator.pop(context); // Pop twice to return to previous screen
              },
              child: Text('OK'),
            ),
          ],
        );
      },
    );
  }
}
