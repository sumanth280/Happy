import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '/api.dart'; // Import the api.dart file where the URL and patient_id are defined

class DeleteMedicine extends StatefulWidget {
  final String notificationId; // Add notification_id as a parameter to this widget

  DeleteMedicine({required this.notificationId}); // Constructor to pass notification_id

  @override
  _DeleteMedicineState createState() => _DeleteMedicineState();
}

class _DeleteMedicineState extends State<DeleteMedicine> {
  bool isLoading = false;
  String message = '';

  // Function to delete medicine by patient_id and notification_id
  Future<void> deleteMedicine() async {
    final url = Uri.parse(Delete_remainderurl); // Use the URL from api.dart

    try {
      setState(() {
        isLoading = true; // Set loading to true while the request is in progress
      });

      // Send POST request with patient_id from api.dart and notification_id from widget
      final response = await http.post(
        url,
        body: {
          'patient_id': patient_id, // Use the patient_id from api.dart
          'notification_id': widget.notificationId, // Use notification_id passed to the widget
        },
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        if (data['status'] == true) {
          // Successfully deleted the record
          setState(() {
            isLoading = false;
            message = 'Record deleted successfully';
          });
        } else {
          // Error in deleting the record
          setState(() {
            isLoading = false;
            message = data['message'];
          });
        }
      } else {
        setState(() {
          isLoading = false;
          message = 'Failed to delete record. Please try again later.';
        });
      }
    } catch (e) {
      setState(() {
        isLoading = false;
        message = 'An error occurred: $e';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Delete Record', style: TextStyle(color: Colors.black)),
        backgroundColor: Colors.white,
        centerTitle: true,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Delete Record for Patient',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8.0),
            ElevatedButton(
              onPressed: () {
                // Call the delete function with the patient_id and notification_id
                deleteMedicine();
              },
              child: Text('Delete Record'),
            ),
            SizedBox(height: 16.0),
            if (isLoading) 
              Center(child: CircularProgressIndicator()),
            if (message.isNotEmpty) 
              Center(child: Text(message, style: TextStyle(fontSize: 16))),
          ],
        ),
      ),
    );
  }
}
