import 'package:http/http.dart' as http;
import 'dart:convert';
import '/api.dart'; // Ensure this imports Patienteditprofileurl, Patientdetailsurl, and patient_id

// Function to fetch patient details
Future<Map<String, dynamic>> fetchPatientDetails() async {
  final response = await http.post(
    Uri.parse(Patientdetailsurl),
    body: {'patient_id': patient_id},
  );

  if (response.statusCode == 200) {
    final data = json.decode(response.body);
    if (data['status'] == true) {
      return data['data'];
    } else {
      throw Exception(data['message']);
    }
  } else {
    throw Exception('Failed to fetch patient details');
  }
}

// Function to edit patient details
Future<bool> editPatientProfile({
  required String name,
  required String age,
  required String gender,
  required String phoneNumber1,
  String? phoneNumber2,
  String? profession,
  String? weight,
  String? height,
  String? bmi,
  String? address,
}) async {
  final response = await http.post(
    Uri.parse(Patienteditprofileurl),
    body: {
      'patient_id': patient_id,
      'name': name,
      'age': age,
      'gender': gender,
      'phone_number_1': phoneNumber1,
      'phone_number_2': phoneNumber2 ?? '',
      'profession': profession ?? '',
      'weight': weight ?? '',
      'height': height ?? '',
      'bmi': bmi ?? '',
      'address': address ?? '',
    },
  );

  if (response.statusCode == 200) {
    final data = json.decode(response.body);
    return data['status'] == 'success';
  } else {
    throw Exception('Failed to update patient profile');
  }
}
