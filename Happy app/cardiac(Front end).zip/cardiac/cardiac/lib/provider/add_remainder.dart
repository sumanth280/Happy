import 'package:http/http.dart' as http;
import 'dart:convert';
import '/api.dart'; // Assuming this file contains `Add_remainderurl` and `patient_id` constants

Future<Map<String, dynamic>> addMedicationReminder({
  required String medicineName,
  required String timeMed,
  String monday = 'no',
  String tuesday = 'no',
  String wednesday = 'no',
  String thursday = 'no',
  String friday = 'no',
  String saturday = 'no',
  String sunday = 'no',
}) async {
  // Construct the data map to send
  final Map<String, String> data = {
    'patient_id': patient_id, // Imported from `api.dart`
    'medicine_name': medicineName,
    'time_med': timeMed,
    'monday': monday,
    'tuesday': tuesday,
    'wednesday': wednesday,
    'thursday': thursday,
    'friday': friday,
    'saturday': saturday,
    'sunday': sunday,
  };

  try {
    // Send a POST request
    final response = await http.post(
      Uri.parse(Add_remainderurl), // Imported URL from `api.dart`
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body: data,
    );

    // Check if request was successful
    if (response.statusCode == 200) {
      // Parse and return JSON response as a map
      return json.decode(response.body);
    } else {
      // Handle error by returning status as false
      return {
        'status': false,
        'message': 'Failed to add reminder: ${response.statusCode}',
      };
    }
  } catch (e) {
    // Handle any exceptions
    return {
      'status': false,
      'message': 'An error occurred: $e',
    };
  }
}
