import 'dart:convert';
import 'package:http/http.dart' as http;
import '/api.dart'; // Ensure Profileviewurl and patient_id are defined here

Future<Map<String, dynamic>> fetchPatientProfile(String patient_id) async {
  final uri = Uri.parse(Profileviewurl);

  try {
    // Make the POST request with the patient_id
    final response = await http.post(
      uri,
      body: {
        'patient_id': patient_id,
      },
    );

    // Check if the response status code is 200 (OK)
    if (response.statusCode == 200) {
      final responseData = json.decode(response.body);

      // Check if the response indicates success
      if (responseData['status'] == 'success') {
        return {
          'status': true,
          'name': responseData['name'],
          'profile_pic': responseData['profile_pic'],
        };
      } else {
        return {
          'status': false,
          'message': responseData['message'] ?? 'Error retrieving data',
        };
      }
    } else {
      return {
        'status': false,
        'message': 'Server returned status code ${response.statusCode}',
      };
    }
  } catch (error) {
    return {
      'status': false,
      'message': 'An error occurred: $error',
    };
  }
}
