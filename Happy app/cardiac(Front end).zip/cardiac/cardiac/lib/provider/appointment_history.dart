import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '/api.dart'; // Import api.dart to access Appointmenthistoryurl and patient_id

class AppointmentHistoryScreen extends StatefulWidget {
  @override
  _AppointmentHistoryScreenState createState() => _AppointmentHistoryScreenState();
}

class _AppointmentHistoryScreenState extends State<AppointmentHistoryScreen> {
  bool isLoading = true;
  String message = '';
  List<Map<String, dynamic>> appointments = [];

  // Function to fetch appointment history using patient_id
  Future<void> fetchAppointmentHistory(String patientId) async {
    final url = Uri.parse(Appointmenthistoryurl);

    try {
      // Send POST request with patient_id
      final response = await http.post(
        url,
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: {
          "patient_id": patientId, // Use dynamic patientId from api.dart or previous screen
        },
      );

      // Check for success response code (200)
      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        if (data['status'] == true && data['data'] != null) {
          setState(() {
            appointments = List<Map<String, dynamic>>.from(data['data']);
            isLoading = false;
          });
        } else {
          setState(() {
            isLoading = false;
            message = data['message'] ?? 'No appointments found.';
          });
        }
      } else {
        setState(() {
          isLoading = false;
          message = 'Failed to load appointments. Server error.';
        });
      }
    } catch (e) {
      setState(() {
        isLoading = false;
        message = 'An error occurred: $e';
      });
    }
  }

  @override
  void initState() {
    super.initState();
    // Example patient data, replace with actual data from api.dart
    String patientId = patient_id;  // Use dynamic patient_id from api.dart
    
    fetchAppointmentHistory(patientId); // Fetch appointments for the patient
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Appointment History', style: TextStyle(color: Colors.black)),
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: isLoading
            ? Center(child: CircularProgressIndicator())
            : appointments.isEmpty
                ? Center(
                    child: Text(
                      message.isEmpty ? 'No appointments available.' : message,
                      style: TextStyle(fontSize: 18, color: Colors.grey),
                    ),
                  )
                : ListView.builder(
                    itemCount: appointments.length,
                    itemBuilder: (context, index) {
                      final appointment = appointments[index];

                      // Use patient_id to display instead of patient_name
                      final patientId = appointment['patient_id'] ?? 'No ID provided';
                      final date = appointment['date'] ?? 'No date specified';
                      final time = appointment['time'] ?? 'No time specified';

                      return Container(
                        margin: EdgeInsets.symmetric(vertical: 8.0),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Colors.grey, width: 1),
                        ),
                        child: ListTile(
                          contentPadding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
                          title: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Expanded(
                                child: Text(
                                  'Patient ID: $patientId',  // Display patient_id instead of name
                                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                              SizedBox(width: 8),
                              Text(
                                '$date, $time',
                                style: TextStyle(fontSize: 16, color: Colors.grey),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
      ),
    );
  }
}
