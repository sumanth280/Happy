import 'dart:convert';
import 'package:http/http.dart' as http;
import '/api.dart'; // Ensure this file contains `patient_id` and `Healthtrendsurl`

Future<Map<String, dynamic>> fetchHealthTrends({
  required String filter, // The filter (e.g., 'today', 'last_week', 'date_range')
  String? startDate, // Used for 'date_range'
  String? endDate, // Used for 'date_range'
}) async {
  try {
    // Ensure the patient_id is available
    if (patient_id == null || patient_id.isEmpty) {
      throw Exception("Patient ID is not available.");
    }

    // Prepare the request payload
    final Map<String, String> body = {
      'patient_id': patient_id,
      'filter': filter,
    };

    if (filter == 'date_range' && startDate != null && endDate != null) {
      body['start_date'] = startDate;
      body['end_date'] = endDate;
    }

    // Make the POST request to the PHP endpoint
    final response = await http.post(
      Uri.parse(Healthtrendsurl),
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: body,
    );

    // Parse the response
    if (response.statusCode == 200) {
      final Map<String, dynamic> jsonResponse = json.decode(response.body);
      if (jsonResponse['status'] == true) {
        return {
          'status': true,
          'data': jsonResponse['data'],
        };
      } else {
        return {
          'status': false,
          'message': jsonResponse['message'] ?? 'Unknown error occurred.',
        };
      }
    } else {
      throw Exception('Failed to fetch data. Status Code: ${response.statusCode}');
    }
  } catch (e) {
    return {
      'status': false,
      'message': e.toString(),
    };
  }
}
