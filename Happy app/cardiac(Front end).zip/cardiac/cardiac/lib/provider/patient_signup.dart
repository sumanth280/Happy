import 'package:http/http.dart' as http;
import 'dart:convert';
import '/api.dart';

Future<Map<String, dynamic>> signupPatient({
  required String name,
  required String age, // Expected format: YYYY-MM-DD
  required String gender,
  required String phoneNumber1,
  required String profession,
  required String weight,
  required String height,
  required String phoneNumber2,
  required String address,
  required String password,
  required String confirmPassword,
}) async {
  try {
    final response = await http.post(
      Uri.parse(PatientSignupurl),
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body: {
        'name': name,
        'age': age,
        'gender': gender,
        'phone_number_1': phoneNumber1,
        'profession': profession,
        'weight': weight,
        'height': height,
        'phone_number_2': phoneNumber2,
        'address': address,
        'password': password,
        'confirm_password': confirmPassword,
      },
    );

    if (response.statusCode == 200) {
      final jsonResponse = json.decode(response.body);
      return {
        'status': jsonResponse['status'],
        'message': jsonResponse['message'],
        'patient_id': jsonResponse['patient_id'] ?? '',
      };
    } else {
      return {
        'status': false,
        'message': 'Server error: ${response.statusCode}',
      };
    }
  } catch (e) {
    return {
      'status': false,
      'message': 'Failed to connect to server: $e',
    };
  }
}
