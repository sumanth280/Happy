import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '/api.dart'; // Import the api.dart file where the URL and patient_id are defined

class MyNotifications extends StatefulWidget {
  @override
  _MyNotificationsState createState() => _MyNotificationsState();
}

class _MyNotificationsState extends State<MyNotifications> {
  List<Map<String, dynamic>> notifications = [];
  bool isLoading = true;
  String message = '';

  // Function to fetch notifications
  Future<void> fetchNotifications() async {
    final url = Uri.parse(Notificationurl); // Use the URL from api.dart

    try {
      // Send POST request with patient_id from api.dart
      final response = await http.post(
        url,
        body: {
          'patient_id': patient_id, // Use the patient_id from api.dart
        },
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        if (data['status'] == true) {
          // Successfully fetched notifications
          setState(() {
            notifications = List<Map<String, dynamic>>.from(data['notifications']).map((notification) {
              return {
                'medicine_name': notification['medicinename'] ?? 'No Name',
                'time_med': notification['time'] ?? 'No Time',
                'notification_id': notification['notification_id'] ?? 'No ID',
              };
            }).toList();
            isLoading = false;
            message = data['message'];
          });
        } else {
          // Error in fetching data
          setState(() {
            isLoading = false;
            message = data['message'];
          });
        }
      } else {
        setState(() {
          isLoading = false;
          message = 'Failed to load notifications. Please try again later.';
        });
      }
    } catch (e) {
      setState(() {
        isLoading = false;
        message = 'An error occurred: $e';
      });
    }
  }

  @override
  void initState() {
    super.initState();
    fetchNotifications(); // Fetch the notifications when the screen loads
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('My Notifications', style: TextStyle(color: Colors.black)),
        backgroundColor: Colors.white,
        centerTitle: true,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Upcoming Notifications',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8.0),
            Expanded(
              child: isLoading
                  ? Center(child: CircularProgressIndicator())
                  : notifications.isEmpty
                      ? Center(
                          child: Text(
                            'No notifications available.',
                            style: TextStyle(fontSize: 16, color: Colors.grey),
                          ),
                        )
                      : ListView.builder(
                          itemCount: notifications.length,
                          itemBuilder: (context, index) {
                            return NotificationCard(
                              medicineName: notifications[index]['medicine_name'] ?? 'N/A',
                              timeMed: notifications[index]['time_med'] ?? 'N/A',
                              notificationId: notifications[index]['notification_id'] ?? 'N/A',
                            );
                          },
                        ),
            ),
          ],
        ),
      ),
    );
  }
}

class NotificationCard extends StatelessWidget {
  final String medicineName;
  final String timeMed;
  final String notificationId;

  NotificationCard({
    required this.medicineName,
    required this.timeMed,
    required this.notificationId,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.symmetric(vertical: 8.0),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          children: [
            Icon(Icons.notifications, size: 40, color: Colors.grey),
            SizedBox(width: 16.0),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Medicine Name: $medicineName', style: TextStyle(fontSize: 16)),
                Text('Time: $timeMed', style: TextStyle(fontSize: 16)),
                Text('Notification ID: $notificationId', style: TextStyle(fontSize: 16)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
