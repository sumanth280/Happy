import 'package:http/http.dart' as http;
import 'dart:convert';
import '/api.dart';  // Import api.dart for Analyticsurl and patient_id

// Function to fetch medicines using patient_id from api.dart
Future<Map<String, dynamic>> fetchMedicines() async {
  final url = Uri.parse(Analyticsurl); // Use Analyticsurl from api.dart

  try {
    // Send POST request with patient_id from api.dart
    final response = await http.post(
      url,
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: {
        "patient_id": patient_id, // Use the patient_id directly from api.dart
      },
    );

    // Check for success response code (200)
    if (response.statusCode == 200) {
      // Decode the JSON response
      final data = json.decode(response.body);

      // Check status in the response
      if (data['status'] == true) {
        // Medicines found, return the data
        return {
          'success': true,
          'message': data['message'],
          'medicines': data['medicines'],  // List of medicines
        };
      } else {
        // No medicines found or error in fetching
        return {
          'success': false,
          'message': data['message'],
        };
      }
    } else {
      // Handle other status codes
      return {
        'success': false,
        'message': 'Error: ${response.statusCode}',
      };
    }
  } catch (e) {
    // Handle any errors (e.g., network errors)
    return {
      'success': false,
      'message': 'An error occurred: $e',
    };
  }
}

void getMedicines() async {
  var result = await fetchMedicines();

  if (result['success']) {
    // Medicines found, handle data
    List medicines = result['medicines'];
    print('Medicines: $medicines');
  } else {
    // Error occurred or no medicines found
    print('Error: ${result['message']}');
  }
}
