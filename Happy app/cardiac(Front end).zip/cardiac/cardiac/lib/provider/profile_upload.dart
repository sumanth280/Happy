import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import '/api.dart'; // Make sure this contains Profileurl and patient_id variables

class ProfileApi {
  static Future<Map<String, dynamic>> uploadProfilePicture({
    required String patient_id,
    required File profilePicture,
  }) async {
    final uri = Uri.parse(Profileurl);

    // Prepare a multipart request to send file data
    var request = http.MultipartRequest('POST', uri)
      ..fields['patient_id'] = patient_id
      ..files.add(await http.MultipartFile.fromPath('profile_pic', profilePicture.path));

    try {
      // Send the request
      var response = await request.send();
      final responseData = await response.stream.bytesToString();
      final jsonResponse = json.decode(responseData);

      if (response.statusCode == 200) {
        return jsonResponse;
      } else {
        return {
          'status': false,
          'message': jsonResponse['message'] ?? 'Unknown error occurred',
        };
      }
    } catch (e) {
      return {
        'status': false,
        'message': 'Error uploading profile picture: $e',
      };
    }
  }
}
