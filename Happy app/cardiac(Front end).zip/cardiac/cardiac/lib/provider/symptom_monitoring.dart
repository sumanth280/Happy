import 'package:http/http.dart' as http;
import 'dart:convert';
import '/api.dart'; // Ensure Symptom_monitoringurl and Symptom_monitoringviewurl are defined here and patient_id is fetched from here

// Function to submit symptom monitoring data
Future<Map<String, dynamic>> submitSymptomMonitoring({
  required String shortnessOfBreath,
  required String cough,
  required String whileWorking,
  required String whileRest,
  required String occasional,
  required String frequent,
  required String fatigueWeakness,
  required String chestPain,
  required String palpatations,
  required String abdomenDiscomfort,
  required String confusion,
  required String weightGain,
  required String sleepDifficulty,
  required String patientId, // fetched from api.dart
}) async {
  final Map<String, dynamic> data = {
    'patient_id': patientId,
    'shortness_of_breath': shortnessOfBreath,
    'while_working': whileWorking,
    'while_rest': whileRest,
    'cough': cough,
    'occasional': occasional,
    'frequent': frequent,
    'fatigue_weakness': fatigueWeakness,
    'chest_pain': chestPain,
    'palpatations': palpatations,
    'abdomen_discomfort': abdomenDiscomfort,
    'confusion': confusion,
    'weight_gain': weightGain,
    'sleep_difficulty': sleepDifficulty,
  };

  try {
    final response = await http.post(
      Uri.parse(Symptom_monitoringurl),
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: data,
    );

    if (response.statusCode == 200) {
      final responseData = json.decode(response.body);
      return responseData;
    } else {
      return {
        'status': 'false',
        'message': 'Server returned status code ${response.statusCode}',
      };
    }
  } catch (error) {
    return {
      'status': 'false',
      'message': 'An error occurred: $error',
    };
  }
}

// Function to fetch symptom monitoring data
Future<Map<String, dynamic>> fetchSymptomMonitoring({
  required String patientId, // fetched from api.dart
}) async {
  final Map<String, dynamic> data = {
    'patient_id': patientId,
  };

  try {
    final response = await http.post(
      Uri.parse(Symptom_monitoringviewurl),
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: data,
    );

    if (response.statusCode == 200) {
      final responseData = json.decode(response.body);
      return responseData;
    } else {
      return {
        'status': 'false',
        'message': 'Server returned status code ${response.statusCode}',
      };
    }
  } catch (error) {
    return {
      'status': 'false',
      'message': 'An error occurred: $error',
    };
  }
}
