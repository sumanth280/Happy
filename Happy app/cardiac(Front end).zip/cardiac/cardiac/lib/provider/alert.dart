import 'dart:convert';
import 'package:http/http.dart' as http;
import '/api.dart'; // Ensure Createalerturl, Alertsshowurl, Markasreadurl, and patient_id are defined here

// Function to create alerts
Future<Map<String, dynamic>> createAlert() async {
  final uri = Uri.parse(Createalerturl);
  final patientId = patient_id; // Get patient_id from api.dart

  try {
    final response = await http.post(
      uri,
      body: {
        'patient_id': patientId,
      },
    );

    if (response.statusCode == 200) {
      final responseData = json.decode(response.body);

      return {
        'status': responseData['status'],
        'message': responseData['message'],
      };
    } else {
      return {
        'status': false,
        'message': 'Server returned status code ${response.statusCode}',
      };
    }
  } catch (error) {
    return {
      'status': false,
      'message': 'An error occurred: $error',
    };
  }
}

// Function to fetch alerts for a patient
Future<Map<String, dynamic>> fetchAlerts() async {
  final uri = Uri.parse(Alertsshowurl);
  final patientId = patient_id; // Get patient_id from api.dart

  try {
    final response = await http.post(
      uri,
      body: {
        'patient_id': patientId,
      },
    );

    if (response.statusCode == 200) {
      final responseData = json.decode(response.body);

      if (responseData['status'] == true) {
        return {
          'status': true,
          'data': responseData['data'], // List of alerts
        };
      } else {
        return {
          'status': false,
          'message': responseData['message'] ?? 'No alerts found',
        };
      }
    } else {
      return {
        'status': false,
        'message': 'Server returned status code ${response.statusCode}',
      };
    }
  } catch (error) {
    return {
      'status': false,
      'message': 'An error occurred: $error',
    };
  }
}

// Function to mark an alert as read
Future<Map<String, dynamic>> markAsRead(String notificationId) async {
  final uri = Uri.parse(Markasreadurl);
  final patientId = patient_id; // Get patient_id from api.dart

  try {
    final response = await http.post(
      uri,
      body: {
        'patient_id': patientId,
        'notification_id': notificationId,
      },
    );

    if (response.statusCode == 200) {
      final responseData = json.decode(response.body);

      return {
        'status': responseData['status'],
        'message': responseData['message'],
      };
    } else {
      return {
        'status': false,
        'message': 'Server returned status code ${response.statusCode}',
      };
    }
  } catch (error) {
    return {
      'status': false,
      'message': 'An error occurred: $error',
    };
  }
}
