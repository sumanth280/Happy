const ip = "180.235.121.245";
String Baseurl = "http://$ip/cardiac/";
String patient_id = "";
String name = "";
String doctor_id = "";
String doc_name = "";
//login and signup Api - patient side//
String PatientLoginurl = "http://$ip/cardiac/login_patient.php";
String PatientSignupurl = "http://$ip/cardiac/patient_signup.php";

String Patientdetailsurl = "http://$ip/cardiac/patient_profile.php";
String Patienteditprofileurl = "http://$ip/cardiac/patient_edit_profile.php";
String Changepasswordurl = "http://$ip/cardiac/change_password.php";

//patient API//
String Analyticsurl = "http://$ip/cardiac/medication.php";
String My_appointmentsurl = "http://$ip/cardiac/my_appointments.php";
String Appointmenthistoryurl = "http://$ip/cardiac/appointment_history.php";
String Profileurl = "http://$ip/cardiac/profile.php"; //profile upload//
String Profileviewurl = "http://$ip/cardiac/profile_view.php";

//Health_metrics//
String Health_metricsurl = "http://$ip/cardiac/health_metrics.php";
String Health_metricsviewurl = "http://$ip/cardiac//health_metric_doc.php";
String Healthtrendsurl="http://$ip/cardiac//health_metric_doc_7.php";
//Symptom monitoring
String Symptom_monitoringurl = "http://$ip/cardiac/symptom_monitoring.php";
String Symptom_monitoringviewurl ="http://$ip/cardiac/symptom_monitoring_doc.php";
String Symptomtrendsurl ="http://$ip/cardiac/symptom_monitoring_doc_7.php";
//Notification API//
String Add_remainderurl = "http://$ip/cardiac/add_notification.php";
String Delete_remainderurl = "http://$ip/cardiac/delete_notification.php";
String Notificationurl = "http://$ip/cardiac/show_notification.php";

//doctor API's//

//login api//
String doctorloginurl = "http://$ip/cardiac/login_doc.php";

//doctor main screens//
String homepageurl ="http://$ip/cardiac/patient_list.php"; //patient list or show all patients same api//
String My_appointments_docurl = "http://$ip/cardiac/myappointments_doc.php";
String profile_docurl = "http://$ip/cardiac/profile_view_doc.php";
String profile_upload_docurl = "http://$ip/cardiac/profile_upload_doc.php";

String Addpatienturl = "http://$ip/cardiac/addpatient.php";
String Showallurl = "http://$ip/cardiac/profile_upload_doc.php";

// doctor profile,passwords//
String Change_password_docurl = "http://$ip/cardiac/change_password_doc.php";
String editprofile_docurl ="http://$ip/cardiac/doctor_profile.php"; //profile editing//
String mydetails_docurl = "http://$ip/cardiac/doctor_profile_view.php";

//medication api//
String Add_medicineurl = "http://$ip/cardiac/add_medicine.php";
String Delete_medicineurl ="http://$ip/cardiac/delete_medicine.php"; 
// addition and deletion both in medication api file//
//for fetching medicine using Analyticsurl only//

//appointments//
//using same api for appointments fetching and appointmenthistory fetching//
String Bookappointmenturl = "http://$ip/cardiac/appointment_book.php";

//risk stratistification//
String Risk_primaryurl = "http://$ip/cardiac/risk_primary.php";
String Risk_minorurl = "http://$ip/cardiac/risk_minor.php";
String Risk_majorurl = "http://$ip/cardiac/risk_major.php";
//risk view//
String Risk_primaryviewurl = "http://$ip/cardiac/risk_primary_view.php";
String Risk_minorviewurl = "http://$ip/cardiac/risk_minor_view.php";
String Risk_majorviewurl = "http://$ip/cardiac/risk_major_view.php";

//investigation//
String Investigation_routinesurl ="http://$ip/cardiac/investigation_routines.php";
String Investigation_specialurl ="http://$ip/cardiac/investigation_special.php";
//investigation view//
String Routines_viewurl = "http://$ip/cardiac/investigation_routines_view.php";
String Special_viewurl = "http://$ip/cardiac/investigation_special_view.php";
//investigation casesheets//
String Routines_casesheeturl = "http://$ip/cardiac/routines_casesheet.php";
String Special_casesheeturl = "http://$ip/cardiac/special_casesheet.php";

//download api//
String Downloadurl = "http://$ip/cardiac/download.php";

//Alerts url//
String Createalerturl = "http://$ip/cardiac/notificationread.php";
String Alertsshowurl = "http://$ip/cardiac/alertsshow.php";
String Markasreadurl = "http://$ip/cardiac/markasread.php";