import 'dart:convert';
import 'package:http/http.dart' as http;
import '/api.dart';  // Ensure Addpatienturl is correctly imported

Future<Map<String, dynamic>> addPatient({
  required String name,
  required String age,
  required String gender,
  required String phoneNumber,
  required String profession,
  String? doctorId,  // Optional doctor_id header
}) async {
  try {
    final Map<String, String> body = {
      'name': name,
      'age': age, // Expected format: YYYY-MM-DD
      'gender': gender,
      'phone_number_1': phoneNumber,
      'profession': profession,
    };

    // Headers may include an optional doctor_id if the backend requires it
    final headers = {
      'Content-Type': 'application/x-www-form-urlencoded',
      if (doctorId != null) 'doctor_id': doctorId,  // Only include if doctorId is provided
    };

    final response = await http.post(
      Uri.parse(Addpatienturl),
      headers: headers,
      body: body,
    );

    if (response.statusCode == 200) {
      final Map<String, dynamic> responseData = json.decode(response.body);
      if (responseData['status'] == true) {
        return {
          'status': true,
          'message': responseData['message'],
          'patient_id': responseData['patient_id'],
        };
      } else {
        return {'status': false, 'message': responseData['message']};
      }
    } else {
      return {
        'status': false,
        'message': 'Server error: ${response.statusCode}',
      };
    }
  } catch (e) {
    return {'status': false, 'message': 'An error occurred: $e'};
  }
}
