import 'dart:convert';
import 'package:http/http.dart' as http;
import '/api.dart'; // Ensure the URLs for Risk_primaryviewurl and Risk_primaryurl are defined here

// Fetch Risk Primary Data
Future<Map<String, dynamic>> fetchRiskPrimaryData(String patientId) async {
  final uri = Uri.parse(Risk_primaryviewurl); // Ensure Risk_primaryviewurl is correctly defined in your API

  try {
    final response = await http.post(
      uri,
      body: {
        'patient_id': patientId,
      },
    );

    if (response.statusCode == 200) {
      final responseData = json.decode(response.body);

      if (responseData['status'] == true) {
        return {
          'status': true,
          'message': responseData['message'] ?? 'Data retrieved successfully',
          'data': responseData['data'],
        };
      } else {
        return {
          'status': false,
          'message': responseData['message'] ?? 'Error retrieving data',
        };
      }
    } else {
      return {
        'status': false,
        'message': 'Server returned status code ${response.statusCode}',
      };
    }
  } catch (error) {
    return {
      'status': false,
      'message': 'An error occurred: $error',
    };
  }
}

// Update or Insert Risk Primary Data
Future<Map<String, dynamic>> updateOrInsertRiskPrimaryData({
  required String patientId,
  required String age,
  required String gender,
  required String bmi,
  required String sbp,
  required String creatinine,
  required String currentSmoker,
  required String Diabetes,
  required String heartFailure,
  required String betaBlockers,
  required String aceiArb,
  required String nyha,
}) async {
  final uri = Uri.parse(Risk_primaryurl); // Ensure Risk_primaryurl is correctly defined in your API

  try {
    final response = await http.post(
      uri,
      body: {
        'patient_id': patientId,
        'age': age,
        'gender': gender,
        'bmi': bmi,
        'sbp': sbp,
        'creatinine': creatinine,
        'current_smoker': currentSmoker,
        'diabetes': Diabetes,
        'heart_failure': heartFailure,
        'beta_blockers': betaBlockers,
        'acei_arb': aceiArb,
        'nyha': nyha,
      },
    );

    if (response.statusCode == 200) {
      final responseData = json.decode(response.body);
      return {
        'status': responseData['status'],
        'message': responseData['message'] ?? 'Data saved successfully',
      };
    } else {
      return {
        'status': false,
        'message': 'Server returned status code ${response.statusCode}',
      };
    }
  } catch (error) {
    return {
      'status': false,
      'message': 'An error occurred: $error',
    };
  }
}
