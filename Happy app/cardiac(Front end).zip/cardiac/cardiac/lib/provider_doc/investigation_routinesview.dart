import 'dart:convert';
import '/api.dart';
import 'package:http/http.dart' as http;

Future<Map<String, dynamic>> fetchInvestigationRoutineData(String casesheetId) async {
  final uri = Uri.parse(Routines_viewurl); // Use the correct URL from api.dart

  // Retrieve patient_id from api.dart
  String patientId = patient_id; // Assuming patient_id is stored in api.dart

  try {
    // Make the POST request to the PHP API
    final response = await http.post(
      uri,
      body: {
        'patient_id': patientId,
        'casesheet_id': casesheetId,
      },
    );

    // Check if the response status code is 200 (OK)
    if (response.statusCode == 200) {
      final responseData = json.decode(response.body);

      // Check if the response contains data
      if (responseData['status'] == true) {
        return {
          'status': true,
          'message': responseData['message'],
          'data': responseData['data'], // Return the entire data array
        };
      } else {
        return {
          'status': false,
          'message': responseData['message'] ?? 'No message available',
        };
      }
    } else {
      return {
        'status': false,
        'message': 'Server returned status code ${response.statusCode}',
      };
    }
  } catch (error) {
    return {
      'status': false,
      'message': 'An error occurred: $error',
    };
  }
}
