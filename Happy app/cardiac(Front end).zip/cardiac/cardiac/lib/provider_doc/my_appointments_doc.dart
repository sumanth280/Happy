import 'dart:convert';
import 'package:http/http.dart' as http;
import '/api.dart'; // Ensure this imports your api.dart file

Future<void> fetchAppointmentsForDoctor() async {
  try {
    // Access doctor_id directly from api.dart
    String doctorId = doctor_id; // Assuming api.dart has a variable named doctorId

    // Define the API URL
    String apiUrl = My_appointments_docurl;

    // Prepare the headers
    Map<String, String> headers = {
      "Content-Type": "application/json",
    };

    // Prepare the body with doctor_id
    Map<String, dynamic> body = {
      'doctor_id': doctorId, // Send doctor_id in the request body
    };

    // Send the POST request
    final response = await http.post(
      Uri.parse(apiUrl),
      headers: headers,
      body: json.encode(body), // Convert the body to JSON format
    );

    // Check the response status
    if (response.statusCode == 200) {
      var data = json.decode(response.body);

      // Handle the response data
      if (data['status'] == true) {
        List appointments = data['data'];
        if (appointments.isNotEmpty) {
          print("Appointments for today:");
          for (var appointment in appointments) {
            print("Name: ${appointment['name']}");
            print("Time: ${appointment['time']}");
            print("Phone: ${appointment['phone_number']}");
            print("Profile Pic: ${appointment['profile_pic']}");
          }
        } else {
          print(data['message']);
        }
      } else {
        print('Error: ${data['message']}');
      }
    } else {
      print('Failed to load appointments. Status code: ${response.statusCode}');
    }
  } catch (e) {
    print('Error occurred: $e');
  }
}
