import 'package:http/http.dart' as http;
import 'dart:convert';
import '/api.dart'; // Import api.dart for the patient_id and API URL

// Function to fetch investigation routines using patient_id from api.dart
Future<Map<String, dynamic>> fetchInvestigationRoutines() async {
  final url = Uri.parse(Routines_casesheeturl); // Use Routines_casesheeturl from api.dart

  try {
    // Send POST request with patient_id from api.dart
    final response = await http.post(
      url,
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: {
        "patient_id": patient_id, // Use the patient_id directly from api.dart
      },
    );

    print("Raw API Response: ${response.body}");

    // Check for success response code (200)
    if (response.statusCode == 200) {
      // Decode the JSON response
      final data = json.decode(response.body);

      // Check status in the response
      if (data['status'] == true) {
        // Data fetched successfully, return the data
        return {
          'success': true,
          'message': data['message'],
          'data': data['data'], // List of investigation routines
        };
      } else {
        // No data found or error in fetching
        return {
          'success': false,
          'message': data['message'],
        };
      }
    } else {
      // Handle other status codes
      return {
        'success': false,
        'message': 'Error: ${response.statusCode}',
      };
    }
  } catch (e) {
    // Handle any errors (e.g., network errors)
    return {
      'success': false,
      'message': 'An error occurred: $e',
    };
  }
}
