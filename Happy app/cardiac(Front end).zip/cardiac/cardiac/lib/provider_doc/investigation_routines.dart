import 'dart:convert';
import 'package:http/http.dart' as http;
import '/api.dart'; // Import your API file where URLs and patient_id are defined

Future<Map<String, dynamic>> addInvestigationRoutine({
  required String? cbcHb,
  required String? cbcTlc,
  required String? rftCreatinine,
  required String? sgot,
  required String? sgpt,
  required String? totalBilirubin,
  required String? sodium,
  required String? potassium,
  required String? chloride,
  required String sodiumBicarbonate,
}) async {
  // Ensure patient_id is defined in api.dart
  String patientId = patient_id;

  // Prepare the request body
  Map<String, String> requestBody = {
    'patient_id': patientId,
    'cbc_hb': cbcHb ?? '',
    'cbc_tlc': cbcTlc ?? '',
    'rft_creatinine': rftCreatinine ?? '',
    'sgot': sgot ?? '',
    'sgpt': sgpt ?? '',
    'total_bilibubin': totalBilirubin ?? '',
    'sodium': sodium ?? '',
    'pottasium': potassium ?? '',
    'chloride': chloride ?? '',
    'sodium_bicarbonate': sodiumBicarbonate,
  };

  try {
    // Send POST request
    final response = await http.post(
      Uri.parse(Investigation_routinesurl), // Replace with your API URL
      body: requestBody,
    );

    // Handle the response
    if (response.statusCode == 200) {
      Map<String, dynamic> jsonResponse = json.decode(response.body);
      return {
        'status': jsonResponse['status'] ?? false,
        'message': jsonResponse['message'] ?? 'Something went wrong',
        'casesheet_id': jsonResponse['casesheet_id'], // Retrieve casesheet_id if available
      };
    } else {
      return {
        'status': false,
        'message': 'Failed to communicate with the server.',
      };
    }
  } catch (e) {
    return {
      'status': false,
      'message': 'An error occurred: $e',
    };
  }
}
