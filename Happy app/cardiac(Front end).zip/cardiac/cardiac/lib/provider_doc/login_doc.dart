import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../doctor/home_doc.dart';
import '/api.dart';

Future<Map<String, dynamic>> doctorLogin(
    String doctorId, String password, BuildContext context) async {
  final url = Uri.parse(doctorloginurl); // Replace with your actual server URL

  try {
    // Send POST request with doctor ID and password as body
    final response = await http.post(
      url,
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: {
        "doctor_id": doctorId,
        "password": password,
      },
    );

    // Check for success response code (200)
    if (response.statusCode == 200) {
      // Decode JSON response
      final data = json.decode(response.body);
      // Check status in response and return data accordingly
      if (data["status"] == true) {
        // Assign doctor-specific data
        doctor_id = data["data"]["doctor_id"];
        doc_name = data["data"]["doc_name"];
        
        print(doctor_id);
        print(doc_name);

        // Navigate to HomeScreen on successful login
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => Home_doc()), // Replace with your HomeScreen widget
        );

        return {
          "success": true,
          "message": data["message"],
        };
      } else {
        // Handle login failure and show error message
        String errorMessage = data["message"] ?? "Unknown error";
        
        // Check if error is due to incorrect credentials
        if (errorMessage.contains("Invalid doctor_id") || errorMessage.contains("Invalid password")) {
          _showErrorDialog(context, "Invalid doctor ID or password. Please try again.");
        } else {
          _showErrorDialog(context, errorMessage);
        }

        return {
          "success": false,
          "message": errorMessage,
        };
      }
    } else {
      // Handle other status codes
      _showErrorDialog(context, "Error: ${response.statusCode}");
      return {
        "success": false,
        "message": "Error: ${response.statusCode}",
      };
    }
  } catch (e) {
    // Handle any errors (e.g., network errors)
    _showErrorDialog(context, "An error occurred: $e");
    return {
      "success": false,
      "message": "An error occurred: $e",
    };
  }
}

// Function to show error dialog
void _showErrorDialog(BuildContext context, String message) {
  showDialog(
    context: context,
    builder: (context) => AlertDialog(
      title: Text("Login Failed"),
      content: Text(message),
      actions: [
        TextButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          child: Text("OK"),
        ),
      ],
    ),
  );
}
