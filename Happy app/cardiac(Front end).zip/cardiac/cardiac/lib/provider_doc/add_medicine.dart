import 'package:http/http.dart' as http;
import 'dart:convert';
import '/api.dart'; // Import for Add_medicineurl and patient_id

Future<Map<String, dynamic>> addMedicine({
  required String medicineName,
  required String dosage,
  required String days,
  required bool morning,
  required bool afternoon,
  required bool night,
  required bool beforeFood,
  required bool afterFood,
  required String comments,
}) async {
  final url = Uri.parse(Add_medicineurl); // URL for the API endpoint

  try {
    // Preparing the POST request
    final response = await http.post(
      url,
      headers: {"Content-Type": "application/x-www-form-urlencoded"},
      body: {
        "patient_id": patient_id, // Fetch patient_id directly from api.dart
        "medicine_name": medicineName,
        "dosage": dosage,
        "days": days,
        "morning": morning ? "yes" : "no",
        "afternoon": afternoon ? "yes" : "no",
        "night": night ? "yes" : "no",
        "before_food": beforeFood ? "yes" : "no",
        "after_food": afterFood ? "yes" : "no",
        "comments": comments,
      },
    );

    // Parse the response
    if (response.statusCode == 200) {
      final data = json.decode(response.body);

      if (data['status'] == true) {
        return {
          'success': true,
          'message': data['message'],
          'medicine_id': data['medicine_id'],
        };
      } else {
        return {
          'success': false,
          'message': data['message'],
        };
      }
    } else {
      return {
        'success': false,
        'message': 'Error: ${response.statusCode}',
      };
    }
  } catch (e) {
    // Handle exceptions
    return {
      'success': false,
      'message': 'An error occurred: $e',
    };
  }
}
