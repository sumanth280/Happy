import 'dart:convert';
import 'package:http/http.dart' as http;
import '/api.dart'; // Ensure the URLs for Risk_majorviewurl and Risk_majorurl are defined here

// Fetch Risk Major Data
Future<Map<String, dynamic>> fetchRiskMajorData(String patientId) async {
  final uri = Uri.parse(Risk_majorviewurl); // Ensure Risk_majorviewurl is correctly defined in your API

  try {
    // Make the POST request with the patient_id
    final response = await http.post(
      uri,
      body: {
        'patient_id': patientId,
      },
    );

    // Check if the response status code is 200 (OK)
    if (response.statusCode == 200) {
      final responseData = json.decode(response.body);

      // Check if the response indicates success
      if (responseData['status'] == true) {
        return {
          'status': true,
          'message': responseData['message'] ?? 'Data retrieved successfully',
          'data': responseData['data'], // The actual data of the risk_major
        };
      } else {
        return {
          'status': false,
          'message': responseData['message'] ?? 'Error retrieving data',
        };
      }
    } else {
      return {
        'status': false,
        'message': 'Server returned status code ${response.statusCode}',
      };
    }
  } catch (error) {
    return {
      'status': false,
      'message': 'An error occurred: $error',
    };
  }
}

// Update or Insert Risk Major Data
Future<Map<String, dynamic>> updateOrInsertRiskMajorData({
  required String patientId,
  required String acutePulmonaryEdema,
  required String cardiomegaly,
  required String hepatojugularReflex,
  required String neckVeinDistension,
  required String pndOrthopnea,
  required String pulmonaryRales,
  required String thirdHeartSoundS3,
  required String responseToTreatment,
}) async {
  final uri = Uri.parse(Risk_majorurl); // Ensure Risk_majorurl is correctly defined in your API

  try {
    // Make the POST request with all necessary data
    final response = await http.post(
      uri,
      body: {
        'patient_id': patientId,
        'acute_pulmonary_edema': acutePulmonaryEdema,
        'cardiomegaly': cardiomegaly,
        'hepatojugular_reflex': hepatojugularReflex,
        'neck_vein_distension': neckVeinDistension,
        'pnd_orthopnea': pndOrthopnea,
        'pulmonary_rales': pulmonaryRales,
        'third_heartsound_s3': thirdHeartSoundS3,
        'response_to_treatment': responseToTreatment,
      },
    );

    // Check if the response status code is 200 (OK)
    if (response.statusCode == 200) {
      final responseData = json.decode(response.body);

      // Check if the response indicates success
      if (responseData['status'] == true) {
        return {
          'status': true,
          'message': responseData['message'] ?? 'Data updated/inserted successfully',
        };
      } else {
        return {
          'status': false,
          'message': responseData['message'] ?? 'Error processing data',
        };
      }
    } else {
      return {
        'status': false,
        'message': 'Server returned status code ${response.statusCode}',
      };
    }
  } catch (error) {
    return {
      'status': false,
      'message': 'An error occurred: $error',
    };
  }
}
