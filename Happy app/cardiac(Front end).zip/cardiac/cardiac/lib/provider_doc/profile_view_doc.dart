import 'dart:convert';
import 'package:http/http.dart' as http;
import '/api.dart'; // Ensure profile_docurl and doctor_id are defined here

Future<Map<String, dynamic>> fetchDoctorProfile(String doctor_id) async {
  final uri = Uri.parse(profile_docurl); // Ensure the profile_docurl is correctly defined in your API

  try {
    // Make the POST request with the doctor_id
    final response = await http.post(
      uri,
      body: {
        'doctor_id': doctor_id,
      },
    );

    // Check if the response status code is 200 (OK)
    if (response.statusCode == 200) {
      final responseData = json.decode(response.body);

      // Check if the response indicates success
      if (responseData['status'] == true) {
        return {
          'status': true,
          'doctor_id': doctor_id,
          'doc_name': responseData['doc_name'] ?? 'No Name Data', // doc_name
          'profile_doc': responseData['profile_doc'] ?? 'No Profile Data', // profile_doc
        };
      } else {
        return {
          'status': false,
          'message': responseData['message'] ?? 'Error retrieving data',
        };
      }
    } else {
      return {
        'status': false,
        'message': 'Server returned status code ${response.statusCode}',
      };
    }
  } catch (error) {
    return {
      'status': false,
      'message': 'An error occurred: $error',
    };
  }
}
