import 'dart:convert';
import 'package:http/http.dart' as http;
import '/api.dart'; // Assuming this contains Bookappointmenturl and patient_id

Future<Map<String, dynamic>> bookAppointment({
  required String date,
  required String time,
  required String comment,
}) async {
  try {
    // Fetch patient_id from api.dart
    final String patientId = patient_id;

    // Prepare the POST request body
    final Map<String, String> requestBody = {
      'patient_id': patientId,
      'date': date,
      'time': time,
      'comment': comment,
    };

    // Make the POST request
    final response = await http.post(
      Uri.parse(Bookappointmenturl),
      body: requestBody,
    );

    // Check for a successful response
    if (response.statusCode == 200) {
      // Parse the JSON response
      final Map<String, dynamic> responseData = json.decode(response.body);

      // Return the parsed response
      return responseData;
    } else {
      // Handle unexpected server errors
      return {
        "status": false,
        "message": "Server error: ${response.statusCode}",
      };
    }
  } catch (e) {
    // Handle network or parsing errors
    return {
      "status": false,
      "message": "An error occurred: $e",
    };
  }
}
