import 'dart:convert';
import 'package:http/http.dart' as http;
import '/api.dart'; // Ensure the URLs for Risk_minorviewurl and Risk_minorurl are defined here

// Fetch Risk Minor Data
Future<Map<String, dynamic>> fetchRiskMinorData(String patientId) async {
  final uri = Uri.parse(Risk_minorviewurl); // Ensure Risk_minorviewurl is correctly defined in your API

  try {
    final response = await http.post(
      uri,
      body: {
        'patient_id': patientId,
      },
    );

    if (response.statusCode == 200) {
      final responseData = json.decode(response.body);

      if (responseData['status'] == true) {
        return {
          'status': true,
          'message': responseData['message'] ?? 'Data retrieved successfully',
          'data': responseData['data'],
        };
      } else {
        return {
          'status': false,
          'message': responseData['message'] ?? 'Error retrieving data',
        };
      }
    } else {
      return {
        'status': false,
        'message': 'Server returned status code ${response.statusCode}',
      };
    }
  } catch (error) {
    return {
      'status': false,
      'message': 'An error occurred: $error',
    };
  }
}

// Update or Insert Risk Minor Data
Future<Map<String, dynamic>> updateOrInsertRiskMinorData({
  required String patientId,
  required String ankleEdema,
  required String dyspneaOnExertion,
  required String hapatomegaly,
  required String nocturnalCough,
  required String pleuralEffusion,
  required String tachycardiaHr,
}) async {
  final uri = Uri.parse(Risk_minorurl); // Ensure Risk_minorurl is correctly defined in your API

  try {
    final response = await http.post(
      uri,
      body: {
        'patient_id': patientId,
        'ankle_edema': ankleEdema,
        'dyspnea_on_exertion': dyspneaOnExertion,
        'hapatomegaly': hapatomegaly,
        'nocturnal_cough': nocturnalCough,
        'pleural_effusion': pleuralEffusion,
        'tachycardia_hr': tachycardiaHr,
      },
    );

    if (response.statusCode == 200) {
      final responseData = json.decode(response.body);
      return {
        'status': responseData['status'],
        'message': responseData['message'] ?? 'Data saved successfully',
      };
    } else {
      return {
        'status': false,
        'message': 'Server returned status code ${response.statusCode}',
      };
    }
  } catch (error) {
    return {
      'status': false,
      'message': 'An error occurred: $error',
    };
  }
}
