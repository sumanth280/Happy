import 'dart:typed_data';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import '/api.dart';

Future<void> downloadPatientData(String patientId) async {
  try {
    // Send POST request to PHP API with the patient_id
    final response = await http.post(
      Uri.parse(Downloadurl),
      body: {'patient_id': patientId},
    );

    if (response.statusCode == 200) {
      // Check if the response is a valid CSV file (instead of JSON)
      if (response.headers['content-type']?.contains('csv') == true) {
        // Prepare file path to save the CSV
        final fileName = 'patient_data_$patientId.csv';
        final directory = await getApplicationDocumentsDirectory();
        final filePath = '${directory.path}/$fileName';

        // Save the CSV data as a file
        final file = File(filePath);
        await file.writeAsBytes(response.bodyBytes);

        print('File saved to $filePath');
      } else {
        // Handle the case if the response is not a CSV
        print('Error: The server did not return a CSV file.');
      }
    } else {
      print('Request failed with status: ${response.statusCode}');
    }
  } catch (error) {
    print('Error: $error');
  }
}
