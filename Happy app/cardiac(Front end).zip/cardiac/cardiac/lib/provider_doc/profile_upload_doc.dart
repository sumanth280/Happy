import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import '/api.dart'; // Make sure this contains profile_upload_docurl and doctor_id variables

class DoctorProfileApi {
  static Future<Map<String, dynamic>> uploadDoctorProfileDocument({
    required String doctor_id,
    required File profileDoc,
  }) async {
    final uri = Uri.parse(profile_upload_docurl);

    // Prepare a multipart request to send file data
    var request = http.MultipartRequest('POST', uri)
      ..fields['doctor_id'] = doctor_id
      ..files.add(await http.MultipartFile.fromPath('profile_doc', profileDoc.path));

    try {
      // Send the request
      var response = await request.send();
      final responseData = await response.stream.bytesToString();
      final jsonResponse = json.decode(responseData);

      if (response.statusCode == 200) {
        return jsonResponse;
      } else {
        return {
          'status': false,
          'message': jsonResponse['message'] ?? 'Unknown error occurred',
        };
      }
    } catch (e) {
      return {
        'status': false,
        'message': 'Error uploading profile document: $e',
      };
    }
  }
}
