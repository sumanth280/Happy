import 'dart:convert';
import 'package:http/http.dart' as http;
import '/api.dart'; // Assuming this file contains patient_id and Special_casesheeturl

// Function to fetch special casesheets using patient_id
Future<Map<String, dynamic>> fetchSpecialCasesheets() async {
  final url = Uri.parse(Special_casesheeturl); // Special_casesheeturl from api.dart
  final patientId = patient_id; // patient_id from api.dart

  try {
    // Make a POST request with the patient_id
    final response = await http.post(
      url,
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: {
        'patient_id': patientId,
      },
    );

    print("Raw API Response: ${response.body}");

    // Parse the response body
    final responseData = json.decode(response.body);

    if (response.statusCode == 200 && responseData['status'] == true) {
      // Success
      return {
        'success': true,
        'message': responseData['message'],
        'data': responseData['data'], // List of special casesheets
      };
    } else {
      // API failed or no data found
      return {
        'success': false,
        'message': responseData['message'] ?? 'Unknown error occurred.',
      };
    }
  } catch (e) {
    // Handle exceptions, e.g., network or decoding errors
    return {
      'success': false,
      'message': 'An error occurred: $e',
    };
  }
}
