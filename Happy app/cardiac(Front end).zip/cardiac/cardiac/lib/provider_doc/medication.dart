import 'package:http/http.dart' as http;
import 'dart:convert';
import '/api.dart'; // Import the constants like `Analyticsurl`, `Delete_medicineurl`, and `patient_id`

/// Fetch medicines for the patient
Future<Map<String, dynamic>> fetchMedicines() async {
  final url = Uri.parse(Analyticsurl);
  try {
    final response = await http.post(
      url,
      headers: {"Content-Type": "application/x-www-form-urlencoded"},
      body: {"patient_id": patient_id}, // Use `patient_id` from `api.dart`
    );

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      if (data['status'] == true) {
        return {'success': true, 'medicines': data['medicines']};
      }
      return {'success': false, 'message': data['message']};
    }
    return {'success': false, 'message': 'Error: ${response.statusCode}'};
  } catch (e) {
    return {'success': false, 'message': 'An error occurred: $e'};
  }
}

/// Delete a specific medicine by its ID
Future<Map<String, dynamic>> deleteMedicineApi(String medicineId) async {
  final url = Uri.parse(Delete_medicineurl);
  try {
    print('Deleting medicine with ID: $medicineId for patient: $patient_id');
    final response = await http.post(
      url,
      headers: {"Content-Type": "application/x-www-form-urlencoded"},
      body: {
        "patient_id": patient_id, // Use `patient_id` from `api.dart`
        "medicine_id": medicineId, // Medicine ID for deletion
      },
    );

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      if (data['status'] == true) {
        return {'success': true, 'message': data['message']};
      }
      return {'success': false, 'message': data['message']};
    }
    return {'success': false, 'message': 'Error: ${response.statusCode}'};
  } catch (e) {
    return {'success': false, 'message': 'An error occurred: $e'};
  }
}
