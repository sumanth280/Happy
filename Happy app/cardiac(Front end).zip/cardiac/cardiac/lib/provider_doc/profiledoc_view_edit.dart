import 'package:http/http.dart' as http;
import 'dart:convert';
import '/api.dart'; // Ensure this imports mydetails_docurl, editprofile_docurl, and doctor_id

/// Function to fetch doctor details
Future<Map<String, dynamic>> fetchDoctorDetails() async {
  final response = await http.post(
    Uri.parse(mydetails_docurl),
    body: {'doctor_id': doctor_id},
  );

  if (response.statusCode == 200) {
    final data = json.decode(response.body);
    if (data['status'] == true) {
      return data['data']; // Returns the doctor details as a Map
    } else {
      throw Exception(data['message']); // Error from API
    }
  } else {
    throw Exception('Failed to fetch doctor details'); // HTTP error
  }
}

/// Function to edit doctor profile details
Future<bool> editDoctorProfile({
  required String name,
  required String age,
  required String gender,
  required String phoneNumber,
  required String address,
}) async {
  final response = await http.post(
    Uri.parse(editprofile_docurl),
    body: {
      'doctor_id': doctor_id,
      'doc_name': name,
      'age': age,
      'gender': gender,
      'phone_number': phoneNumber,
      'address': address,
    },
  );

  if (response.statusCode == 200) {
    final data = json.decode(response.body);
    return data['status'] == true; // Returns true if update is successful
  } else {
    throw Exception('Failed to update doctor profile'); // HTTP error
  }
}
