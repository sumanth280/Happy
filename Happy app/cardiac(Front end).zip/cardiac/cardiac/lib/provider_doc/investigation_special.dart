import 'dart:convert';
import 'package:http/http.dart' as http;
import '/api.dart'; // Import your API file where URLs and patient_id are defined

Future<Map<String, dynamic>> addInvestigationSpecial({
  required String? h1ba1c,
  required String? triglycerides,
  required String? ldl,
  required String? hdl,
  required String? bnp,
  required String? tsh,
  required String? ft3,
  required String? ft4,
  required String? ecgFindings,
  required String? echoFindings,
  required String? usgAbdomenFindings,
  required String? stage,
}) async {
  // Ensure patient_id is defined in api.dart
  String patientId = patient_id;

  // Prepare the request body
  Map<String, String> requestBody = {
    'patient_id': patientId,
    'h1ba1c': h1ba1c ?? '',
    'triglycerides': triglycerides ?? '',
    'ldl': ldl ?? '',
    'hdl': hdl ?? '',
    'bnp': bnp ?? '',
    'tsh': tsh ?? '',
    'ft3': ft3 ?? '',
    'ft4': ft4 ?? '',
    'ecg_findings': ecgFindings ?? '',
    'echo_findings': echoFindings ?? '',
    'usg_abdomen_findings': usgAbdomenFindings ?? '',
    'stage': stage ?? '',
  };

  try {
    // Send POST request
    final response = await http.post(
      Uri.parse(Investigation_specialurl), // Replace with your API URL
      body: requestBody,
    );

    // Handle the response
    if (response.statusCode == 200) {
      Map<String, dynamic> jsonResponse = json.decode(response.body);
      return {
        'status': jsonResponse['success'] ?? false,
        'message': jsonResponse['message'] ?? 'Something went wrong',
        'special_casesheet_id': jsonResponse['special_casesheet_id'], // Retrieve special_casesheet_id if available
      };
    } else {
      return {
        'status': false,
        'message': 'Failed to communicate with the server.',
      };
    }
  } catch (e) {
    return {
      'status': false,
      'message': 'An error occurred: $e',
    };
  }
}
