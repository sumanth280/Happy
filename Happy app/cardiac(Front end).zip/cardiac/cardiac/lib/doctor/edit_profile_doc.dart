import '/provider/profile_edit_view.dart';
import '/provider_doc/profiledoc_view_edit.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '/api.dart';
import 'profile_doc.dart';
import 'dart:async';

class _PatientEditProfileState extends State<PatientEditProfile> {
  // Text controllers for form fields
  TextEditingController nameController = TextEditingController();
  TextEditingController ageController = TextEditingController();
  TextEditingController genderController = TextEditingController();
  TextEditingController phone1Controller = TextEditingController();
  TextEditingController addressController = TextEditingController();
  TextEditingController doctorIdController = TextEditingController();

  bool isEditing = false;
  String selectedGender = 'Male'; // Default gender

  @override
  void initState() {
    super.initState();
    _fetchDoctorDetails(); // Fetch doctor details on page load
  }

  // Fetches doctor details and populates the form fields
  Future<void> _fetchDoctorDetails() async {
    try {
      final doctorDetails = await fetchDoctorDetails();
      print(doctorDetails);

      setState(() {
        doctorIdController.text = doctorDetails['doctor_id'] ?? ''; // Lock doctor ID
        nameController.text = doctorDetails['doc_name'] ?? '';
        ageController.text = doctorDetails['age'] ?? '';
        selectedGender = doctorDetails['gender'] ?? 'Male';
        phone1Controller.text = doctorDetails['phone_number'] ?? '';
        addressController.text = doctorDetails['address'] ?? '';
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed to fetch doctor details')));
    }
  }

  // Calls the editDoctorProfile API to save profile changes
  Future<void> _saveProfile() async {
    try {
      bool isSuccess = await editDoctorProfile(
        name: nameController.text,
        age: ageController.text,
        gender: selectedGender,
        phoneNumber: phone1Controller.text,
        address: addressController.text,
      );
      if (isSuccess) {
        _showSuccessPopup(context);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed to update profile')));
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed to update profile')));
    }
  }

  // Success popup dialog
  void _showSuccessPopup(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Details Updated Successfully'),
          content: Text('Your details have been updated successfully!'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                Navigator.pop(context);
              },
              child: Text('Done'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('My Details'),
            IconButton(
              icon: Icon(Icons.edit),
              onPressed: () {
                setState(() {
                  isEditing = !isEditing; // Toggle editing mode
                });
              },
            ),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            _buildLockedTextField('Doctor ID', doctorIdController, 'Doctor ID'),
            _buildTextField('Name', nameController, 'Enter Name'),
            _buildTextField('Age', ageController, 'Enter Age'),
            _buildGenderDropdown(),
            _buildTextField('Phone Number', phone1Controller, 'Enter Phone Number'),
            _buildTextField('Address', addressController, 'Enter Address'),
            if (isEditing)
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.black, // Set button color to black
                ),
                onPressed: _saveProfile,
                child: Text('Save'),
              ),
          ],
        ),
      ),
    );
  }

  // Locked text field for Doctor ID
  Widget _buildLockedTextField(String label, TextEditingController controller, String hint) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: TextField(
        controller: controller,
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          border: OutlineInputBorder(),
        ),
        enabled: false, // Lock this field
      ),
    );
  }

  // Gender dropdown menu
  Widget _buildGenderDropdown() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: DropdownButtonFormField<String>(
        value: selectedGender,
        items: <String>['Male', 'Female', 'Other']
            .map((String value) => DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                ))
            .toList(),
        onChanged: isEditing
            ? (String? newValue) {
                setState(() {
                  selectedGender = newValue!;
                });
              }
            : null, // Disable dropdown when not editing
        decoration: InputDecoration(
          labelText: 'Gender',
          border: OutlineInputBorder(),
        ),
      ),
    );
  }

  // General text field builder
  Widget _buildTextField(String label, TextEditingController controller, String hint) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: TextField(
        controller: controller,
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          border: OutlineInputBorder(),
        ),
        enabled: isEditing, // Enable only when editing
      ),
    );
  }
}

class PatientEditProfile extends StatefulWidget {
  @override
  _PatientEditProfileState createState() => _PatientEditProfileState();
}
