import '/doctor/casesheet.dart';
import '/provider_doc/patientlist.dart';
import 'package:flutter/material.dart';
import '/api.dart'; // Import api.dart for the Base URL

class AllpatientListScreen extends StatefulWidget {
  @override
  _AllpatientListScreenState createState() => _AllpatientListScreenState();
}

class _AllpatientListScreenState extends State<AllpatientListScreen> {
  late Future<Map<String, dynamic>> _futurePatients;
  String _searchQuery = '';

  @override
  void initState() {
    super.initState();
    _futurePatients = fetchPatientData();
  }

  void _filterPatients(String query) {
    setState(() {
      _searchQuery = query.toLowerCase();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Patient List'),
        centerTitle: true, // Center the title
      ),
      body: Column(
        children: [
          // Search bar
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              onChanged: _filterPatients,
              decoration: InputDecoration(
                labelText: 'Search by Name or Patient ID',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8.0),
                ),
              ),
            ),
          ),
          Expanded(
            child: FutureBuilder<Map<String, dynamic>>(
              future: _futurePatients,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(child: CircularProgressIndicator());
                } else if (snapshot.hasError) {
                  return Center(
                    child: Text(
                      'Error: ${snapshot.error}',
                      style: TextStyle(fontSize: 18, color: Colors.red),
                    ),
                  );
                } else if (!snapshot.hasData ||
                    snapshot.data!['data'] == null ||
                    snapshot.data!['data'].isEmpty) {
                  return Center(
                    child: Text(
                      'No patient data available.',
                      style: TextStyle(fontSize: 18, color: Colors.grey),
                    ),
                  );
                } else {
                  final patients = snapshot.data!['data']
                      .where((patient) =>
                          (patient['name'] != null &&
                              patient['name']
                                  .toLowerCase()
                                  .contains(_searchQuery)) ||
                          (patient['patient_id'] != null &&
                              patient['patient_id']
                                  .toString()
                                  .contains(_searchQuery)))
                      .toList();
                  return ListView.builder(
                    itemCount: patients.length,
                    itemBuilder: (context, index) {
                      final patient = patients[index];
                      return GestureDetector(
                        onTap: () {
                          // Navigate to CaseSheetScreen with name and patient_id
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => CaseSheetScreen(
                                name: patient['name'],
                                patientId: patient['patient_id'].toString(),
                              ),
                            ),
                          );
                        },
                        child: Container(
                          margin: EdgeInsets.symmetric(vertical: 8.0),
                          padding: EdgeInsets.all(10.0),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: Colors.grey, width: 1),
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              CircleAvatar(
                                radius: 30,
                                backgroundImage: (patient['profile_pic'] == null ||
                                        patient['profile_pic'].isEmpty ||
                                        patient['profile_pic'] == "0")
                                    ? AssetImage('assets/images/dp.jpg')
                                        as ImageProvider
                                    : NetworkImage(
                                        Baseurl + patient['profile_pic']),
                              ),
                              SizedBox(width: 10),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      "Patient ID: ${patient['patient_id']}",
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16,
                                      ),
                                    ),
                                    SizedBox(height: 5),
                                    Text("Name: ${patient['name']}"),
                                    SizedBox(height: 5),
                                    Text("Stage: ${patient['stage']}"),
                                  ],
                                ),
                              ),
                              // Condition status color
                              Container(
                                padding: EdgeInsets.all(5.0),
                                decoration: BoxDecoration(
                                  color: getConditionColor(
                                      patient['condition_status']),
                                  borderRadius: BorderRadius.circular(5),
                                ),
                                child: Text(
                                  patient['condition_status'] ?? 'No Status',
                                  style: TextStyle(
                                    fontSize: 14,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  );
                }
              },
            ),
          ),
        ],
      ),
    );
  }

  // Color function for condition status
  Color getConditionColor(String? status) {
    if (status == null || status.isEmpty || status.toLowerCase() == 'no data') {
      return Colors.grey;
    }
    switch (status.toLowerCase()) {
      case 'good':
        return Colors.green;
      case 'caution':
        return Colors.orange;
      case 'warning':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

}
