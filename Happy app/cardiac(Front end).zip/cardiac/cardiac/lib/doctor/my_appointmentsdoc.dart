import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '/api.dart'; // Ensure this imports your api.dart file

class MyAppointmentsDoc extends StatefulWidget {
  @override
  _MyAppointmentsDocState createState() => _MyAppointmentsDocState();
}

class _MyAppointmentsDocState extends State<MyAppointmentsDoc> {
  List<Map<String, dynamic>> appointments = [];
  bool isLoading = true;
  String message = '';

  // Function to fetch appointments for the doctor
  Future<void> fetchAppointmentsForDoctor() async {
    final url = Uri.parse(My_appointments_docurl);  // Use the URL from api.dart

    try {
      // Get the doctor_id directly from api.dart
      String doctorId = doctor_id; 

      // Prepare the headers and body for the POST request
      Map<String, String> headers = {
        "Content-Type": "application/json",
      };

      Map<String, dynamic> body = {
        'doctor_id': doctorId, // Send doctor_id in the request body
      };

      // Send the POST request
      final response = await http.post(
        url,
        headers: headers,
        body: json.encode(body), // Convert the body to JSON format
      );

      // Check the response status
      if (response.statusCode == 200) {
        var data = json.decode(response.body);

        if (data['status'] == true) {
          setState(() {
            appointments = List<Map<String, dynamic>>.from(data['data']);
            isLoading = false;
            message = data['message'];
          });
        } else {
          setState(() {
            isLoading = false;
            message = data['message'];
          });
        }
      } else {
        setState(() {
          isLoading = false;
          message = 'Failed to load appointments. Please try again later.';
        });
      }
    } catch (e) {
      setState(() {
        isLoading = false;
        message = 'An error occurred: $e';
      });
    }
  }

  @override
  void initState() {
    super.initState();
    fetchAppointmentsForDoctor(); // Fetch the appointments for the doctor when the screen loads
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('My Appointments', style: TextStyle(color: Colors.black)),
        backgroundColor: Colors.white,
        centerTitle: true,
        elevation: 0,
        automaticallyImplyLeading: false, // Hides the default back button
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              'Today Appointments',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8.0),
            Expanded(
              child: isLoading
                  ? Center(child: CircularProgressIndicator())
                  : appointments.isEmpty
                      ? Center(
                          child: Text(
                            'No upcoming appointments.',
                            style: TextStyle(fontSize: 16, color: Colors.grey),
                          ),
                        )
                      : ListView.builder(
                          itemCount: appointments.length,
                          itemBuilder: (context, index) {
                            return Container(
                              margin: EdgeInsets.symmetric(vertical: 8.0),
                              decoration: BoxDecoration(
                                color: Colors.white,  // Set background to white
                                borderRadius: BorderRadius.circular(8.0),
                                border: Border.all(
                                  color: Colors.grey,  // Set border color to grey
                                  width: 1.0,
                                ),
                              ),
                              child: AppointmentCard(
                                name: appointments[index]['name'] ?? 'N/A',
                                date: appointments[index]['date'] ?? 'N/A',
                                time: appointments[index]['time'] ?? 'N/A',
                                profilePic: appointments[index]['profile_pic'] ?? '',  // It won't be used now
                              ),
                            );
                          },
                        ),
            ),
          ],
        ),
      ),
    );
  }
}

class AppointmentCard extends StatelessWidget {
  final String name;
  final String date;
  final String time;
  final String profilePic;

  AppointmentCard({required this.name, required this.date, required this.time, this.profilePic = ''});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Row(
        children: [
          // Always display the profile icon
          Icon(Icons.person, size: 40, color: Colors.grey),
          SizedBox(width: 16.0),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Text('Name :', style: TextStyle(fontSize: 16)),
                  SizedBox(width: 8),
                  Text(name, style: TextStyle(fontSize: 16)),
                ],
              ),
              Row(
                children: [
                  Text('Date   :', style: TextStyle(fontSize: 16)),
                  SizedBox(width: 8),
                  Text(date, style: TextStyle(fontSize: 16)),
                ],
              ),
              Row(
                children: [
                  Text('Time  :', style: TextStyle(fontSize: 16)),
                  SizedBox(width: 8),
                  Text(time, style: TextStyle(fontSize: 16)),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}
