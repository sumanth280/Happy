import '/provider_doc/risk_minor.dart';
import 'package:flutter/material.dart';
import '/api.dart'; // Import your API functions (where patient_id is stored)

class MinorRiskScreen extends StatefulWidget {
  @override
  _MinorRiskScreenState createState() => _MinorRiskScreenState();
}

class _MinorRiskScreenState extends State<MinorRiskScreen> {
  bool isEditable = false;
  Map<String, bool> symptoms = {
    "Ankle Edema": false,
    "Dyspnea on Exertion": false,
    "Hepatomegaly": false,
    "Nocturnal Cough": false,
    "Pleural Effusion": false,
    "Tachycardia HR > 120": false,
  };

  // Directly accessing patient_id from api.dart
  String patientId = patient_id; // Assuming patientId is already defined in api.dart

  @override
  void initState() {
    super.initState();
    if (patientId.isNotEmpty) {
      _fetchRiskMinorData(); // Fetch risk data when the screen initializes
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to retrieve patient ID')),
      );
    }
  }

  // Fetch risk minor data using the patient_id from api.dart
  Future<void> _fetchRiskMinorData() async {
    var result = await fetchRiskMinorData(patientId);
    if (result['status'] == true) {
      // Set the values based on the fetched data
      var data = result['data'];
      setState(() {
        symptoms["Ankle Edema"] = data['ankle_edema'] == 'yes';
        symptoms["Dyspnea on Exertion"] = data['dyspnea_on_exertion'] == 'yes';
        symptoms["Hepatomegaly"] = data['hapatomegaly'] == 'yes';
        symptoms["Nocturnal Cough"] = data['nocturnal_cough'] == 'yes';
        symptoms["Pleural Effusion"] = data['pleural_effusion'] == 'yes';
        symptoms["Tachycardia HR > 120"] = data['tachycardia_hr'] == 'yes';
      });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(result['message'])),
      );
    }
  }

  // Submit updated data
  Future<void> _submitRiskMinorData() async {
    var result = await updateOrInsertRiskMinorData(
      patientId: patientId, // Using patientId directly
      ankleEdema: symptoms["Ankle Edema"]! ? 'yes' : 'no',
      dyspneaOnExertion: symptoms["Dyspnea on Exertion"]! ? 'yes' : 'no',
      hapatomegaly: symptoms["Hepatomegaly"]! ? 'yes' : 'no',
      nocturnalCough: symptoms["Nocturnal Cough"]! ? 'yes' : 'no',
      pleuralEffusion: symptoms["Pleural Effusion"]! ? 'yes' : 'no',
      tachycardiaHr: symptoms["Tachycardia HR > 120"]! ? 'yes' : 'no',
    );

    if (result['status'] == true) {
      // Show dialog on success
      _showDialog('Success', result['message'], true);
    } else {
      // Show dialog on failure
      _showDialog('Error', result['message'], false);
    }
  }

  // Function to show a dialog (popup) and update the state
  void _showDialog(String title, String message, bool isSuccess) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(title),
          content: Text(message),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close the dialog
                // If the operation was successful, reset the form to non-editable
                if (isSuccess) {
                  setState(() {
                    isEditable = false; // Disable editing after success
                  });
                }
              },
              child: Text('OK'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          // Minor risks text in the center with the edit button beside it
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'Framingham Minor criteria',
                  style: TextStyle(fontSize: 24.0, fontWeight: FontWeight.bold),
                ),
                IconButton(
                  icon: Icon(isEditable ? Icons.check : Icons.edit),
                  onPressed: () {
                    setState(() {
                      isEditable = !isEditable;
                    });
                  },
                ),
              ],
            ),
          ),
          // List of Symptoms with white background and grey border
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: ListView.builder(
                itemCount: symptoms.keys.length,
                itemBuilder: (context, index) {
                  String symptom = symptoms.keys.elementAt(index);
                  return Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0),
                      side: BorderSide(color: Colors.grey),
                    ),
                    color: Colors.white, // White background for the card
                    child: ListTile(
                      title: Text(symptom),
                      trailing: GestureDetector(
                        onTap: isEditable
                            ? () {
                                setState(() {
                                  symptoms[symptom] = !(symptoms[symptom] ?? false);
                                });
                              }
                            : null,
                        child: Container(
                          width: 24,
                          height: 24,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: (symptoms[symptom] ?? false)
                                ? Colors.green
                                : Colors.white,
                            border: Border.all(color: Colors.grey),
                          ),
                          child: (symptoms[symptom] ?? false)
                              ? Icon(
                                  Icons.check,
                                  color: Colors.white,
                                  size: 16.0,
                                )
                              : null,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),

          // Save Button visible only when editable and smaller in size
          if (isEditable)
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: ElevatedButton(
                onPressed: _submitRiskMinorData,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.black,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                  padding: EdgeInsets.symmetric(vertical: 12.0), // Smaller padding
                  minimumSize: Size(double.infinity * 0.8, 50), // Smaller width (80% of screen width)
                ),
                child: Text(
                  "Save",
                  style: TextStyle(fontSize: 16.0, color: Colors.white), // Smaller font size
                ),
              ),
            ),
        ],
      ),
    );
  }
}
