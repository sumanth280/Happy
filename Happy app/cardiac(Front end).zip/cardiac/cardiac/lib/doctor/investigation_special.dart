import 'package:flutter/material.dart';
import '../provider_doc/investigation_special.dart';
import 'special_casesheets.dart';

class SpecialAddCaseSheet extends StatefulWidget {
  @override
  _SpecialAddCaseSheetState createState() => _SpecialAddCaseSheetState();
}

class _SpecialAddCaseSheetState extends State<SpecialAddCaseSheet> {
  // TextEditingControllers for input fields
  final TextEditingController hba1cController = TextEditingController();
  final TextEditingController triglyceridesController = TextEditingController();
  final TextEditingController ldlController = TextEditingController();
  final TextEditingController hdlController = TextEditingController();
  final TextEditingController bnpController = TextEditingController();
  final TextEditingController tshController = TextEditingController();
  final TextEditingController ft3Controller = TextEditingController();
  final TextEditingController ft4Controller = TextEditingController();
  final TextEditingController ecgCommentsController = TextEditingController();
  final TextEditingController echoCommentsController = TextEditingController();
  final TextEditingController usgCommentsController = TextEditingController();

  // FocusNodes for focus handling
  final FocusNode hba1cFocusNode = FocusNode();
  final FocusNode triglyceridesFocusNode = FocusNode();
  final FocusNode ldlFocusNode = FocusNode();
  final FocusNode hdlFocusNode = FocusNode();
  final FocusNode bnpFocusNode = FocusNode();
  final FocusNode tshFocusNode = FocusNode();
  final FocusNode ft3FocusNode = FocusNode();
  final FocusNode ft4FocusNode = FocusNode();

  // Dropdown menu value
  String? selectedStage;

  @override
  void dispose() {
    // Dispose controllers and focus nodes
    hba1cController.dispose();
    triglyceridesController.dispose();
    ldlController.dispose();
    hdlController.dispose();
    bnpController.dispose();
    tshController.dispose();
    ft3Controller.dispose();
    ft4Controller.dispose();
    ecgCommentsController.dispose();
    echoCommentsController.dispose();
    usgCommentsController.dispose();

    hba1cFocusNode.dispose();
    triglyceridesFocusNode.dispose();
    ldlFocusNode.dispose();
    hdlFocusNode.dispose();
    bnpFocusNode.dispose();
    tshFocusNode.dispose();
    ft3FocusNode.dispose();
    ft4FocusNode.dispose();

    super.dispose();
  }
 Future<void> submitData() async {
    // Call the API function
    final response = await addInvestigationSpecial(
    h1ba1c: hba1cController.text,
    triglycerides: triglyceridesController.text,
    ldl: ldlController.text,
    hdl: hdlController.text,
    bnp: bnpController.text,
    tsh: tshController.text,
    ft3: ft3Controller.text,
    ft4: ft4Controller.text,
    ecgFindings: ecgCommentsController.text,
    echoFindings: echoCommentsController.text,
    usgAbdomenFindings: usgCommentsController.text,
    stage: selectedStage,
  );
  
    // Show a dialog with the response
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(response['status'] ? 'Success' : 'Error'),
        content: Text(response['message']),
        actions: [
         TextButton(
  onPressed: () {
    Navigator.pop(context); // Close the dialog first
    if (response['status']) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => Specialcasesheets(), // Replace with your desired widget
        ),
      );
    }
  },
  child: Text('OK'),
)

        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Investigation'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            InvestigationField(
              label: 'H1BA1C',
              unit: '%',
              controller: hba1cController,
              focusNode: hba1cFocusNode,
            ),
            InvestigationField(
              label: 'Triglycerides',
              unit: 'Mg/DL',
              controller: triglyceridesController,
              focusNode: triglyceridesFocusNode,
            ),
            InvestigationField(
              label: 'LDL',
              unit: 'mg/DL',
              controller: ldlController,
              focusNode: ldlFocusNode,
            ),
            InvestigationField(
              label: 'HDL',
              unit: 'mg/DL',
              controller: hdlController,
              focusNode: hdlFocusNode,
            ),
            InvestigationField(
              label: 'BNP',
              unit: 'Pg/ml',
              controller: bnpController,
              focusNode: bnpFocusNode,
            ),
            InvestigationField(
              label: 'TSH',
              unit: 'mlu/ml',
              controller: tshController,
              focusNode: tshFocusNode,
            ),
            InvestigationField(
              label: 'FT3',
              unit: 'pg/ml',
              controller: ft3Controller,
              focusNode: ft3FocusNode,
            ),
            InvestigationField(
              label: 'FT4',
              unit: 'ng/dl',
              controller: ft4Controller,
              focusNode: ft4FocusNode,
            ),
            // ECG Findings Section
            SectionLabel(label: 'ECG Findings'),
            CommentBox(
              controller: ecgCommentsController,
            ),
            // ECHO Findings Section
            SectionLabel(label: 'ECHO Findings'),
            CommentBox(
              controller: echoCommentsController,
            ),
            // USG Findings Section
            SectionLabel(label: 'USG Abdomen Findings'),
            CommentBox(
              controller: usgCommentsController,
            ),
            // Stage Dropdown
            SectionLabel(label: 'Stage'),
            DropdownButtonFormField<String>(
              value: selectedStage,
              hint: Text('Select the stage'),
              onChanged: (String? value) {
                setState(() {
                  selectedStage = value;
                });
              },
              items: [
                DropdownMenuItem(
                  value: 'Stage A - At risk for heart failure',
                  child: Text('Stage A - At risk for heart failure'),
                ),
                DropdownMenuItem(
                  value: 'Stage B - Pre-heart failure',
                  child: Text('Stage B - Pre-heart failure'),
                ),
                DropdownMenuItem(
                  value: 'Stage C - Symptomatic heart failure',
                  child: Text('Stage C - Symptomatic heart failure'),
                ),
                DropdownMenuItem(
                  value: 'Stage D - Advanced heart failure',
                  child: Text('Stage D - Advanced heart failure'),
                ),
              ],
              decoration: InputDecoration(
                contentPadding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(20.0),
                ),
              ),
            ),
            SizedBox(height: 20.0),
            Center(
              child:  ElevatedButton(
                onPressed: submitData,
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.symmetric(horizontal: 40.0, vertical: 16.0),
                  backgroundColor: Colors.black,
                ),
                child: Text(
                  'Save',
                  style: TextStyle(color: Colors.white, fontSize: 16.0),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Reusable Widget for Investigation Fields
class InvestigationField extends StatelessWidget {
  final String label;
  final String unit;
  final TextEditingController controller;
  final FocusNode focusNode;

  const InvestigationField({
    required this.label,
    required this.unit,
    required this.controller,
    required this.focusNode,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 8.0),
      padding: EdgeInsets.all(12.0),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(
          color: focusNode.hasFocus ? Colors.green : Colors.grey.shade300,
          width: 2.0,
        ),
        borderRadius: BorderRadius.circular(20.0),
      ),
      child: Row(
        children: [
          Expanded(
            flex: 3,
            child: Text(
              label,
              style: TextStyle(fontSize: 16.0),
            ),
          ),
          Expanded(
            flex: 2,
            child: TextField(
              controller: controller,
              focusNode: focusNode,
              decoration: InputDecoration(
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(vertical: 0),
              ),
            ),
          ),
          if (unit.isNotEmpty)
            Expanded(
              flex: 1,
              child: Text(
                unit,
                textAlign: TextAlign.end,
                style: TextStyle(fontSize: 16.0, color: Colors.grey),
              ),
            ),
        ],
      ),
    );
  }
}

// Reusable Widget for Comment Boxes
class CommentBox extends StatelessWidget {
  final TextEditingController controller;

  const CommentBox({required this.controller});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 8.0),
      padding: EdgeInsets.all(12.0),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: Colors.grey.shade300, width: 2.0),
        borderRadius: BorderRadius.circular(20.0),
      ),
      child: TextField(
        controller: controller,
        maxLines: 3,
        decoration: InputDecoration(
          border: InputBorder.none,
          contentPadding: EdgeInsets.symmetric(vertical: 0),
        ),
      ),
    );
  }
}

// Widget for Section Labels
class SectionLabel extends StatelessWidget {
  final String label;

  const SectionLabel({required this.label});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Text(
        label,
        style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold),
      ),
    );
  }
} 