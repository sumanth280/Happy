import '/provider_doc/add_medicine.dart';
import 'package:flutter/material.dart';
import 'add_medicine.dart';
import 'medication.dart';

class AddMedicineScreen extends StatefulWidget {
  @override
  _AddMedicineScreenState createState() => _AddMedicineScreenState();
}

class _AddMedicineScreenState extends State<AddMedicineScreen> {
  bool morning = false;
  bool afternoon = false;
  bool night = false;
  bool beforeFood = false;
  bool afterFood = false;

  final TextEditingController medicineNameController = TextEditingController();
  final TextEditingController dosageController = TextEditingController();
  final TextEditingController daysController = TextEditingController();
  final TextEditingController commentsController = TextEditingController();

  bool isLoading = false;

  void saveMedicine() async {
    final medicineName = medicineNameController.text.trim();
    final dosage = dosageController.text.trim();
    final days = daysController.text.trim();
    final comments = commentsController.text.trim();

    if (medicineName.isEmpty || dosage.isEmpty || days.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("All fields are required")),
      );
      return;
    }

    setState(() {
      isLoading = true;
    });

    final response = await addMedicine(
      medicineName: medicineName,
      dosage: dosage,
      days: days,
      morning: morning,
      afternoon: afternoon,
      night: night,
      beforeFood: beforeFood,
      afterFood: afterFood,
      comments: comments,
    );

    setState(() {
      isLoading = false;
    });

    if (response['success']) {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text("Success"),
          content: Text(response['message']),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                Navigator.pop(context);
              },
              child: Text("OK"),
            ),
          ],
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(response['message'])),
      );
    }
  }

  Widget buildCustomCheckboxTile({
    required String title,
    required bool value,
    required ValueChanged<bool?> onChanged,
  }) {
    return Container(
      margin: EdgeInsets.only(bottom: 10),
      padding: EdgeInsets.symmetric(vertical: 5),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(10),
      ),
      child: CheckboxListTile(
        title: Text(title),
        value: value,
        onChanged: onChanged,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        activeColor: Colors.green,
        checkColor: Colors.white,
        contentPadding: EdgeInsets.symmetric(horizontal: 10),
      ),
    );
  }

  Widget buildCustomTextField({
    required String label,
    required TextEditingController controller,
    String hintText = "",
    TextInputType keyboardType = TextInputType.text,
    int maxLines = 1,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: TextStyle(fontWeight: FontWeight.bold)),
        SizedBox(height: 5),
        TextField(
          controller: controller,
          keyboardType: keyboardType,
          maxLines: maxLines,
          decoration: InputDecoration(
            hintText: hintText,
            filled: true,
            fillColor: Colors.white,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide(color: Colors.grey),
            ),
            contentPadding: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Add Medicine",
          style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 1,
        iconTheme: IconThemeData(color: Colors.black),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              buildCustomTextField(
                label: "Medicine Name",
                controller: medicineNameController,
                hintText: "Enter Medicine Name",
              ),
              SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: buildCustomTextField(
                      label: "Dosage",
                      controller: dosageController,
                      hintText: "Enter Dosage",
                      keyboardType: TextInputType.text,
                    ),
                  ),
                  SizedBox(width: 20),
                  Expanded(
                    child: buildCustomTextField(
                      label: "Days",
                      controller: daysController,
                      hintText: "Enter Days",
                      keyboardType: TextInputType.number,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 20),
              Text("Symptom", style: TextStyle(fontWeight: FontWeight.bold)),
              buildCustomCheckboxTile(
                title: "Morning",
                value: morning,
                onChanged: (value) {
                  setState(() {
                    morning = value ?? false;
                  });
                },
              ),
              buildCustomCheckboxTile(
                title: "Afternoon",
                value: afternoon,
                onChanged: (value) {
                  setState(() {
                    afternoon = value ?? false;
                  });
                },
              ),
              buildCustomCheckboxTile(
                title: "Night",
                value: night,
                onChanged: (value) {
                  setState(() {
                    night = value ?? false;
                  });
                },
              ),
              SizedBox(height: 20),
              Text("Food Timing", style: TextStyle(fontWeight: FontWeight.bold)),
              buildCustomCheckboxTile(
                title: "Before Food",
                value: beforeFood,
                onChanged: (value) {
                  setState(() {
                    beforeFood = value ?? false;
                  });
                },
              ),
              buildCustomCheckboxTile(
                title: "After Food",
                value: afterFood,
                onChanged: (value) {
                  setState(() {
                    afterFood = value ?? false;
                  });
                },
              ),
              SizedBox(height: 20),
              buildCustomTextField(
                label: "About",
                controller: commentsController,
                hintText: "Comments",
                maxLines: 3,
              ),
              SizedBox(height: 30),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      onPressed: isLoading ? null : saveMedicine,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.black,
                        padding: EdgeInsets.symmetric(vertical: 15),
                      ),
                      child: isLoading
                          ? CircularProgressIndicator(color: Colors.white)
                          : Text("Save", style: TextStyle(color: Colors.white)),
                    ),
                  ),
                  SizedBox(width: 20),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.grey,
                        padding: EdgeInsets.symmetric(vertical: 15),
                      ),
                      child: Text("Cancel", style: TextStyle(color: Colors.white)),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
