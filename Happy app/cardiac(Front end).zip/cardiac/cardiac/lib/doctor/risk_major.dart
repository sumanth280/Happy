import 'package:flutter/material.dart';
import '../provider_doc/risk_major.dart';
import '/api.dart'; // Import the API functions where patient_id is stored

class MajorRiskScreen extends StatefulWidget {
  @override
  _MajorRiskScreenState createState() => _MajorRiskScreenState();
}

class _MajorRiskScreenState extends State<MajorRiskScreen> {
  bool isEditable = false;
  bool isSaved = false; // Track if data is saved
  Map<String, bool> symptoms = {
    "Acute pulmonary Edema": false,
    "Cardiomegaly": false,
    "Hepatojugular Reflex": false,
    "Neck Vein Distension": false,
    "PND/orthopnea": false,
    "Pulmonary Rales": false,
    "Third Heartsound S3": false,
    "weight Loss >4.5kg in 5 days in response to Treatment": false,
  };

  // Directly accessing patient_id from api.dart
  String patientId = patient_id; // Assuming patientId is already defined in api.dart

  @override
  void initState() {
    super.initState();
    if (patientId.isNotEmpty) {
      _fetchRiskMajorData(); // Fetch initial data when the screen is loaded
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to retrieve patient ID')),
      );
    }
  }

  // Fetch Risk Major Data
  Future<void> _fetchRiskMajorData() async {
    var result = await fetchRiskMajorData(patientId); // API call using patientId
    if (result['status'] == true) {
      var data = result['data'];
      setState(() {
        symptoms["Acute pulmonary Edema"] = data['acute_pulmonary_edema'] == 'yes';
        symptoms["Cardiomegaly"] = data['cardiomegaly'] == 'yes';
        symptoms["Hepatojugular Reflex"] = data['hepatojugular_reflex'] == 'yes';
        symptoms["Neck Vein Distension"] = data['neck_vein_distension'] == 'yes';
        symptoms["PND/orthopnea"] = data['pnd_orthopnea'] == 'yes';
        symptoms["Pulmonary Rales"] = data['pulmonary_rales'] == 'yes';
        symptoms["Third Heartsound S3"] = data['third_heartsound_s3'] == 'yes';
        symptoms["weight Loss >4.5kg in 5 days in response to Treatment"] = data['response_to_treatment'] == 'yes';
      });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(result['message'])),
      );
    }
  }

  // Submit Risk Major Data
  Future<void> _submitRiskMajorData() async {
    var result = await updateOrInsertRiskMajorData(
      patientId: patientId,
      acutePulmonaryEdema: symptoms["Acute pulmonary Edema"]! ? 'yes' : 'no',
      cardiomegaly: symptoms["Cardiomegaly"]! ? 'yes' : 'no',
      hepatojugularReflex: symptoms["Hepatojugular Reflex"]! ? 'yes' : 'no',
      neckVeinDistension: symptoms["Neck Vein Distension"]! ? 'yes' : 'no',
      pndOrthopnea: symptoms["PND/orthopnea"]! ? 'yes' : 'no',
      pulmonaryRales: symptoms["Pulmonary Rales"]! ? 'yes' : 'no',
      thirdHeartSoundS3: symptoms["Third Heartsound S3"]! ? 'yes' : 'no',
      responseToTreatment: symptoms["weight Loss >4.5kg in 5 days in response to Treatment"]! ? 'yes' : 'no',
    );

    if (result['status'] == true) {
      // Show dialog on success
      _showDialog('Success', result['message'], true);
    } else {
      // Show dialog on failure
      _showDialog('Error', result['message'], false);
    }
  }

  // Show success dialog after saving
  void _showDialog(String title, String message, bool isSuccess) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(title),
          content: Text(message),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close the dialog
                // If the operation was successful, reset the form to non-editable
                if (isSuccess) {
                  setState(() {
                    isEditable = false; // Disable editing after success
                  });
                }
              },
              child: Text('OK'),
            ),
          ],
        );
      },
    );
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          // Major risks text centered with the edit/check button beside it
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'Framingham Major criteria',
                  style: TextStyle(fontSize: 24.0, fontWeight: FontWeight.bold),
                ),
                IconButton(
                  icon: Icon(isSaved ? Icons.edit : (isEditable ? Icons.check : Icons.edit)),
                  onPressed: () {
                    setState(() {
                      isEditable = !isEditable;
                    });
                  },
                ),
              ],
            ),
          ),
          // List of Symptoms
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: ListView.builder(
                itemCount: symptoms.keys.length,
                itemBuilder: (context, index) {
                  String symptom = symptoms.keys.elementAt(index);
                  return Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0),
                      side: BorderSide(color: Colors.grey),
                    ),
                    color: Colors.white, // White background for the card
                    child: ListTile(
                      title: Text(symptom),
                      trailing: GestureDetector(
                        onTap: isEditable
                            ? () {
                                setState(() {
                                  symptoms[symptom] = !symptoms[symptom]!;
                                });
                              }
                            : null,
                        child: Container(
                          width: 24,
                          height: 24,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: symptoms[symptom]!
                                ? Colors.green
                                : Colors.white,
                            border: Border.all(color: Colors.grey),
                          ),
                          child: symptoms[symptom]!
                              ? Icon(
                                  Icons.check,
                                  color: Colors.white,
                                  size: 16.0,
                                )
                              : null,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),

          // Save Button (Smaller size and placed below the list)
          if (isEditable && !isSaved)
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: ElevatedButton(
                onPressed: _submitRiskMajorData, // Save functionality
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.black,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                  padding: EdgeInsets.symmetric(vertical: 12.0), // Smaller padding
                  minimumSize: Size(double.infinity * 0.8, 50), // Smaller width (80% of screen width)
                ),
                child: Text(
                  "Save",
                  style: TextStyle(fontSize: 16.0, color: Colors.white), // Smaller font size
                ),
              ),
            ),
        ],
      ),
    );
  }
}
