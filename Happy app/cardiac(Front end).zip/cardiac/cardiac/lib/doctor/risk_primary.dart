import '/provider_doc/risk_primary.dart';
import 'package:flutter/material.dart';
import '/api.dart'; // Import API calls from your api.dart
import 'risk_minor.dart';
import 'risk_major.dart';

class RiskStratistificationScreen extends StatefulWidget {
  @override
  _RiskStratistificationScreenState createState() =>
      _RiskStratistificationScreenState();
}

class _RiskStratistificationScreenState extends State<RiskStratistificationScreen>
    with SingleTickerProviderStateMixin {
  bool isEditable = false;
  String? nyhaClass;
  String? gender;
  List<String> nyhaOptions = [
    'No limitation',
    'Slight limitation',
    'Moderate limitation',
    'Severe limitation even at rest'
  ];
  List<String> genderOptions = ['Male', 'Female', 'Other'];

  late TabController tabController;

  Map<String, bool> symptoms = {
    "Current smoker": false,
    "Diabetes": false,
    "Heart Failure >=18 months": false,
    "Beta Blockers": false,
    "ACEI/ARB": false,
  };

  // Define TextEditingControllers for form fields
  TextEditingController ageController = TextEditingController();
  TextEditingController bmiController = TextEditingController();
  TextEditingController sbpController = TextEditingController();
  TextEditingController creatinineController = TextEditingController();

  String patientId = ''; // Patient ID retrieved from api.dart

  @override
  void initState() {
    super.initState();
    tabController = TabController(length: 3, vsync: this);

    // Fetch patient data when the screen is loaded
    fetchData();
  }

  // Fetch Risk Primary Data from the API
  Future<void> fetchData() async {
    patientId = patient_id; // Assuming patient_id is a global variable from api.dart

    try {
      final response = await fetchRiskPrimaryData(patientId);

      if (response['status'] == true) {
        setState(() {
          ageController.text = response['data']['age'] ?? '';
          bmiController.text = response['data']['bmi'] ?? '';
          sbpController.text = response['data']['sbp'] ?? '';
          creatinineController.text = response['data']['creatinine'] ?? '';
          gender = response['data']['gender'] ?? '';

          // Map symptom fields correctly
          symptoms['Current smoker'] = response['data']['current_smoker'] == '1';
          symptoms['Diabetes'] = response['data']['diabetes'] == '1';
          symptoms['Heart Failure >=18 months'] = response['data']['heart_failure'] == '1';
          symptoms['H/O Beta Blockers'] = response['data']['beta_blockers'] == '1';
          symptoms['H/O ACEI/ARB'] = response['data']['acei_arb'] == '1';

          // Map NYHA class
          nyhaClass = response['data']['nyha'] ?? '';
        });
      } else {
        showError(response['message']);
      }
    } catch (e) {
      showError('An error occurred while fetching data: $e');
    }
  }

  // Save data to the API
  Future<void> saveData() async {
    if (!isEditable) return;

    final currentSmoker = symptoms['Current smoker'] == true ? '1' : '0';
    final Diabetes = symptoms['Diabetes'] == true ? '1' : '0';
    final heartFailure = symptoms['Heart Failure >=18 months'] == true ? '1' : '0';
    final betaBlockers = symptoms['Beta Blockers'] == true ? '1' : '0';
    final aceiArb = symptoms['ACEI/ARB'] == true ? '1' : '0';

    try {
      final response = await updateOrInsertRiskPrimaryData(
        patientId: patientId,
        age: ageController.text,
        gender: gender!,
        bmi: bmiController.text,
        sbp: sbpController.text,
        creatinine: creatinineController.text,
        currentSmoker: currentSmoker,
        Diabetes: Diabetes,
        heartFailure: heartFailure,
        betaBlockers: betaBlockers,
        aceiArb: aceiArb,
        nyha: nyhaClass!,
      );

      if (response['status'] == true) {
        showSuccess(response['message']);
      } else {
        showError(response['message']);
      }
    } catch (e) {
      showError('An error occurred while saving data: $e');
    }
  }

  // Show error message
  void showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  // Show success message in a popup dialog
  // Show success message in a popup dialog
void showSuccess(String message) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: Text('Success'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () {
              setState(() {
                isEditable = false; // Disable editing after success
              });
              Navigator.of(context).pop(); // Close the dialog
            },
            child: Text('OK'),
          ),
        ],
      );
    },
  );
}


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Risk Stratification"),
        bottom: TabBar(
          controller: tabController,
          tabs: [
            Tab(text: 'Primary'),
            Tab(text: 'Framingham Minor'),
            Tab(text: 'Framingham Major'),
          ],
        ),
      ),
      body: TabBarView(
        controller: tabController,
        children: [
          buildPrimaryRiskScreen(),
          MajorRiskScreen(),
          MinorRiskScreen(),
        ],
      ),
    );
  }

  Widget buildPrimaryRiskScreen() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: ListView(
        children: [
          // Header (Primary risks and edit button)
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Primary Risks',
                style: TextStyle(fontSize: 24.0, fontWeight: FontWeight.bold),
              ),
              IconButton(
                icon: Icon(isEditable ? Icons.check : Icons.edit),
                onPressed: () {
                  setState(() {
                    isEditable = !isEditable;
                  });
                },
              ),
            ],
          ),

          // Input Fields
          buildCardInput("Age", ageController, "Years"),
          buildGenderDropdown(),
          buildCardInput("BMI", bmiController, "Kg/m2"),
          buildCardInput("SBP", sbpController, "mm/Hg"),
          buildCardInput("Creatinine", creatinineController, "mg/dL"),
          SizedBox(height: 16),

          // Symptoms Section
          Text(
            "Symptoms",
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          ...symptoms.keys.map((symptom) => buildSymptomCard(symptom)),

          SizedBox(height: 16),

          // NYHA Dropdown
          Text(
            "NYHA",
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          Card(
            color: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10.0),
              side: BorderSide(color: Colors.grey),
            ),
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: DropdownButton<String>(
                value: nyhaClass,
                items: nyhaOptions.map((String value) {
                  return DropdownMenuItem<String>(value: value, child: Text(value));
                }).toList(),
                onChanged: isEditable
                    ? (newValue) {
                        setState(() {
                          nyhaClass = newValue!;
                        });
                      }
                    : null,
                hint: Text("Select Class"),
                style: TextStyle(color: Colors.black),
                dropdownColor: Colors.white,
              ),
            ),
          ),

          // Save Button
          if (isEditable)
            Padding(
              padding: const EdgeInsets.only(top: 16.0),
              child: ElevatedButton(
                onPressed: saveData,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.black,
                  padding: EdgeInsets.symmetric(vertical: 12.0),
                ),
                child: Text("Save", style: TextStyle(color: Colors.white)),
              ),
            ),
        ],
      ),
    );
  }

  Widget buildCardInput(String label, TextEditingController controller, String unit) {
    return Card(
      margin: EdgeInsets.symmetric(vertical: 8.0),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10.0),
        side: BorderSide(color: Colors.grey),
      ),
      color: Colors.white, // White background for the card
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Row(
          children: [
            Expanded(flex: 2, child: Text(label)),
            Expanded(
              flex: 3,
              child: TextField(
                controller: controller,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                ),
                enabled: isEditable,
              ),
            ),
            SizedBox(width: 8),
            Text(unit),
          ],
        ),
      ),
    );
  }

  Widget buildGenderDropdown() {
    return Card(
      color: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10.0),
        side: BorderSide(color: Colors.grey),
      ),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: DropdownButton<String>(
          value: gender,
          items: genderOptions.map((String value) {
            return DropdownMenuItem<String>(value: value, child: Text(value));
          }).toList(),
          onChanged: isEditable
              ? (newValue) {
                  setState(() {
                    gender = newValue!;
                  });
                }
              : null,
          hint: Text("Select Gender"),
          style: TextStyle(color: Colors.black),
          dropdownColor: Colors.white,
        ),
      ),
    );
  }

  Widget buildSymptomCard(String symptom) {
    return Card(
      margin: EdgeInsets.symmetric(vertical: 8.0),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10.0),
        side: BorderSide(color: Colors.grey),
      ),
      color: Colors.white,
      child: CheckboxListTile(
        title: Text(symptom),
        value: symptoms[symptom],
        onChanged: isEditable
            ? (bool? value) {
                setState(() {
                  symptoms[symptom] = value ?? false;
                });
              }
            : null,
      ),
    );
  }
}
