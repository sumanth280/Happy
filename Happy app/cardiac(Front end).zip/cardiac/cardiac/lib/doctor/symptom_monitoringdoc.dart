import '../patient/symptom_trends.dart';
import '/api.dart';
import '/provider/symptom_monitoring.dart';
import 'package:flutter/material.dart';

class SymptomMonitoringDocScreen extends StatefulWidget {
  @override
  _SymptomMonitoringDocScreenState createState() =>
      _SymptomMonitoringDocScreenState();
}

class _SymptomMonitoringDocScreenState
    extends State<SymptomMonitoringDocScreen> {
  Map<String, bool?> symptoms = {
    'Shortness of Breath': null,
    'Cough': null,
    'Fatigue/Weakness': null,
    'Chest Pain': null,
    'Palpitations': null,
    'Abdomen Discomfort': null,
    'Confusion': null,
    'Weight Gain/Pedal Edema': null,
    'Sleep Difficulty': null,
  };

  String? shortnessOfBreathDetail;
  String? coughDetail;
  bool isDataAvailable = false;

  @override
  void initState() {
    super.initState();
    _fetchSymptomData();
  }

  Future<void> _fetchSymptomData() async {
    String patientId = patient_id; // Replace with actual patient_id from api.dart
    Map<String, dynamic> response =
        await fetchSymptomMonitoring(patientId: patientId);

    if (response['status'] == true) {
      setState(() {
        if (response['data'] != null && response['data'].isNotEmpty) {
          isDataAvailable = true;
          var data = response['data'][0];

          symptoms['Shortness of Breath'] = data['shortness_of_breath'] == 'yes';
          symptoms['Cough'] = data['cough'] == 'yes';
          symptoms['Fatigue/Weakness'] = data['fatigue_weakness'] == 'yes';
          symptoms['Chest Pain'] = data['chest_pain'] == 'yes';
          symptoms['Palpitations'] = data['palpatations'] == 'yes';
          symptoms['Abdomen Discomfort'] = data['abdomen_discomfort'] == 'yes';
          symptoms['Confusion'] = data['confusion'] == 'yes';
          symptoms['Weight Gain/Pedal Edema'] = data['weight_gain'] == 'yes';
          symptoms['Sleep Difficulty'] = data['sleep_difficulty'] == 'yes';

          shortnessOfBreathDetail = data['while_working'] == 'yes'
              ? 'While Working'
              : data['while_rest'] == 'yes'
                  ? 'While at Rest'
                  : null;

          coughDetail = data['occasional'] == 'yes'
              ? 'Occasional'
              : data['frequent'] == 'yes'
                  ? 'Frequent'
                  : null;
        } else {
          isDataAvailable = false;
          symptoms.forEach((key, value) {
            symptoms[key] = null;
          });
          shortnessOfBreathDetail = null;
          coughDetail = null;
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 0,
          title: Text('Symptom Monitoring', style: TextStyle(color: Colors.black)),
          centerTitle: true,
          bottom: TabBar(
            labelColor: Colors.black,
            indicatorColor: Colors.lightGreen,
            tabs: [
              Tab(text: 'Today'),
              Tab(text: 'Trends'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _buildTodayView(),
            SymptomTrends(),
          ],
        ),
      ),
    );
  }

  Widget _buildTodayView() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Symptoms',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              Spacer(),
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text("Yes", style: TextStyle(color: Colors.green, fontSize: 16)),
                  SizedBox(width: 40),
                  Text("No    ", style: TextStyle(color: Colors.red, fontSize: 16)),
                ],
              ),
            ],
          ),
          Expanded(
            child: ListView(
              children: symptoms.keys.map((symptom) {
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildSymptomRow(symptom),
                    if (symptom == 'Shortness of Breath' &&
                        symptoms[symptom] == true)
                      _buildFollowUpQuestion(
                        'While working or while at rest?',
                        ['While Working', 'While at Rest'],
                        selectedOption: shortnessOfBreathDetail,
                      ),
                    if (symptom == 'Cough' && symptoms[symptom] == true)
                      _buildFollowUpQuestion(
                        'Occasional or frequent?',
                        ['Occasional', 'Frequent'],
                        selectedOption: coughDetail,
                      ),
                  ],
                );
              }).toList(),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(
              isDataAvailable
                  ? "Data Available"
                  : "Patient yet to enter data",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 16.0,
                color: isDataAvailable ? Colors.green : Colors.red,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSymptomRow(String symptom) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
      margin: EdgeInsets.symmetric(vertical: 8.0),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey.shade300),
        borderRadius: BorderRadius.circular(8.0),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(symptom, style: TextStyle(fontSize: 16)),
          Row(
            children: [
              Icon(
                symptoms[symptom] == true
                    ? Icons.check_circle
                    : Icons.radio_button_unchecked,
                color:
                    symptoms[symptom] == true ? Colors.green : Colors.grey,
              ),
              SizedBox(width: 16),
              Icon(
                symptoms[symptom] == false
                    ? Icons.check_circle
                    : Icons.radio_button_unchecked,
                color: symptoms[symptom] == false ? Colors.red : Colors.grey,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildFollowUpQuestion(
    String question,
    List<String> options, {
    String? selectedOption,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(question, style: TextStyle(fontSize: 16)),
          SizedBox(height: 8.0),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: options.map((option) {
              return Row(
                children: [
                  Radio<String>(
                    value: option,
                    groupValue: selectedOption,
                    onChanged: null, // Non-editable
                  ),
                  Text(option),
                  SizedBox(width: 10),
                ],
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}

