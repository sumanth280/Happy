import '/provider/profile_edit_view.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart'; // Importing intl package for date formatting
import '/api.dart'; // Import the api.dart file
import 'dart:async'; // To use Future.delayed for the API call

class PatientProfileScreen extends StatefulWidget {
  @override
  _PatientProfileScreenState createState() => _PatientProfileScreenState();
}

class _PatientProfileScreenState extends State<PatientProfileScreen> {
  // Text controllers for form fields
  TextEditingController nameController = TextEditingController();
  TextEditingController ageController = TextEditingController();
  TextEditingController genderController = TextEditingController();
  TextEditingController patientIdController = TextEditingController();
  TextEditingController weightController = TextEditingController();
  TextEditingController heightController = TextEditingController();
  TextEditingController bmiController = TextEditingController();
  TextEditingController professionController = TextEditingController();
  TextEditingController phone1Controller = TextEditingController();
  TextEditingController phone2Controller = TextEditingController();
  TextEditingController addressController = TextEditingController();

  bool isEditing = false; // Controls if the save button is visible

  @override
  void initState() {
    super.initState();
    _fetchPatientDetails(); // Fetch patient details when the page loads
  }

  // Function to fetch patient details and populate the form fields
  Future<void> _fetchPatientDetails() async {
    try {
      final patientDetails = await fetchPatientDetails();
      print(patientDetails);  // Debugging: Check API response

      setState(() {
        nameController.text = patientDetails['name'] ?? '';
        ageController.text = patientDetails['age'] ?? '';
        genderController.text = patientDetails['gender'] ?? '';
        patientIdController.text = patientDetails['patient_id'] ?? '';
        weightController.text = patientDetails['weight'] ?? '';
        heightController.text = patientDetails['height'] ?? '';
        bmiController.text = patientDetails['bmi'] ?? '';
        professionController.text = patientDetails['profession'] ?? '';
        phone1Controller.text = patientDetails['phone_number_1'] ?? '';
        phone2Controller.text = patientDetails['phone_number_2'] ?? '';
        addressController.text = patientDetails['address'] ?? '';
      });
    } catch (e) {
      // Handle error
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed to fetch patient details')));
    }
  }

  // Function to handle the save button press and call editPatientProfile API
  Future<void> _saveProfile() async {
    try {
      bool isSuccess = await editPatientProfile(
        name: nameController.text,
        age: ageController.text,
        gender: genderController.text,
        phoneNumber1: phone1Controller.text,
        phoneNumber2: phone2Controller.text,
        profession: professionController.text,
        weight: weightController.text,
        height: heightController.text,
        bmi: bmiController.text,
        address: addressController.text,
      );
      if (isSuccess) {
        _showSuccessPopup(context);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed to update profile')));
      }
    } catch (e) {
      // Handle error
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed to update profile')));
    }
  }

  // Function to show account update success popup
  void _showSuccessPopup(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false, // Prevent dismissing the popup when tapping outside
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Details Updated Successfully'),
          content: Text('Your details have been updated successfully!'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context); // Close the dialog
                Navigator.pop(context); // Go back to the previous screen (profile)
              },
              child: Text('Done'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF7F7F7),
      appBar: AppBar(
  backgroundColor: Colors.white,
  elevation: 0,
  leading: IconButton(
    icon: Icon(Icons.arrow_back, color: Colors.black),
    onPressed: () {
      Navigator.pop(context); // Go back to the previous screen
    },
  ),
  title: Text(
    'My Details',
    style: TextStyle(
      color: Colors.black,
      fontSize: 24,
      fontWeight: FontWeight.bold,
    ),
  ),
  centerTitle: true,
),

      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(height: 20),
              _buildTextField('Full Name', nameController, 'Enter Your Full Name'),
              _buildDatePickerField(context, 'Age', ageController),
              _buildTextField('Gender', genderController, 'Gender'),
              _buildLockedField('Patient ID', patientIdController),
              _buildTextField('Weight', weightController, 'Weight (kg)', onChanged: _calculateBMI),
              _buildTextField('Height', heightController, 'Height (m)', onChanged: _calculateBMI),
              _buildLockedField('BMI', bmiController),
              _buildTextField('Profession', professionController, 'Profession'),
              _buildTextField('Phone number 1', phone1Controller, 'Phone number 1'),
              _buildTextField('Phone number 2', phone2Controller, 'Phone number 2'),
              _buildTextField('Address', addressController, 'Enter your Address'),
              SizedBox(height: 20),
              if (isEditing) // Show Save button only if editing is enabled
                ElevatedButton(
                  onPressed: _saveProfile, // Call the save function
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.black,
                    minimumSize: Size(double.infinity, 50),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: Text(
                    'Save',
                    style: TextStyle(fontSize: 16),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(
      String label, TextEditingController controller, String hint,
      {bool obscureText = false, void Function()? onChanged}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: TextField(
        controller: controller,
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
        ),
        obscureText: obscureText,
        enabled: isEditing, // Field is enabled only when in editing mode
        onChanged: onChanged != null ? (value) => onChanged() : null,
      ),
    );
  }

  // Widget for displaying permanently locked fields (Patient ID and BMI)
  Widget _buildLockedField(String label, TextEditingController controller) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: TextField(
        controller: controller,
        readOnly: true, // Permanently read-only
        decoration: InputDecoration(
          labelText: label,
          filled: true,
          fillColor: Colors.grey.shade300, // Distinct background color
          suffixIcon: Icon(Icons.lock, color: Colors.grey), // Lock icon
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
          ),
        ),
      ),
    );
  }

  Widget _buildDatePickerField(BuildContext context, String label, TextEditingController controller) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: GestureDetector(
        onTap: () => isEditing ? _selectDate(context) : null,
        child: AbsorbPointer(
          child: TextField(
            controller: controller,
            decoration: InputDecoration(
              labelText: label,
              hintText: 'Date of birth',
              suffixIcon: Icon(Icons.calendar_today),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
            ),
          ),
        ),
      ),
    );
  }

  // Function to calculate BMI based on weight and height inputs
  void _calculateBMI() {
    double? weight = double.tryParse(weightController.text);
    double? height = double.tryParse(heightController.text);

    if (weight != null && height != null && height > 0) {
      double bmi = weight / (height * height);
      bmiController.text = bmi.toStringAsFixed(2);
    } else {
      bmiController.clear(); // Clear the BMI field if input is invalid
    }
  }

  // Function to open date picker and set age based on selected date
  Future<void> _selectDate(BuildContext context) async {
    DateTime selectedDate = DateTime.now();
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
    );
    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
        ageController.text = DateFormat.yMd().format(selectedDate); // Use this format to display
      });
    }
  }
}
