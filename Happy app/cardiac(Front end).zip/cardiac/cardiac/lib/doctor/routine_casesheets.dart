import 'package:flutter/material.dart';
import '../provider_doc/routines_casesheet.dart';
import '/api.dart'; // Assuming api.dart contains the required patient_id and URL
import 'investigation_routine.dart'; // Import your next screen
import 'routine_view.dart'; // Import the next screen for viewing details

class RoutinecaseSheets extends StatefulWidget {
  @override
  _RoutinecaseSheetsState createState() => _RoutinecaseSheetsState();
}

class _RoutinecaseSheetsState extends State<RoutinecaseSheets> {
  List<Map<String, dynamic>> caseHistory = []; // Corrected to dynamic to match API
  bool isLoading = true; // Loading state

  @override
  void initState() {
    super.initState();
    fetchCaseHistory(); // Fetch data from API
  }

  // Fetch case history from API
  Future<void> fetchCaseHistory() async {
    try {
      final response = await fetchInvestigationRoutines();

      if (response['success']) {
        setState(() {
          // Ensure correct parsing of the response
          caseHistory = List<Map<String, dynamic>>.from(response['data']);
          isLoading = false;
        });
      } else {
        setState(() {
          isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Routine Case History"),
        centerTitle: true,
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : caseHistory.isEmpty
              ? Center(
                  child: Text(
                    "No case history available.",
                    style: TextStyle(fontSize: 16, color: Colors.grey),
                  ),
                )
              : ListView.builder(
                  itemCount: caseHistory.length,
                  itemBuilder: (context, index) {
                    return GestureDetector(
                      onTap: () {
                        // Pass casesheet_id and patient_id to the next screen
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => RoutineView(
                              casesheetId: caseHistory[index]["casesheet_id"],
                              patientId: patient_id, // Assuming patient_id is defined globally
                            ),
                          ),
                        );
                      },
                      child: buildCaseCard(caseHistory[index]),
                    );
                  },
                ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ElevatedButton(
          onPressed: () {
            // Navigate to RoutineAddCaseSheet when the button is clicked
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => RoutineAddCaseSheet()),
            );
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.black, // Button color
            padding: EdgeInsets.symmetric(vertical: 15),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
          ),
          child: Text(
            "Add a New Report",
            style: TextStyle(color: Colors.white, fontSize: 16),
          ),
        ),
      ),
    );
  }

  Widget buildCaseCard(Map<String, dynamic> caseData) {
    return Card(
      margin: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10.0),
        side: BorderSide(color: Colors.grey.shade300), // Grey border
      ),
      color: Colors.white, // White background
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            buildRow("Casesheet ID", caseData["casesheet_id"] ?? ""),
            buildRow("Name", caseData["name"] ?? ""),
            buildRow("Date", caseData["date"] ?? ""),
          ],
        ),
      ),
    );
  }

  Widget buildRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            "$label :",
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          Text(value),
        ],
      ),
    );
  }
}
