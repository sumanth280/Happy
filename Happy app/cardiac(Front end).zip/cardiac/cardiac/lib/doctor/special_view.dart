import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '/api.dart';

// Function to fetch investigation special data
Future<Map<String, dynamic>> fetchInvestigationSpecialData(String specialCasesheetId) async {
  final uri = Uri.parse(Special_viewurl); // Use the URL from api.dart
  String patientId = patient_id; // Assuming patient_id is stored in api.dart

  try {
    final response = await http.post(
      uri,
      body: {
        'patient_id': patientId,
        'special_casesheet_id': specialCasesheetId,
      },
    );

    if (response.statusCode == 200) {
      final responseData = json.decode(response.body);
      print(responseData); // Print the entire response to check its structure

      // Check if the response contains data
      if (responseData['status'] == true) {
        var data = responseData['data'];

        // If 'data' is a list, we can check the first element and return it
        if (data is List && data.isNotEmpty) {
          return {
            'status': true,
            'message': responseData['message'],
            'data': data[0], // Access the first item in the list
          };
        } else {
          return {
            'status': false,
            'message': 'No data available',
          };
        }
      } else {
        return {
          'status': false,
          'message': responseData['message'] ?? 'No message available',
        };
      }
    } else {
      return {
        'status': false,
        'message': 'Server returned status code ${response.statusCode}',
      };
    }
  } catch (error) {
    return {
      'status': false,
      'message': 'An error occurred: $error',
    };
  }
}

class SpecialView extends StatefulWidget {
  final String specialCasesheetId;

  SpecialView({required this.specialCasesheetId});

  @override
  _SpecialViewState createState() => _SpecialViewState();
}

class _SpecialViewState extends State<SpecialView> {
  Map<String, dynamic>? investigationData;

  @override
  void initState() {
    super.initState();
    _fetchInvestigationData();
  }

  Future<void> _fetchInvestigationData() async {
    final data = await fetchInvestigationSpecialData(widget.specialCasesheetId);

    setState(() {
      if (data['status'] == true) {
        investigationData = data['data'];
      } else {
        investigationData = {
          'message': data['message'],
        };
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Investigation'),
        centerTitle: true,
      ),
      body: investigationData == null
          ? Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (investigationData!['message'] != null)
                    Center(
                      child: Text(
                        investigationData!['message'],
                        style: TextStyle(color: Colors.red, fontSize: 16),
                      ),
                    ),
                  if (investigationData!['message'] == null) ...[
                    InvestigationField(
                      label: 'H1BA1C',
                      unit: '%',
                      value: investigationData!['h1ba1c'] ?? 'N/A',
                    ),
                    InvestigationField(
                      label: 'Triglycerides',
                      unit: 'Mg/DL',
                      value: investigationData!['triglycerides'] ?? 'N/A',
                    ),
                    InvestigationField(
                      label: 'LDL',
                      unit: 'mg/DL',
                      value: investigationData!['ldl'] ?? 'N/A',
                    ),
                    InvestigationField(
                      label: 'HDL',
                      unit: 'mg/DL',
                      value: investigationData!['hdl'] ?? 'N/A',
                    ),
                    InvestigationField(
                      label: 'BNP',
                      unit: 'Pg/ml',
                      value: investigationData!['bnp'] ?? 'N/A',
                    ),
                    InvestigationField(
                      label: 'TSH',
                      unit: 'mlu/ml',
                      value: investigationData!['tsh'] ?? 'N/A',
                    ),
                    InvestigationField(
                      label: 'FT3',
                      unit: 'pg/ml',
                      value: investigationData!['ft3'] ?? 'N/A',
                    ),
                    InvestigationField(
                      label: 'FT4',
                      unit: 'ng/dl',
                      value: investigationData!['ft4'] ?? 'N/A',
                    ),
                    SectionLabel(label: 'ECG Findings'),
                    CommentBox(
                      content: investigationData!['ecg_findings'] ?? 'N/A',
                    ),
                    SectionLabel(label: 'ECHO Findings'),
                    CommentBox(
                      content: investigationData!['echo_findings'] ?? 'N/A',
                    ),
                    SectionLabel(label: 'USG Abdomen Findings'),
                    CommentBox(
                      content: investigationData!['usg_abdomen_findings'] ?? 'N/A',
                    ),
                    SectionLabel(label: 'Stage'),
                    InvestigationField(
                      label: 'Stage',
                      unit: '',
                      value: investigationData!['stage'] ?? 'N/A',
                    ),
                  ],
                ],
              ),
            ),
    );
  }
}

// Reusable Widget for Investigation Fields
class InvestigationField extends StatelessWidget {
  final String label;
  final String unit;
  final String value;

  const InvestigationField({
    required this.label,
    required this.unit,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 8.0),
      padding: EdgeInsets.all(12.0),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(
          color: Colors.grey.shade300,
          width: 2.0,
        ),
        borderRadius: BorderRadius.circular(20.0),
      ),
      child: Row(
        children: [
          Expanded(
            flex: 3,
            child: Text(
              label,
              style: TextStyle(fontSize: 16.0),
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              value,
              style: TextStyle(fontSize: 16.0),
            ),
          ),
          Expanded(
            flex: 1,
            child: Text(
              unit,
              textAlign: TextAlign.end,
              style: TextStyle(fontSize: 16.0, color: Colors.grey),
            ),
          ),
        ],
      ),
    );
  }
}

// Reusable Widget for Comment Boxes (for ECG, ECHO, USG)
class CommentBox extends StatelessWidget {
  final String content;

  const CommentBox({required this.content});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(12.0),
      margin: EdgeInsets.only(top: 8.0),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: Colors.grey.shade300),
        borderRadius: BorderRadius.circular(5.0),
      ),
      child: Text(content),
    );
  }
}

// Widget for Section Labels
class SectionLabel extends StatelessWidget {
  final String label;

  const SectionLabel({required this.label});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12.0),
      child: Text(
        label,
        style: TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 18,
          color: Colors.blueGrey,
        ),
      ),
    );
  }
}
