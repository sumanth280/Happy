import '/doctor/appointments.dart';
import '/doctor/health_metricsdoc.dart';
import '/doctor/investigation.dart';
import '/doctor/medication.dart';
import '/doctor/risk_primary.dart';
import '/doctor/symptom_monitoringdoc.dart';
import '/doctor/patient_profile.dart';
import '/api.dart'; // Import for global variables
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'dart:io';

class CaseSheetScreen extends StatelessWidget {
  // Remove 'final' keyword
  String name;
  String patientId;

  CaseSheetScreen({required this.name, required this.patientId}) {
    // Update global variables in api.dart
    patient_id = patientId;
    name = this.name; // Use 'this.name' to avoid shadowing
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Icon(Icons.emoji_emotions_outlined),
            SizedBox(width: 8), // Adds space between emoji and name
            Expanded(
              child: Text(
                name,
                style: TextStyle(color: Colors.teal, fontSize: 20, fontWeight: FontWeight.bold),
                overflow: TextOverflow.ellipsis, // Truncate the text if it's too long
              ),
            ),
            SizedBox(width: 10), // Adds some space between name and patient ID
            Text(
              patientId,
              style: TextStyle(color: Colors.teal, fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ],
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(vertical: 20.0, horizontal: 20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CustomButton(
              label: 'Medication',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MedicationScreen()),
                );
              },
            ),
            CustomButton(
              label: 'Appointments',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => AppointmentsScreen()),
                );
              },
            ),
            CustomButton(
              label: 'Symptom Monitoring',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => SymptomMonitoringDocScreen()),
                );
              },
            ),
            CustomButton(
              label: 'Health Metrics',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => HealthMetricsDocScreen()),
                );
              },
            ),
            CustomButton(
              label: 'Risk Stratification',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => RiskStratistificationScreen()),
                );
              },
            ),
            CustomButton(
              label: 'Investigation',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => InvestigationScreen()),
                );
              },
            ),
            CustomButton(
              label: 'Patient Profile',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => PatientProfileScreen()),
                );
              },
            ),
            CustomButton(
              label: 'Download Patient Data',
              onTap: () {
                // Show a confirmation dialog before downloading the data
                showDialog(
                  context: context,
                  builder: (context) {
                    return AlertDialog(
                      title: Text('Are you sure?'),
                      content: Text('Do you want to download the patient data as CSV?'),
                      actions: [
                        TextButton(
                          onPressed: () {
                            // Close the dialog
                            Navigator.pop(context);
                          },
                          child: Text('Cancel'),
                        ),
                        TextButton(
                          onPressed: () {
                            // Call the function to download the CSV
                            downloadPatientData(patientId, context);
                            Navigator.pop(context); // Close the dialog after action
                          },
                          child: Text('Download'),
                        ),
                      ],
                    );
                  },
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Future<void> downloadPatientData(String patientId, BuildContext context) async {
    try {
      // Send POST request to PHP API with the patient_id
      final response = await http.post(
        Uri.parse(Downloadurl),
        body: {'patient_id': patientId},
      );

      if (response.statusCode == 200) {
        // Prepare file path to save the CSV in Downloads folder
        final fileName = 'patient_data_$patientId.csv';
        final directory = Directory('/storage/emulated/0/Download');
        if (!(await directory.exists())) {
          await directory.create(recursive: true);
        }
        final filePath = '${directory.path}/$fileName';

        // Save the CSV data as a file
        final file = File(filePath);
        await file.writeAsBytes(response.bodyBytes);

        // Notify the user with a dialog
        showDialog(
          context: context,
          builder: (context) {
            return AlertDialog(
              title: Text('Download Complete'),
              content: Text('File saved to: $filePath'),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: Text('OK'),
                ),
              ],
            );
          },
        );

        print('File saved to $filePath');
      } else {
        print('Request failed with status: ${response.statusCode}');
      }
    } catch (error) {
      print('Error: $error');
    }
  }
}

class CustomButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;

  CustomButton({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: EdgeInsets.symmetric(vertical: 8.0),
      child: ElevatedButton(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(
          padding: EdgeInsets.symmetric(vertical: 16.0),
          backgroundColor: Colors.black87, // Button color
        ),
        child: Text(
          label,
          style: TextStyle(fontSize: 18, color: Colors.white),
        ),
      ),
    );
  }
}
