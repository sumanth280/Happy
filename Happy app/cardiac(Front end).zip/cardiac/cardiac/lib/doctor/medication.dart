import '/provider_doc/medication.dart';
import 'package:flutter/material.dart';
import 'add_medicine.dart'; // Add Medicine screen
import 'medication.dart'; // Import the API logic

class MedicationScreen extends StatefulWidget {
  @override
  _MedicationScreenState createState() => _MedicationScreenState();
}

class _MedicationScreenState extends State<MedicationScreen> {
  List<Map<String, dynamic>> medicines = [];

  @override
  void initState() {
    super.initState();
    fetchMedicinesData();
  }

  /// Fetch medicines and update the state
  Future<void> fetchMedicinesData() async {
    final result = await fetchMedicines();
    if (result['success']) {
      setState(() {
        medicines = List<Map<String, dynamic>>.from(result['medicines']);
      });
    } else {
      showSnackBar(result['message']);
    }
  }

  /// Delete a specific medicine by its ID
  Future<void> deleteMedicine(String medicineId) async {
    final result = await deleteMedicineApi(medicineId);
    if (result['success']) {
      fetchMedicinesData(); // Refresh the list after deletion
    }
    showSnackBar(result['message']);
  }

  /// Show a Snackbar with a message
  void showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Medication',
          style: TextStyle(color: Colors.black, fontSize: 24, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(vertical: 20.0, horizontal: 20.0),
        child: Column(
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => AddMedicineScreen()),
                ).then((_) => fetchMedicinesData()); // Refresh after adding medicine
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.black87,
                padding: EdgeInsets.symmetric(vertical: 20.0, horizontal: 40.0),
              ),
              child: Text('Add Medicine', style: TextStyle(color: Colors.white)),
            ),
            SizedBox(height: 30),
            Text('Current Dosage', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
            SizedBox(height: 20),
            Expanded(
              child: ListView.builder(
                itemCount: medicines.length,
                itemBuilder: (context, index) {
                  final medicine = medicines[index];

                  // Extract the medicine_id or id
                  final medicineId = medicine['id'] ?? medicine['medicine_id'];

                  return Card(
                    shape: RoundedRectangleBorder(
                      side: BorderSide(color: Colors.grey),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: ListTile(
                      contentPadding: EdgeInsets.symmetric(vertical: 10, horizontal: 15),
                      title: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            medicine['medicine_name'] ?? 'Unknown Medicine',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          Text(
                            '${medicine['days_left'] ?? 'N/A'} days left',
                            style: TextStyle(color: Colors.black),
                          ),
                        ],
                      ),
                      trailing: IconButton(
                        icon: Icon(Icons.delete, color: Colors.red),
                        onPressed: () {
                          if (medicineId != null) {
                            // Show a confirmation dialog before deleting
                            showDialog(
                              context: context,
                              builder: (context) => AlertDialog(
                                title: Text("Confirm Deletion"),
                                content: Text("Do you want to delete this medicine?"),
                                actions: [
                                  TextButton(
                                    onPressed: () => Navigator.of(context).pop(),
                                    child: Text("Cancel"),
                                  ),
                                  TextButton(
                                    onPressed: () async {
                                      Navigator.of(context).pop(); // Close the dialog
                                      await deleteMedicine(medicineId); // Delete the medicine
                                    },
                                    child: Text("Delete", style: TextStyle(color: Colors.red)),
                                  ),
                                ],
                              ),
                            );
                          } else {
                            showSnackBar('Medicine ID is missing.');
                          }
                        },
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
