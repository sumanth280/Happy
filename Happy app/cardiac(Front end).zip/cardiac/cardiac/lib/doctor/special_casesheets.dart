import '/doctor/special_view.dart';
import 'package:flutter/material.dart';
import '../provider_doc/special_casesheet.dart';
import '/api.dart';
import 'investigation_special.dart'; // Assuming this file contains patient_id and Special_casesheeturl
// New screen for adding a report

class Specialcasesheets extends StatefulWidget {
  @override
  _SpecialcasesheetsState createState() => _SpecialcasesheetsState();
}

class _SpecialcasesheetsState extends State<Specialcasesheets> {
  List<Map<String, dynamic>> caseHistory = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchCaseHistory();
  }

  // Fetch special case sheets from the API
  Future<void> fetchCaseHistory() async {
    try {
      final response = await fetchSpecialCasesheets(); // Fetch API data

      if (response['success']) {
        setState(() {
          caseHistory = List<Map<String, dynamic>>.from(response['data']);
          isLoading = false;
        });
      } else {
        print("API Error: ${response['message']}");
        setState(() {
          isLoading = false;
        });
      }
    } catch (e) {
      print("Exception while fetching case history: $e");
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Special Case History"),
        centerTitle: true,
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : caseHistory.isEmpty
              ? Center(
                  child: Text(
                    "No case history available.",
                    style: TextStyle(fontSize: 16, color: Colors.grey),
                  ),
                )
              : ListView.builder(
                  itemCount: caseHistory.length,
                  itemBuilder: (context, index) {
                    return buildCaseCard(caseHistory[index]);
                  },
                ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ElevatedButton(
          onPressed: () {
            // Navigate to AddNewReportScreen instead of the same screen
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => SpecialAddCaseSheet()),
            );
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.black, // Button color black
            padding: EdgeInsets.symmetric(vertical: 15),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
          ),
          child: Text(
            "Add New Report",
            style: TextStyle(color: Colors.white, fontSize: 16),
          ),
        ),
      ),
    );
  }

  // Build the card for each case history
  Widget buildCaseCard(Map<String, dynamic> caseData) {
    return GestureDetector(
      onTap: () {
        // Navigate to SpecialView with specialCasesheetId
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => SpecialView(
              specialCasesheetId: caseData["special_casesheet_id"],
            ),
          ),
        );
      },
      child: Card(
        margin: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10.0),
          side: BorderSide(color: Colors.grey.shade300),
        ),
        color: Colors.white,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              buildRow("Casesheet ID", caseData["special_casesheet_id"] ?? ""),
              buildRow("Name", caseData["name"] ?? ""),
              buildRow("Date", caseData["date"] ?? ""),
            ],
          ),
        ),
      ),
    );
  }

  // Helper method to create a row of label and value
  Widget buildRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            "$label :",
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          Text(value),
        ],
      ),
    );
  }
}
