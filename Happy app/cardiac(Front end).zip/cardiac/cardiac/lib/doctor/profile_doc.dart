import 'dart:io';
import 'dart:convert';
import '/provider_doc/profile_upload_doc.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import '/api.dart'; // Ensure profile_docurl, profile_upload_docurl, and doctor_id are defined here
import 'edit_profile_doc.dart';
import 'change_password_doc.dart';
import '/doctor/login_doc.dart';

class ProfilePage extends StatefulWidget {
  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  String? profileImageUrl;
  String userName = '';
  String userId = '';
  File? _selectedImage;
  final ImagePicker _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    _loadDoctorProfile(); // Fetch profile when the page is loaded
  }

  // Pick image from gallery
  Future<void> _pickImage() async {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Allow Media Access"),
          content: Text("This app needs access to your gallery to upload a profile picture."),
          actions: [
            TextButton(
              onPressed: () async {
                Navigator.pop(context); // Close the dialog
                final pickedFile = await _picker.pickImage(source: ImageSource.gallery);
                if (pickedFile != null) {
                  setState(() {
                    _selectedImage = File(pickedFile.path);
                  });
                  await _uploadDoctorProfileDocument(); // Call the upload API after image is selected
                }
              },
              child: Text("Allow"),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(context); // Close the dialog without action
              },
              child: Text("Don't Allow"),
            ),
          ],
        );
      },
    );
  }
void _showDeveloperPopup() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Developer Mark"),
          content: Text("App developed by - Sumanth Nerella\nHackcode - 2806S"),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context); // Close dialog
              },
              child: Text("OK"),
            ),
          ],
        );
      },
    );
  }
  // Upload selected document
  Future<void> _uploadDoctorProfileDocument() async {
    if (_selectedImage == null) return;

    // Call the upload API
    final response = await DoctorProfileApi.uploadDoctorProfileDocument(
      doctor_id: doctor_id,
      profileDoc: _selectedImage!,
    );

    if (response['status'] == true) {
      setState(() {
        profileImageUrl = '${response['profile_doc']}?v=${DateTime.now().millisecondsSinceEpoch}';
      });

      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text("Success"),
            content: Text("Profile picture uploaded successfully!"),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context); // Close dialog
                  _loadDoctorProfile(); // Reload profile data to refresh the page
                },
                child: Text("OK"),
              ),
            ],
          );
        },
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to upload profile picture: ${response['message']}')),
      );
    }
  }

  // Fetch doctor profile and image URL from DB
  Future<void> _loadDoctorProfile() async {
    final response = await fetchDoctorProfile(doctor_id);

    if (response['status'] == true) {
      setState(() {
        userName = response['doc_name'];
        userId = doctor_id;

        // Ensure profileImageUrl only updates if profile_doc is not null or empty
        profileImageUrl = response['profile_doc'];
        if (profileImageUrl != null && profileImageUrl!.isNotEmpty) {
          profileImageUrl = '$Baseurl$profileImageUrl?v=${DateTime.now().millisecondsSinceEpoch}';
        } else {
          profileImageUrl = null; // or provide a default image URL here
        }
      });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to load profile: ${response['message']}')),
      );
    }
  }
int _emojiClickCount = 0; // Counter for emoji and text clicks

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
  backgroundColor: Colors.white,
  elevation: 0,
  automaticallyImplyLeading: false,
  title: GestureDetector(
    onTap: () {
      // Increment counter and show popup after 5 taps
      setState(() {
        _emojiClickCount++;
        if (_emojiClickCount == 5) {
          _emojiClickCount = 0; // Reset the counter
          _showDeveloperPopup(); // Show the popup
        }
      });
    },
    child: Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          "Profile", // Emoji
          style: TextStyle(fontSize: 24),
        ),
        SizedBox(width: 8), // Spacing between emoji and text
        Text(
          '🙂',
          style: TextStyle(color: Colors.black, fontSize: 20),
        ),
      ],
    ),
  ),
  centerTitle: true,
),

      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(height: 30),
            Stack(
              alignment: Alignment.bottomRight,
              children: [
                CircleAvatar(
                  radius: 65,
                  backgroundImage: profileImageUrl != null && profileImageUrl!.isNotEmpty
                      ? NetworkImage(profileImageUrl!)
                      : AssetImage('assets/images/dp.jpg') as ImageProvider,
                  backgroundColor: Colors.grey[300],
                ),
                IconButton(
                  icon: Icon(Icons.camera_alt, color: Colors.black),
                  onPressed: _pickImage,
                ),
              ],
            ),
            SizedBox(height: 15),
            Text(
              userName,
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.w600),
            ),
            SizedBox(height: 5),
            Text(
              userId,
              style: TextStyle(fontSize: 16, color: Colors.black54),
            ),
            SizedBox(height: 5),
            Text(
              'Doctor',
              style: TextStyle(fontSize: 16, color: Colors.black54),
            ),
            SizedBox(height: 20),
            ProfileOption(
              icon: Icons.info_outline,
              text: 'Personal Details',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => PatientEditProfile()),
                );
              },
            ),
            ProfileOption(
              icon: Icons.lock_outline,
              text: 'Change Password',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ChangePasswordScreen()),
                );
              },
            ),
            ProfileOption(
              icon: Icons.logout,
              text: 'Logout',
              onTap: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => DoctorLoginScreen()),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class ProfileOption extends StatelessWidget {
  final IconData icon;
  final String text;
  final VoidCallback onTap;

  ProfileOption({required this.icon, required this.text, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: InkWell(
        onTap: onTap,
        child: Container(
          padding: EdgeInsets.symmetric(vertical: 15, horizontal: 20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(8),
            boxShadow: [
              BoxShadow(
                color: Colors.black12,
                blurRadius: 5,
                offset: Offset(0, 2),
              ),
            ],
          ),
          child: Row(
            children: [
              Icon(icon, color: Colors.black),
              SizedBox(width: 20),
              Expanded(
                child: Text(
                  text,
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                ),
              ),
              Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey),
            ],
          ),
        ),
      ),
    );
  }
}

// Doctor Profile APIs

Future<Map<String, dynamic>> fetchDoctorProfile(String doctor_id) async {
  final uri = Uri.parse(profile_docurl); // Ensure the profile_docurl is correctly defined in your API

  try {
    // Make the POST request with the doctor_id
    final response = await http.post(
      uri,
      body: {
        'doctor_id': doctor_id,
      },
    );

    // Check if the response status code is 200 (OK)
    if (response.statusCode == 200) {
      final responseData = json.decode(response.body);

      // Check if the response indicates success
      if (responseData['status'] == true) {
        return {
          'status': true,
          'doctor_id': doctor_id,
          'doc_name': responseData['doc_name'] ?? 'No Name Data', // doc_name
          'profile_doc': responseData['profile_doc'] ?? 'No Profile Data', // profile_doc
        };
      } else {
        return {
          'status': false,
          'message': responseData['message'] ?? 'Error retrieving data',
        };
      }
    } else {
      return {
        'status': false,
        'message': 'Server returned status code ${response.statusCode}',
      };
    }
  } catch (error) {
    return {
      'status': false,
      'message': 'An error occurred: $error',
    };
  }
}
