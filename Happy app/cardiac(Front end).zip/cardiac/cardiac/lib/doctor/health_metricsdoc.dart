import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../patient/health_metrics_trends.dart';
import '/api.dart'; // Assuming API endpoints are in 'api.dart'

class HealthMetricsDocScreen extends StatefulWidget {
  @override
  _HealthMetricsDocScreenState createState() => _HealthMetricsDocScreenState();
}

class _HealthMetricsDocScreenState extends State<HealthMetricsDocScreen> {
  bool isLoading = false;
  bool hasData = false; // Track if data is available

  // TextEditingControllers for each field
  TextEditingController pulseRateController = TextEditingController();
  TextEditingController spo2Controller = TextEditingController();
  TextEditingController bpController = TextEditingController();
  TextEditingController weightController = TextEditingController();
  TextEditingController activityController = TextEditingController();
  TextEditingController fluidIntakeController = TextEditingController();
  TextEditingController saltIntakeController = TextEditingController();
  TextEditingController urineOutputController = TextEditingController();

  @override
  void initState() {
    super.initState();
    fetchHealthMetrics();
  }

  // API Call to fetch health metrics data
  Future<void> fetchHealthMetrics() async {
    setState(() {
      isLoading = true;
    });

    try {
      String patientId = patient_id;

      final response = await http.post(
        Uri.parse(Health_metricsviewurl), // API URL for fetching metrics
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: {'patient_id': patientId},
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status'] == true && data['data'] != null && data['data'].isNotEmpty) {
          final metrics = data['data'][0];
          setState(() {
            pulseRateController.text = metrics['pulse_rate'] ?? '';
            spo2Controller.text = metrics['spo2'] ?? '';
            bpController.text = metrics['bp'] ?? '';
            weightController.text = metrics['weight'] ?? '';
            activityController.text = metrics['activity'] ?? '';
            fluidIntakeController.text = metrics['fluid_intake'] ?? '';
            saltIntakeController.text = metrics['salt_intake'] ?? '';
            urineOutputController.text = metrics['urine_output'] ?? '';
            hasData = true; // Data is available
          });
        } else {
          setState(() {
            hasData = false; // No data available
          });
        }
      } else {
        throw Exception('Failed to fetch data');
      }
    } catch (e) {
      showMessage('Error: $e');
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  // Function to show a popup message
  void showMessage(String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Message"),
          content: Text(message),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close the popup
              },
              child: Text("OK"),
            ),
          ],
        );
      },
    );
  }

  // Widget to build each metric row
  Widget _buildMetricRow(String metric, String unit, TextEditingController controller) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
      margin: EdgeInsets.symmetric(vertical: 8.0),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey.shade300),
        borderRadius: BorderRadius.circular(8.0),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            metric,
            style: TextStyle(fontSize: 16),
          ),
          Container(
            width: 150.0, // Adjusted width to fit the unit
            child: TextField(
              controller: controller,
              enabled: false, // Read-only
              decoration: InputDecoration(
                suffixText: unit, // Add the unit here
                suffixStyle: TextStyle(color: Colors.grey, fontSize: 14),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8.0),
                  borderSide: BorderSide(color: Colors.grey.shade300),
                ),
                contentPadding: EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Widget for "Today" tab
  Widget _buildTodayView() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(height: 20.0),
          isLoading
              ? CircularProgressIndicator()
              : Expanded(
                  child: ListView(
                    children: [
                      _buildMetricRow('Pulse Rate', 'bpm', pulseRateController),
                      _buildMetricRow('SPO2', '%', spo2Controller),
                      _buildMetricRow('BP', 'mm/Hg', bpController),
                      _buildMetricRow('Weight', 'kg', weightController),
                      _buildMetricRow('Activity', 'km', activityController),
                      _buildMetricRow('Fluid Intake', 'ml/l', fluidIntakeController),
                      _buildMetricRow('Salt Intake', 'mg', saltIntakeController),
                      _buildMetricRow('Urine Output', 'ml', urineOutputController),
                    ],
                  ),
                ),
          SizedBox(height: 16.0),
          Text(
            hasData ? 'Data Available' : 'Patient yet to enter data',
            style: TextStyle(fontSize: 16, color: hasData ? Colors.green : Colors.redAccent),
          ),
          SizedBox(height: 24.0),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 0,
          title: Text('Health Metrics', style: TextStyle(color: Colors.black, fontSize: 22)),
          centerTitle: true,
          bottom: TabBar(
            labelColor: Colors.black,
            indicatorColor: Colors.lightGreen,
            tabs: [
              Tab(text: 'Today'),
              Tab(text: 'Trends'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _buildTodayView(),
            HealthMetricsTrends(),
          ],
        ),
      ),
    );
  }
}
