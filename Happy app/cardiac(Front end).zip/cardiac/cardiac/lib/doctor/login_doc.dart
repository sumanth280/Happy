import '/provider_doc/login_doc.dart';
import 'package:flutter/material.dart';
import '/doctor/home_doc.dart'; // Import Home Screen for doctors
import '/provider/login.dart';
import '/api.dart';

class DoctorLoginScreen extends StatefulWidget {
  @override
  _DoctorLoginScreenState createState() => _DoctorLoginScreenState();
}

class _DoctorLoginScreenState extends State<DoctorLoginScreen> {
  bool _isPasswordVisible = false; // Password visibility state
  final TextEditingController _doctorIdController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  bool _isLoading = false;

  // Function to show error dialog
  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Login Failed"),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: Text("OK"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(height: 40),
              Text(
                'Welcome',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w500),
              ),
              SizedBox(height: 10),
              Text(
                'Cardio Care - Doctor',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 20),

              // Logo Container with Circular Background
              Container(
                width: 160,
                height: 160,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white,
                ),
                child: Center(
                  child: Image.asset(
                    'assets/images/logo.jpg',
                    width: 110,
                    height: 110,
                  ),
                ),
              ),
              SizedBox(height: 20),

              TextField(
                controller: _doctorIdController,
                decoration: InputDecoration(
                  labelText: 'Doctor ID',
                  hintText: 'Enter your Doctor ID',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 20),
              
              // Password TextField with visibility toggle
              TextField(
                controller: _passwordController,
                obscureText: !_isPasswordVisible,
                decoration: InputDecoration(
                  labelText: 'Password',
                  hintText: 'Enter your Password',
                  border: OutlineInputBorder(),
                  suffixIcon: IconButton(
                    icon: Icon(
                      _isPasswordVisible ? Icons.visibility : Icons.visibility_off,
                    ),
                    onPressed: () {
                      setState(() {
                        _isPasswordVisible = !_isPasswordVisible;
                      });
                    },
                  ),
                ),
              ),
              SizedBox(height: 10),
              
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                  onPressed: () {
                    // Forgot password functionality
                  },
                  child: Text('Forget Password'),
                ),
              ),
              SizedBox(height: 20),
              
              _isLoading
                  ? CircularProgressIndicator() // Show loading spinner
                  : ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.black,
                        padding: EdgeInsets.symmetric(horizontal: 80, vertical: 15),
                      ),
                      onPressed: () async {
                        // Call login function with entered credentials
                        final doctorId = _doctorIdController.text;
                        final password = _passwordController.text;

                        if (doctorId.isNotEmpty && password.isNotEmpty) {
                          setState(() => _isLoading = true);
                          final response = await doctorLogin(doctorId, password, context);
                          setState(() => _isLoading = false);

                          if (!response["success"]) {
                            _showErrorDialog(response["message"]);
                          }
                        } else {
                          _showErrorDialog("Please enter both Doctor ID and password.");
                        }
                      },
                      child: Text('Sign In'),
                    ),
              SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }
}
