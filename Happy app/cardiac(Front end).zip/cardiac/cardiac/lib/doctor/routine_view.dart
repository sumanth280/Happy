import 'package:flutter/material.dart';
import '../provider_doc/investigation_routinesview.dart';
import '/api.dart'; // Import your API file where URLs and patient_id are defined

class RoutineView extends StatefulWidget {
  final String casesheetId;
  final String patientId;

  const RoutineView({required this.casesheetId, required this.patientId});

  @override
  _RoutineViewState createState() => _RoutineViewState();
}

class _RoutineViewState extends State<RoutineView> {
  Map<String, dynamic> investigationData = {};
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchInvestigationData();
  }

  Future<void> fetchInvestigationData() async {
    try {
      final response = await fetchInvestigationRoutineData(widget.casesheetId);

      if (response['status'] == true) {
        setState(() {
          // Access the first object in the data array
          if (response['data'] != null && response['data'].isNotEmpty) {
            investigationData = response['data'][0]; // Fetch first object
          }
          isLoading = false;
        });
      } else {
        setState(() {
          isLoading = false;
        });

        // Show error message
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: Text('Error'),
            content: Text(response['message']),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: Text('OK'),
              ),
            ],
          ),
        );
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      print("Error fetching data: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Investigation Details'),
        centerTitle: true,
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SectionHeader(title: 'CBC:'),
                  InvestigationField(
                    label: 'Hb',
                    unit: 'g/dl',
                    value: investigationData['cbc_hb'] ?? 'N/A',
                  ),
                  InvestigationField(
                    label: 'TLC',
                    unit: 'cells/cum',
                    value: investigationData['cbc_tlc'] ?? 'N/A',
                  ),
                  SizedBox(height: 16.0),
                  SectionHeader(title: 'RFT:'),
                  InvestigationField(
                    label: 'Creatinine',
                    unit: 'mg/dl',
                    value: investigationData['rft_creatinine'] ?? 'N/A',
                  ),
                  SizedBox(height: 16.0),
                  SectionHeader(title: 'LFT:'),
                  InvestigationField(
                    label: 'SGOT/AST',
                    unit: 'IU/L',
                    value: investigationData['sgot'] ?? 'N/A',
                  ),
                  InvestigationField(
                    label: 'SGPT/ALT',
                    unit: 'IU/L',
                    value: investigationData['sgpt'] ?? 'N/A',
                  ),
                  InvestigationField(
                    label: 'Total Bilirubin',
                    unit: 'mg/dL',
                    value: investigationData['total_bilibubin'] ?? 'N/A',
                  ),
                  SizedBox(height: 16.0),
                  SectionHeader(title: 'Electrolytes:'),
                  InvestigationField(
                    label: 'Sodium',
                    unit: 'meq/L',
                    value: investigationData['sodium'] ?? 'N/A',
                  ),
                  InvestigationField(
                    label: 'Potassium',
                    unit: 'meq/L',
                    value: investigationData['pottasium'] ?? 'N/A',
                  ),
                  InvestigationField(
                    label: 'Chloride',
                    unit: 'meq/L',
                    value: investigationData['chloride'] ?? 'N/A',
                  ),
                  InvestigationField(
                    label: 'Sodium Bicarbonate',
                    unit: 'meq/L',
                    value: investigationData['sodium_bicarbonate'] ?? 'N/A',
                  ),
                  SizedBox(height: 20.0),
                ],
              ),
            ),
    );
  }
}

class SectionHeader extends StatelessWidget {
  final String title;

  const SectionHeader({required this.title});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Text(
        title,
        style: TextStyle(fontSize: 18.0, fontWeight: FontWeight.bold),
      ),
    );
  }
}

class InvestigationField extends StatelessWidget {
  final String label;
  final String unit;
  final String value;

  const InvestigationField({
    required this.label,
    required this.unit,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 8.0),
      padding: EdgeInsets.all(12.0),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(
          color: Colors.grey.shade300,
          width: 2.0,
        ),
        borderRadius: BorderRadius.circular(20.0),
      ),
      child: Row(
        children: [
          Expanded(
            flex: 3,
            child: Text(
              label,
              style: TextStyle(fontSize: 16.0),
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              value,
              style: TextStyle(fontSize: 16.0),
            ),
          ),
          Expanded(
            flex: 1,
            child: Text(
              unit,
              textAlign: TextAlign.end,
              style: TextStyle(fontSize: 16.0, color: Colors.grey),
            ),
          ),
        ],
      ),
    );
  }
}
