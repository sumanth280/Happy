import '/patient/appointment_history.dart';
import 'book_appointment.dart'; // Import the BookAppointmentScreen
import 'package:flutter/material.dart';
import '/api.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class AppointmentsScreen extends StatefulWidget {
  @override
  _AppointmentsScreenState createState() => _AppointmentsScreenState();
}

class _AppointmentsScreenState extends State<AppointmentsScreen> {
  List<Map<String, dynamic>> appointments = [];
  bool isLoading = true;
  String message = '';

  // Function to fetch pending appointments
  Future<void> fetchAppointments() async {
    final url = Uri.parse(My_appointmentsurl);

    try {
      // Send POST request with patient_id
      final response = await http.post(
        url,
        body: {
          'patient_id': patient_id,
        },
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        if (data['status'] == true) {
          setState(() {
            appointments = List<Map<String, dynamic>>.from(data['data']);
            isLoading = false;
            message = data['message'];
          });
        } else {
          setState(() {
            isLoading = false;
            message = data['message'];
          });
        }
      } else {
        setState(() {
          isLoading = false;
          message = 'Failed to load appointments. Please try again later.';
        });
      }
    } catch (e) {
      setState(() {
        isLoading = false;
        message = 'An error occurred: $e';
      });
    }
  }

  @override
  void initState() {
    super.initState();
    fetchAppointments();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Appointments', style: TextStyle(color: Colors.black)),
        backgroundColor: Colors.white,
        centerTitle: true,
        elevation: 0,
        automaticallyImplyLeading: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Upcoming',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8.0),
            Expanded(
              child: isLoading
                  ? Center(child: CircularProgressIndicator())
                  : appointments.isEmpty
                      ? Center(
                          child: Text(
                            'No upcoming appointments.',
                            style: TextStyle(fontSize: 16, color: Colors.grey),
                          ),
                        )
                      : ListView.builder(
                          itemCount: appointments.length,
                          itemBuilder: (context, index) {
                            return Container(
                              margin: EdgeInsets.symmetric(vertical: 8.0),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(8.0),
                                border: Border.all(
                                  color: Colors.grey,
                                  width: 1.0,
                                ),
                              ),
                              child: AppointmentCard(
                                name: appointments[index]['name'] ?? 'N/A',
                                date: appointments[index]['date'] ?? 'N/A',
                                time: appointments[index]['time'] ?? 'N/A',
                                profilePic: appointments[index]['profile_pic'] ?? '',
                              ),
                            );
                          },
                        ),
            ),
            SizedBox(height: 16.0),
            Align(
              alignment: Alignment.center,
              child: Column(
                children: [
                  ElevatedButton.icon(
                    onPressed: () {
                      // Navigate to BookAppointmentScreen
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => BookAppointmentScreen(),
                        ),
                      );
                    },
                    icon: Icon(Icons.add),
                    label: Text('Set New Appointment'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.grey[850], // Slightly lighter black
                      padding: EdgeInsets.symmetric(vertical: 16.0, horizontal: 24.0),
                      fixedSize: Size(240, 56), // Ensure both buttons are the same size
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                    ),
                  ),
                  SizedBox(height: 16.0),
                  ElevatedButton.icon(
                    onPressed: () {
                      // Navigate to the AppointmentHistoryScreen
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => AppointmentHistoryScreen(),
                        ),
                      );
                    },
                    icon: Icon(Icons.history),
                    label: Text('Appointment History'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.grey[850], // Slightly lighter black
                      padding: EdgeInsets.symmetric(vertical: 16.0, horizontal: 24.0),
                      fixedSize: Size(240, 56), // Ensure both buttons are the same size
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class AppointmentCard extends StatelessWidget {
  final String name;
  final String date;
  final String time;
  final String profilePic;

  AppointmentCard({required this.name, required this.date, required this.time, this.profilePic = ''});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Row(
        children: [
          Icon(Icons.person, size: 40, color: Colors.grey),
          SizedBox(width: 16.0),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Text('Name :', style: TextStyle(fontSize: 16)),
                  SizedBox(width: 8),
                  Text(name, style: TextStyle(fontSize: 16)),
                ],
              ),
              Row(
                children: [
                  Text('Date   :', style: TextStyle(fontSize: 16)),
                  SizedBox(width: 8),
                  Text(date, style: TextStyle(fontSize: 16)),
                ],
              ),
              Row(
                children: [
                  Text('Time  :', style: TextStyle(fontSize: 16)),
                  SizedBox(width: 8),
                  Text(time, style: TextStyle(fontSize: 16)),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}
