import 'package:flutter/material.dart';
import '../provider_doc/investigation_routines.dart';
import '/api.dart';
import 'routine_casesheets.dart'; // Import your API file where URLs and patient_id are defined

class RoutineAddCaseSheet extends StatefulWidget {
  @override
  _RoutineAddCaseSheetState createState() => _RoutineAddCaseSheetState();
}

class _RoutineAddCaseSheetState extends State<RoutineAddCaseSheet> {
  // TextEditingController for each input field
  final TextEditingController hbController = TextEditingController();
  final TextEditingController tlcController = TextEditingController();
  final TextEditingController creatinineController = TextEditingController();
  final TextEditingController sgotController = TextEditingController();
  final TextEditingController sgptController = TextEditingController();
  final TextEditingController bilibubinController = TextEditingController();
  final TextEditingController sodiumController = TextEditingController();
  final TextEditingController potassiumController = TextEditingController();
  final TextEditingController chlorideController = TextEditingController();
  final TextEditingController sodiumBicarbController = TextEditingController();

  // FocusNode to handle highlighting input fields
  final FocusNode hbFocusNode = FocusNode();
  final FocusNode tlcFocusNode = FocusNode();
  final FocusNode creatinineFocusNode = FocusNode();
  final FocusNode sgotFocusNode = FocusNode();
  final FocusNode sgptFocusNode = FocusNode();
  final FocusNode bilibubinFocusNode = FocusNode();
  final FocusNode sodiumFocusNode = FocusNode();
  final FocusNode potassiumFocusNode = FocusNode();
  final FocusNode chlorideFocusNode = FocusNode();
  final FocusNode sodiumBicarbFocusNode = FocusNode();

  @override
  void dispose() {
    // Dispose controllers and focus nodes
    hbController.dispose();
    tlcController.dispose();
    creatinineController.dispose();
    sgotController.dispose();
    sgptController.dispose();
    bilibubinController.dispose();
    sodiumController.dispose();
    potassiumController.dispose();
    chlorideController.dispose();
    sodiumBicarbController.dispose();

    hbFocusNode.dispose();
    tlcFocusNode.dispose();
    creatinineFocusNode.dispose();
    sgotFocusNode.dispose();
    sgptFocusNode.dispose();
    bilibubinFocusNode.dispose();
    sodiumFocusNode.dispose();
    potassiumFocusNode.dispose();
    chlorideFocusNode.dispose();
    sodiumBicarbFocusNode.dispose();

    super.dispose();
  }

  Future<void> submitData() async {
    // Call the API function
    final response = await addInvestigationRoutine(
      cbcHb: hbController.text,
      cbcTlc: tlcController.text,
      rftCreatinine: creatinineController.text,
      sgot: sgotController.text,
      sgpt: sgptController.text,
      totalBilirubin: bilibubinController.text,
      sodium: sodiumController.text,
      potassium: potassiumController.text,
      chloride: chlorideController.text,
      sodiumBicarbonate: sodiumBicarbController.text,
    );

    // Show a dialog with the response
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(response['status'] ? 'Success' : 'Error'),
        content: Text(response['message']),
        actions: [
         TextButton(
  onPressed: () {
    Navigator.pop(context); // Close the dialog first
    if (response['status']) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => RoutinecaseSheets(), // Replace with your desired widget
        ),
      );
    }
  },
  child: Text('OK'),
)

        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Investigation'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SectionHeader(title: 'CBC:'),
            InvestigationField(
              label: 'Hb',
              unit: 'g/dl',
              controller: hbController,
              focusNode: hbFocusNode,
            ),
            InvestigationField(
              label: 'TLC',
              unit: 'cells/cum',
              controller: tlcController,
              focusNode: tlcFocusNode,
            ),
            SizedBox(height: 16.0),
            SectionHeader(title: 'RFT:'),
            InvestigationField(
              label: 'Creatinine',
              unit: 'mg/dl',
              controller: creatinineController,
              focusNode: creatinineFocusNode,
            ),
            SizedBox(height: 16.0),
            SectionHeader(title: 'LFT:'),
            InvestigationField(
              label: 'SGOT/AST',
              unit: 'IU/L',
              controller: sgotController,
              focusNode: sgotFocusNode,
            ),
            InvestigationField(
              label: 'SGPT/ALT',
              unit: 'IU/L',
              controller: sgptController,
              focusNode: sgptFocusNode,
            ),
            InvestigationField(
              label: 'Total Bilibubin',
              unit: 'mg/dL',
              controller: bilibubinController,
              focusNode: bilibubinFocusNode,
            ),
            SizedBox(height: 16.0),
            SectionHeader(title: 'Electrolytes:'),
            InvestigationField(
              label: 'Sodium',
              unit: 'meq/L',
              controller: sodiumController,
              focusNode: sodiumFocusNode,
            ),
            InvestigationField(
              label: 'Potassium',
              unit: 'meq/L',
              controller: potassiumController,
              focusNode: potassiumFocusNode,
            ),
            InvestigationField(
              label: 'Chloride',
              unit: 'meq/L',
              controller: chlorideController,
              focusNode: chlorideFocusNode,
            ),
            InvestigationField(
              label: 'Sodium Bicarbonate',
              unit: 'meq/L',
              controller: sodiumBicarbController,
              focusNode: sodiumBicarbFocusNode,
            ),
            SizedBox(height: 20.0),
            Center(
              child: ElevatedButton(
                onPressed: submitData,
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.symmetric(horizontal: 40.0, vertical: 16.0),
                  backgroundColor: Colors.black,
                ),
                child: Text(
                  'Save',
                  style: TextStyle(color: Colors.white, fontSize: 16.0),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class SectionHeader extends StatelessWidget {
  final String title;

  const SectionHeader({required this.title});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Text(
        title,
        style: TextStyle(fontSize: 18.0, fontWeight: FontWeight.bold),
      ),
    );
  }
}

class InvestigationField extends StatelessWidget {
  final String label;
  final String unit;
  final TextEditingController controller;
  final FocusNode focusNode;

  const InvestigationField({
    required this.label,
    required this.unit,
    required this.controller,
    required this.focusNode,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 8.0),
      padding: EdgeInsets.all(12.0),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(
          color: focusNode.hasFocus ? Colors.green : Colors.grey.shade300,
          width: 2.0,
        ),
        borderRadius: BorderRadius.circular(20.0), // Increased border radius
      ),
      child: Row(
        children: [
          Expanded(
            flex: 3,
            child: Text(
              label,
              style: TextStyle(fontSize: 16.0),
            ),
          ),
          Expanded(
            flex: 2,
            child: TextField(
              controller: controller,
              focusNode: focusNode,
              keyboardType: TextInputType.text, // Text input for all fields
              decoration: InputDecoration(
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(vertical: 0),
              ),
            ),
          ),
          Expanded(
            flex: 1,
            child: Text(
              unit,
              textAlign: TextAlign.end,
              style: TextStyle(fontSize: 16.0, color: Colors.grey),
            ),
          ),
        ],
      ),
    );
  }
}
