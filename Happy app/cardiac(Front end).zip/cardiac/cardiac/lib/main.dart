import 'package:flutter/material.dart';
import 'select_login.dart'; // Import the lucky.dart file

void main() {
  runApp(const CardioCareApp());
}

class CardioCareApp extends StatelessWidget {
  const CardioCareApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        scaffoldBackgroundColor: Color(0xFFF7F6FA),
      ),
      home: CardioCareScreen(),
    );
  }
}

class CardioCareScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Spacer at the top
            Expanded(flex: 2, child: Container()),

            // Welcome Text
            Padding(
              padding: const EdgeInsets.only(bottom: 5.0),
              child: Text(
                'Welcome',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
            ),

            // App Title Text
            Padding(
              padding: const EdgeInsets.only(bottom: 90.0), // Increased bottom padding here
              child: Text(
                'Cardio care',
                style: TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
            ),

            // Logo Image with increased size
            Container(
              width: 160,  // Increased width
              height: 160, // Increased height
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white,
              ),
              child: Center(
                child: Image.asset(
                  'assets/images/logo.jpg',
                  width: 110,  // Increased logo width
                  height: 110, // Increased logo height
                ),
              ),
            ),
            SizedBox(height: 40), // Increased space here

            // Subtitle Text
            Text(
              'Wherever You Are\nHealth Is Number One',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            SizedBox(height: 20),

            // Description Text
            Text(
              'There is no instant way to a healthy life',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey[700],
              ),
            ),
            SizedBox(height: 20),

            // Increased Spacer to move the green line and button further down
            Expanded(flex: 3, child: Container()),

            // Green Line Design
            Container(
              width: 60,
              height: 4,
              color: Colors.green,
            ),
            SizedBox(height: 40),

            // Get Started Button
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24.0),
              child: SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    // Navigate to LuckyScreen when "Get Started" is clicked
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => SelectionScreen()), // Navigate to LuckyScreen
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.black,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    padding: EdgeInsets.symmetric(vertical: 16),
                  ),
                  child: Text(
                    'Get Started',
                    style: TextStyle(
                      fontSize: 18,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ),

            // Reduced Spacer at the bottom
            Expanded(flex: 1, child: Container()),
          ],
        ),
      ),
    );
  }
}
