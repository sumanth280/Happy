package com.simats.happy

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
