import 'package:Happy/main.dart';
import 'package:Happy/select_login.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('CardioCareApp UI test', (WidgetTester tester) async {
    // Build the app and trigger a frame.
    await tester.pumpWidget(const CardioCareApp());

    // Verify the presence of the welcome text.
    expect(find.text('Welcome'), findsOneWidget);

    // Verify the presence of the app title.
    expect(find.text('Cardio care'), findsOneWidget);

    // Verify the presence of the subtitle text.
    expect(find.textContaining('Health Is Number One'), findsOneWidget);

    // Verify the presence of the "Get Started" button.
    expect(find.text('Get Started'), findsOneWidget);

    // Verify the presence of the green line design.
    expect(find.byType(Container), findsWidgets);

    // Verify tapping the "Get Started" button navigates to the SelectionScreen.
    await tester.tap(find.text('Get Started'));
    await tester.pumpAndSettle();

    // Confirm navigation occurred (you'll need to mock SelectionScreen if it has functionality).
    expect(find.byType(SelectionScreen), findsOneWidget);
  });
}
