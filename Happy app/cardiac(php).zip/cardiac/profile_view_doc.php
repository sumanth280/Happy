<?php
include 'con.php'; // Include your database connection file

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if doctor_id is provided
    if (!isset($_POST['doctor_id']) || empty(trim($_POST['doctor_id']))) {
        echo json_encode([
            'status' => false,
            'message' => 'doctor_id is required.'
        ], JSON_PRETTY_PRINT);
        exit;
    }

    // Get the doctor_id from the POST request
    $doctor_id = trim($_POST['doctor_id']);

    // Prepare the SQL statement to fetch the profile_doc and doc_name for the given doctor_id
    $sql = "SELECT profile_doc, doc_name FROM doctor_profile WHERE doctor_id = ?";

    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("s", $doctor_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            echo json_encode([
                'status' => true,
                'message' => 'Profile found for the provided doctor_id.',
                'doctor_id' => $doctor_id,
                'doc_name' => $row['doc_name'] ?? 'No Name Data',
                'profile_doc' => $row['profile_doc'] ?? 'No Profile Data'
            ], JSON_PRETTY_PRINT);
        } else {
            echo json_encode([
                'status' => false,
                'message' => 'No profile found for this doctor_id.'
            ], JSON_PRETTY_PRINT);
        }

        $stmt->close();
    } else {
        echo json_encode([
            'status' => false,
            'message' => 'Error in SQL preparation: ' . $conn->error
        ], JSON_PRETTY_PRINT);
    }

    $conn->close();
} else {
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.'
    ], JSON_PRETTY_PRINT);
}
?>
