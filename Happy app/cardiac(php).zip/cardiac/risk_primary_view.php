<?php
include 'con.php'; // Include your database connection file

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect the patient_id from the POST request
    $patient_id = $_POST['patient_id'] ?? null;

    // Check if patient_id is provided
    if (!$patient_id) {
        echo json_encode([
            'status' => false,
            'message' => 'Patient ID is required.',
        ], JSON_PRETTY_PRINT);
        exit;
    }

    // Prepare the SQL query to fetch data from risk_primary for the given patient_id
    $sql = "SELECT * FROM risk_primary WHERE patient_id = ?";

    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        echo json_encode([
            'status' => false,
            'message' => 'Failed to prepare SQL statement.',
        ], JSON_PRETTY_PRINT);
        exit;
    }

    // Bind the parameter to the SQL query
    $stmt->bind_param("s", $patient_id);

    // Execute the statement
    if ($stmt->execute()) {
        $result = $stmt->get_result();

        // Check if any data is found
        if ($result->num_rows > 0) {
            $data = $result->fetch_assoc();
            echo json_encode([
                'status' => true,
                'message' => 'Data retrieved successfully.',
                'data' => $data,
            ], JSON_PRETTY_PRINT);
        } else {
            echo json_encode([
                'status' => false,
                'message' => 'No data found for the given patient ID.',
            ], JSON_PRETTY_PRINT);
        }
    } else {
        echo json_encode([
            'status' => false,
            'message' => 'Failed to execute query.',
        ], JSON_PRETTY_PRINT);
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method. Use POST.',
    ], JSON_PRETTY_PRINT);
}
?>
