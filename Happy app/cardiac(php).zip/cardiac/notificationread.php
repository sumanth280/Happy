<?php
// Include database connection
include 'con.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve patient_id from the POST request
    $patient_id = isset($_POST['patient_id']) ? $_POST['patient_id'] : '';

    if (empty($patient_id)) {
        echo json_encode(['status' => false, 'message' => 'Patient ID is required']);
        exit;
    }

    try {
        // Get the current day and time
        $currentDay = strtolower(date('l')); // e.g., 'monday', 'tuesday', etc.
        $currentTime = date('H:i:s');

        // Query to find notifications for the given patient_id, current day, and time
        $query = "SELECT patient_id, notification_id, medicine_name, time_med FROM notification 
                  WHERE patient_id = ? 
                  AND `$currentDay` = 'yes' 
                  AND time_med <= ? 
                  AND status = ''";

        $stmt = $conn->prepare($query);
        $stmt->bind_param('ss', $patient_id, $currentTime);
        $stmt->execute();
        $result = $stmt->get_result();

        // Check if notifications exist
        if ($result->num_rows > 0) {
            // Insert matching notifications into the alerts table
            $insertQuery = "INSERT INTO alerts (patient_id, notification_id, medicine_name, time_med, status) 
                            SELECT ?, ?, ?, ?, 0 
                            WHERE NOT EXISTS (
                                SELECT 1 FROM alerts 
                                WHERE patient_id = ? 
                                AND notification_id = ? 
                                AND DATE(time_stamp) = CURDATE()
                            )";
            $insertStmt = $conn->prepare($insertQuery);

            while ($row = $result->fetch_assoc()) {
                $insertStmt->bind_param(
                    'ssssss',
                    $row['patient_id'],
                    $row['notification_id'],
                    $row['medicine_name'],
                    $row['time_med'],
                    $row['patient_id'],
                    $row['notification_id']
                );
                $insertStmt->execute();
            }

            echo json_encode(['status' => true, 'message' => 'Notifications processed and added to alerts table']);
        } else {
            echo json_encode(['status' => false, 'message' => 'No matching notifications found']);
        }
    } catch (Exception $e) {
        echo json_encode(['status' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['status' => false, 'message' => 'Invalid request method']);
}
?>
