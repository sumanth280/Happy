<?php
include 'con.php'; // Include your database connection file

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect the data from the POST request
    $patient_id = $_POST['patient_id'] ?? null;
    $ankle_edema = $_POST['ankle_edema'] ?? null;
    $dyspnea_on_exertion = $_POST['dyspnea_on_exertion'] ?? null;
    $hapatomegaly = $_POST['hapatomegaly'] ?? null;
    $nocturnal_cough = $_POST['nocturnal_cough'] ?? null;
    $pleural_effusion = $_POST['pleural_effusion'] ?? null;
    $tachycardia_hr = $_POST['tachycardia_hr'] ?? null;

    // Check if patient_id is provided
    if (!$patient_id) {
        echo json_encode([
            'status' => false,
            'message' => 'Patient ID is required.',
        ], JSON_PRETTY_PRINT);
        exit;
    }

    // Check if patient_id exists in the risk_minor table
    $check_sql = "SELECT patient_id FROM risk_minor WHERE patient_id = ?";
    $check_stmt = $conn->prepare($check_sql);
    if ($check_stmt === false) {
        echo json_encode([
            'status' => false,
            'message' => 'Failed to prepare SQL statement for checking patient ID.',
        ], JSON_PRETTY_PRINT);
        exit;
    }
    $check_stmt->bind_param("s", $patient_id);
    $check_stmt->execute();
    $check_stmt->store_result();

    if ($check_stmt->num_rows > 0) {
        // If patient_id exists, update the record
        $sql = "UPDATE risk_minor SET 
                    ankle_edema = ?, 
                    dyspnea_on_exertion = ?, 
                    hapatomegaly = ?, 
                    nocturnal_cough = ?, 
                    pleural_effusion = ?, 
                    tachycardia_hr = ?
                WHERE patient_id = ?";
        $stmt = $conn->prepare($sql);
        if ($stmt === false) {
            echo json_encode([
                'status' => false,
                'message' => 'Failed to prepare SQL statement for update.',
            ], JSON_PRETTY_PRINT);
            exit;
        }
        $stmt->bind_param("sssssss", $ankle_edema, $dyspnea_on_exertion, $hapatomegaly, $nocturnal_cough, $pleural_effusion, $tachycardia_hr, $patient_id);
    } else {
        // If patient_id doesn't exist, insert a new record
        $sql = "INSERT INTO risk_minor (
                    patient_id, 
                    ankle_edema, 
                    dyspnea_on_exertion, 
                    hapatomegaly, 
                    nocturnal_cough, 
                    pleural_effusion, 
                    tachycardia_hr
                ) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        if ($stmt === false) {
            echo json_encode([
                'status' => false,
                'message' => 'Failed to prepare SQL statement for insert.',
            ], JSON_PRETTY_PRINT);
            exit;
        }
        $stmt->bind_param("sssssss", $patient_id, $ankle_edema, $dyspnea_on_exertion, $hapatomegaly, $nocturnal_cough, $pleural_effusion, $tachycardia_hr);
    }

    // Execute the statement
    if ($stmt->execute()) {
        echo json_encode([
            'status' => true,
            'message' => $check_stmt->num_rows > 0 ? 'Data updated successfully.' : 'Data inserted successfully.',
        ], JSON_PRETTY_PRINT);
    } else {
        echo json_encode([
            'status' => false,
            'message' => 'Failed to execute query.',
        ], JSON_PRETTY_PRINT);
    }

    // Close the statements and connection
    $stmt->close();
    $check_stmt->close();
    $conn->close();
} else {
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.',
    ], JSON_PRETTY_PRINT);
}
?>
