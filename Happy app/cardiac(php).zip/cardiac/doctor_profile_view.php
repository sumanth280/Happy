<?php
include 'con.php'; // Include your database connection file

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect the doctor_id from the POST request
    $doctor_id = $_POST['doctor_id'] ?? null;

    // Check if doctor_id is provided
    if (!$doctor_id) {
        echo json_encode([
            'status' => false,
            'message' => 'Doctor ID is required.'
        ], JSON_PRETTY_PRINT);
        exit;
    }

    // Prepare the SQL statement to fetch the data from the doctor_profile table
    $sql = "SELECT * FROM doctor_profile WHERE doctor_id = ?";
    $stmt = $conn->prepare($sql);

    // Check if the SQL statement is prepared correctly
    if ($stmt === false) {
        echo json_encode([
            'status' => false,
            'message' => 'Failed to prepare SQL statement.'
        ], JSON_PRETTY_PRINT);
        exit;
    }

    // Bind the doctor_id parameter to the query
    $stmt->bind_param("s", $doctor_id);

    // Execute the statement
    $stmt->execute();

    // Fetch the result
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        // Fetch the data as an associative array
        $data = $result->fetch_assoc();

        // Return the data in JSON format with status true
        echo json_encode([
            'status' => true,
            'message' => 'Data fetched successfully.',
            'data' => $data
        ], JSON_PRETTY_PRINT);
    } else {
        // No doctor found with the given ID
        echo json_encode([
            'status' => false,
            'message' => 'No doctor found with the provided ID.'
        ], JSON_PRETTY_PRINT);
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();

} else {
    // Invalid request method
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.'
    ], JSON_PRETTY_PRINT);
}
