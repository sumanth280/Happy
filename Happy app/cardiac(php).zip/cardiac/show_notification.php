<?php
include 'con.php'; // Include your database connection file

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect the data from the POST request
    $patient_id = $_POST['patient_id'] ?? null;

    // Validate that patient_id is provided
    if ($patient_id) {
        // Prepare the SQL statement to select notifications for the patient
        $sql = "SELECT * FROM notification WHERE patient_id = ?";
        $stmt = $conn->prepare($sql);
        
        if ($stmt === false) {
            echo json_encode([
                'status' => false,
                'message' => 'Error in SQL preparation: ' . $conn->error
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Bind the patient_id parameter and execute the statement
        $stmt->bind_param("s", $patient_id);
        $stmt->execute();
        
        // Get the result
        $result = $stmt->get_result();
        $notifications = $result->fetch_all(MYSQLI_ASSOC); // Fetch all notifications as an associative array
        
        // Check if any notifications were found
        if (count($notifications) > 0) {
            echo json_encode([
                'status' => true,
                'notifications' => $notifications,
            ], JSON_PRETTY_PRINT);
        } else {
            echo json_encode([
                'status' => false,
                'message' => 'No notifications found for this patient_id.',
            ], JSON_PRETTY_PRINT);
        }

        // Close the statement and connection
        $stmt->close();
        $conn->close();
    } else {
        echo json_encode([
            'status' => false,
            'message' => 'Missing required field: patient_id.',
        ], JSON_PRETTY_PRINT);
    }
} else {
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method. Use POST.',
    ], JSON_PRETTY_PRINT);
}
?>
