<?php
// Include database connection
include 'con.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve patient_id from the POST request
    $patient_id = isset($_POST['patient_id']) ? $_POST['patient_id'] : '';

    if (empty($patient_id)) {
        echo json_encode(['status' => false, 'message' => 'Patient ID is required']);
        exit;
    }

    try {
        // Get the current day
        $currentDay = strtolower(date('l')); // e.g., 'monday', 'tuesday', etc.

        // Query to fetch alerts for the given patient_id for the current day where status = 0
        $query = "SELECT patient_id, notification_id, medicine_name,time_med, time_stamp 
                  FROM alerts 
                  WHERE patient_id = ? 
                  AND status = 0 
                  AND DATE(time_stamp) = CURDATE()";

        $stmt = $conn->prepare($query);
        $stmt->bind_param('s', $patient_id);
        $stmt->execute();
        $result = $stmt->get_result();

        // Check if alerts exist
        if ($result->num_rows > 0) {
            $alerts = [];
            while ($row = $result->fetch_assoc()) {
                $alerts[] = $row;
            }

            echo json_encode(['status' => true, 'data' => $alerts]);
        } else {
            echo json_encode(['status' => false, 'message' => 'No alerts found for the current day with status 0']);
        }
    } catch (Exception $e) {
        echo json_encode(['status' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['status' => false, 'message' => 'Invalid request method']);
}
?>
