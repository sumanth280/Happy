<?php
include 'con.php'; // Include your database connection file

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect the patient_id from the POST request
    $patient_id = $_POST['patient_id'] ?? null;

    // Check if patient_id is provided
    if (!$patient_id) {
        echo json_encode([
            'status' => false,
            'message' => 'Patient ID is required.'
        ], JSON_PRETTY_PRINT);
        exit;
    }

    // Prepare SQL statement to fetch data
    $sql = "SELECT * FROM risk_major WHERE patient_id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        echo json_encode([
            'status' => false,
            'message' => 'Failed to prepare SQL statement.'
        ], JSON_PRETTY_PRINT);
        exit;
    }
    
    // Bind the patient_id parameter
    $stmt->bind_param("s", $patient_id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if the record exists
    if ($result->num_rows > 0) {
        $data = $result->fetch_assoc();
        echo json_encode([
            'status' => true,
            'message' => 'Data fetched successfully.', // Added message for successful fetch
            'data' => $data
        ], JSON_PRETTY_PRINT);
    } else {
        echo json_encode([
            'status' => false,
            'message' => 'No data found for the provided Patient ID.'
        ], JSON_PRETTY_PRINT);
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.'
    ], JSON_PRETTY_PRINT);
}
?>
