<?php
include 'con.php'; // Include your database connection file

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect the data from the POST request
    $patient_id = $_POST['patient_id'] ?? null;
    $acute_pulmonary_edema = $_POST['acute_pulmonary_edema'] ?? null;
    $cardiomegaly = $_POST['cardiomegaly'] ?? null;
    $hepatojugular_reflex = $_POST['hepatojugular_reflex'] ?? null;
    $neck_vein_distension = $_POST['neck_vein_distension'] ?? null;
    $pnd_orthopnea = $_POST['pnd_orthopnea'] ?? null;
    $pulmonary_rales = $_POST['pulmonary_rales'] ?? null;
    $third_heartsound_s3 = $_POST['third_heartsound_s3'] ?? null;
    $response_to_treatment = $_POST['response_to_treatment'] ?? null;

    // Check if patient_id is provided
    if (!$patient_id) {
        echo json_encode([
            'status' => false,
            'message' => 'Patient ID is required.',
        ], JSON_PRETTY_PRINT);
        exit;
    }

    // Check if patient_id exists in the risk_major table
    $check_sql = "SELECT patient_id FROM risk_major WHERE patient_id=?";
    $check_stmt = $conn->prepare($check_sql);
    if ($check_stmt === false) {
        echo json_encode([
            'status' => false,
            'message' => 'Failed to prepare SQL statement for checking patient ID: ' . $conn->error,
        ], JSON_PRETTY_PRINT);
        exit;
    }
    $check_stmt->bind_param("s", $patient_id);
    $check_stmt->execute();
    $check_stmt->store_result();

    if ($check_stmt->num_rows > 0) {
        // If patient_id exists, update the record
        $sql = "UPDATE risk_major SET 
                    `acute_pulmonary_edema`=?, 
                    `cardiomegaly`=?, 
                    `hepatojugular_reflex`=?, 
                    `neck_vein_distension`=?, 
                    `pnd_orthopnea`=?, 
                    `pulmonary_rales`=?, 
                    `third_heartsound_s3`=?, 
                    `response_to_treatment`=?
                WHERE patient_id=?";
        $stmt = $conn->prepare($sql);
        if ($stmt === false) {
            echo json_encode([
                'status' => false,
                'message' => 'Failed to prepare SQL statement for update: ' . $conn->error,
            ], JSON_PRETTY_PRINT);
            exit;
        }
        $stmt->bind_param("sssssssss", $acute_pulmonary_edema, $cardiomegaly, $hepatojugular_reflex, $neck_vein_distension, $pnd_orthopnea, $pulmonary_rales, $third_heartsound_s3, $response_to_treatment, $patient_id);
    } else {
        // If patient_id doesn't exist, insert a new record
        $sql = "INSERT INTO risk_major (
                    patient_id, 
                    `acute_pulmonary_edema`, 
                    `cardiomegaly`, 
                    `hepatojugular_reflex`, 
                    `neck_vein_distension`, 
                    `pnd_orthopnea`, 
                    `pulmonary_rales`, 
                    `third_heartsound_s3`, 
                    `response_to_treatment`
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        if ($stmt === false) {
            echo json_encode([
                'status' => false,
                'message' => 'Failed to prepare SQL statement for insert: ' . $conn->error,
            ], JSON_PRETTY_PRINT);
            exit;
        }
        $stmt->bind_param("sssssssss", $patient_id, $acute_pulmonary_edema, $cardiomegaly, $hepatojugular_reflex, $neck_vein_distension, $pnd_orthopnea, $pulmonary_rales, $third_heartsound_s3, $response_to_treatment);
    }

    // Execute the statement
    if ($stmt->execute()) {
        echo json_encode([
            'status' => true,
            'message' => $check_stmt->num_rows > 0 ? 'Data updated successfully.' : 'Data inserted successfully.',
        ], JSON_PRETTY_PRINT);
    } else {
        echo json_encode([
            'status' => false,
            'message' => 'Failed to execute query: ' . $stmt->error,
        ], JSON_PRETTY_PRINT);
    }

    // Close the statements and connection
    $stmt->close();
    $check_stmt->close();
    $conn->close();
} else {
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.',
    ], JSON_PRETTY_PRINT);
}
?>
