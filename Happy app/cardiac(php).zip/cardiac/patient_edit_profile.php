<?php
include 'con.php'; // Include your database connection file

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect the data from the POST request
    $patient_id = $_POST['patient_id'] ?? null;
    $name = $_POST['name'] ?? null;
    $age = $_POST['age'] ?? null;
    $gender = $_POST['gender'] ?? null;
    $phone_number_1 = $_POST['phone_number_1'] ?? null;
    $profession = $_POST['profession'] ?? null;
    $weight = $_POST['weight'] ?? null;
    $height = $_POST['height'] ?? null;
    $bmi = $_POST['bmi'] ?? null;
    $phone_number_2 = $_POST['phone_number_2'] ?? null;
    $address = $_POST['address'] ?? null;
    // Check if patient_id is provided
    if (!$patient_id) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Patient ID is required.',
        ], JSON_PRETTY_PRINT);
        exit;
    }

    // Prepare the SQL statement to update all fields except patient_id
    $sql = "UPDATE addpatient SET
            name = ?,
            age = ?,
            gender = ?,
            phone_number_1 = ?,
            profession = ?,
            weight = ?,
            height = ?,
            bmi = ?,
            phone_number_2 = ?,
            address = ?
            WHERE patient_id = ?";

    // The type definition string should be 'sssssssssss' for the 11 string parameters
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssssssss", $name, $age, $gender, $phone_number_1, $profession, $weight, $height, $bmi, $phone_number_2, $address, $patient_id);

    // Execute the statement
    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            echo json_encode([
                'status' => 'success',
                'message' => 'Data updated successfully.',
            ], JSON_PRETTY_PRINT);
        } else {
            echo json_encode([
                'status' => 'info',
                'message' => 'No changes were made.',
            ], JSON_PRETTY_PRINT);
        }
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'Failed to execute query.',
        ], JSON_PRETTY_PRINT);
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid request method.',
    ], JSON_PRETTY_PRINT);
}
?>
