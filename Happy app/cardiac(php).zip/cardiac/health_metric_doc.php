<?php
include 'con.php'; // Include your database connection file

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect the data from the POST request
    $patient_id = $_POST['patient_id'] ?? null;

    if ($patient_id) {
        // Prepare the SQL statement to fetch data for the current date
        $sql = "SELECT * FROM health_metrics 
                WHERE patient_id = ? 
                AND DATE(time_stamp) = CURDATE()";

        $stmt = $conn->prepare($sql);
        if ($stmt === false) {
            // Log error details
            error_log("Prepare Error: " . $conn->error);
            echo json_encode([
                'status' => false,  // Set status to false for SQL preparation error
                'message' => 'Failed to prepare SQL statement.',
                'error' => $conn->error, // Optional: include the error message
            ], JSON_PRETTY_PRINT);
            exit;
        }

        $stmt->bind_param("s", $patient_id);

        // Execute the statement
        if ($stmt->execute()) {
            $result = $stmt->get_result();
            $data = []; // Initialize data array
            if ($result->num_rows > 0) {
                $data = $result->fetch_all(MYSQLI_ASSOC);
            } // No need for an else block since $data will be empty if no rows are found

            echo json_encode([
                'status' => true,  // Always set to true if the query was executed
                'message' => $result->num_rows > 0 ? 'Data retrieved successfully.' : 'No data found for the given patient ID on the current date.',
                'data' => $data, // Return data, which will be empty if no data is found
            ], JSON_PRETTY_PRINT);
        } else {
            // Log error details
            error_log("Execute Error: " . $stmt->error);
            echo json_encode([
                'status' => false,  // Set status to false if query execution fails
                'message' => 'Failed to execute query.',
                'error' => $stmt->error, // Optional: include the error message
            ], JSON_PRETTY_PRINT);
        }

        // Close the statement and connection
        $stmt->close();
        $conn->close();
    } else {
        echo json_encode([
            'status' => false,  // Set status to false if patient ID is not provided
            'message' => 'Patient ID is required.',
        ], JSON_PRETTY_PRINT);
    }
} else {
    echo json_encode([
        'status' => false,  // Set status to false for invalid request method
        'message' => 'Invalid request method.',
    ], JSON_PRETTY_PRINT);
}
?>
