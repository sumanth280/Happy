<?php
include 'con.php';

header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];

switch($method) {
    case 'POST':
        // Check if form data is sent using POST method
        if (isset($_POST['phone_number_1']) && isset($_POST['password'])) {
    $phone_number_1 = $_POST['phone_number_1'];
    $password = $_POST['password'];

    // Prepare and bind the SQL statement to check phone_number_1 and password in the addpatient table
    $stmt = $conn->prepare("SELECT * FROM addpatient WHERE phone_number_1 = ? AND password = ?");
    $stmt->bind_param("ss", $phone_number_1, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Fetch the data as an associative array
        $row = mysqli_fetch_assoc($result);
        
        // Return the data in JSON format with the 'data' field holding the database result
        echo json_encode([
            "status" => true,
            "message" => "Login successful",
            "data" => $row
        ]);
    } else {
        echo json_encode([
            "status" => false,
            "message" => "Invalid username or password"
        ]);
    }

    // Close the statement
    $stmt->close();
          }}  
// Close the connection
$conn->close();
?>
