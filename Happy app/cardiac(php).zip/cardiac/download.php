<?php
include 'con.php'; // Include your database connection file

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $patient_id = $_POST['patient_id'] ?? null; // Get patient_id from POST request

    if (!$patient_id) {
        echo json_encode([
            'status' => false,
            'message' => 'Patient ID is required.',
        ], JSON_PRETTY_PRINT);
        exit;
    }

    // Fetch data from the `addpatient` table for the given patient_id
    $query = "SELECT * FROM addpatient WHERE patient_id = ?";
    $stmt = $conn->prepare($query);

    if (!$stmt) {
        echo json_encode([
            'status' => false,
            'message' => 'Failed to prepare query.',
        ], JSON_PRETTY_PRINT);
        exit;
    }

    $stmt->bind_param("s", $patient_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        echo json_encode([
            'status' => false,
            'message' => 'No records found for the given Patient ID.',
        ], JSON_PRETTY_PRINT);
        exit;
    }

    // Prepare CSV headers
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="patient_data_' . $patient_id . '.csv"');

    // Open output stream
    $output = fopen('php://output', 'w');

    // Add CSV column headers
    $headers = [
        'S No', 'Patient ID', 'Name', 'Age', 'Gender', 'Phone Number 1', 
        'Profession', 'Weight', 'Height', 'BMI', 'Phone Number 2', 'Address'
    ];
    fputcsv($output, $headers);

    // Add table rows
    while ($row = $result->fetch_assoc()) {
        fputcsv($output, [
            $row['s_no'],
            $row['patient_id'],
            $row['name'],
            $row['age'],
            $row['gender'],
            $row['phone_number_1'],
            $row['profession'],
            $row['weight'],
            $row['height'],
            $row['bmi'],
            $row['phone_number_2'],
            $row['address'],
        ]);
    }

    // Close output stream and database connection
    fclose($output);
    $stmt->close();
    $conn->close();
    exit;
} else {
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.',
    ], JSON_PRETTY_PRINT);
    exit;
}
?>
