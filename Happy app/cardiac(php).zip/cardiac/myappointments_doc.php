<?php
include 'con.php'; // Include your database connection file

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the current date
    $current_date = date('Y-m-d');

    // Prepare the SQL statement to fetch appointments for the current day
    $sql = "
        SELECT a.patient_id, ap.name, ap.phone_number_1, a.time, a.date, ap.profile_pic
        FROM appointments a
        JOIN addpatient ap ON a.patient_id = ap.patient_id
        WHERE a.date = ?
    ";

    $stmt = $conn->prepare($sql);
    
    // Check if the SQL was prepared correctly
    if ($stmt === false) {
        echo json_encode([
            'status' => false,
            'message' => 'Error in SQL preparation: ' . $conn->error
        ], JSON_PRETTY_PRINT);
        exit;
    }

    $stmt->bind_param("s", $current_date);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if any appointments were found
    if ($result->num_rows > 0) {
        $response = [];
        $s_no = 1;

        // Loop through each appointment
        while ($row = $result->fetch_assoc()) {
            $response[] = [
                's.no' => $s_no++,
                'patient_id' => $row['patient_id'] ?? '',
                'name' => $row['name'] ?? '',
                'phone_number' => $row['phone_number_1'] ?? '',
                'time' => $row['time'] ?? '',
                'date' => $row['date'] ?? '',
                'profile_pic' => $row['profile_pic'] ?? 'No Profile Pic' // Include profile_pic
            ];
        }

        // Output the data
        echo json_encode([
            'status' => true,
            'message' => 'Appointments fetched successfully.',
            'data' => $response
        ], JSON_PRETTY_PRINT);
    } else {
        // If no appointments are found, status is still true
        echo json_encode([
            'status' => true,
            'message' => 'No appointments found for today.',
            'data' => []
        ], JSON_PRETTY_PRINT);
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.',
    ], JSON_PRETTY_PRINT);
}
?>
