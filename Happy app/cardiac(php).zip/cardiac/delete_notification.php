<?php
include 'con.php'; // Include your database connection file

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect the data from the POST request
    $patient_id = $_POST['patient_id'] ?? null;
    $notification_id = $_POST['notification_id'] ?? null;

    // Validate that both patient_id and notification_id are provided
    if ($patient_id && $notification_id) {
        // Prepare the SQL statement to delete the notification
        $sql = "DELETE FROM notification WHERE patient_id = ? AND notification_id = ?";
        $stmt = $conn->prepare($sql);

        if ($stmt === false) {
            echo json_encode([
                'status' => false,
                'message' => 'Error in SQL preparation: ' . $conn->error
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Bind the parameters and execute the statement
        $stmt->bind_param("ss", $patient_id, $notification_id);
        $stmt->execute();
        
        // Check how many rows were affected
        if ($stmt->affected_rows > 0) {
            echo json_encode([
                'status' => true,
                'message' => 'Notification deleted successfully.',
            ], JSON_PRETTY_PRINT);
        } else {
            echo json_encode([
                'status' => false,
                'message' => 'No notification found with the given patient_id and notification_id.',
            ], JSON_PRETTY_PRINT);
        }

        // Close the statement and connection
        $stmt->close();
        $conn->close();
    } else {
        echo json_encode([
            'status' => false,
            'message' => 'Missing required fields: patient_id or notification_id.',
        ], JSON_PRETTY_PRINT);
    }
} else {
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method. Use POST.',
    ], JSON_PRETTY_PRINT);
}
?>
