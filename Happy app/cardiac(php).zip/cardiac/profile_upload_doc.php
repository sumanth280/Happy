<?php
include 'con.php'; // Include your database connection file

header('Content-Type: application/json');

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check for database connection
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect the doctor_id from the POST request
    $doctor_id = $_POST['doctor_id'] ?? null;

    // Check if doctor_id is provided
    if (!$doctor_id) {
        echo json_encode([
            'status' => false,
            'message' => 'Doctor ID is required.',
        ], JSON_PRETTY_PRINT);
        exit;
    }

    // Check if a file was uploaded
    if (isset($_FILES['profile_doc']) && $_FILES['profile_doc']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['profile_doc']['tmp_name'];
        $fileName = $_FILES['profile_doc']['name'];
        $fileSize = $_FILES['profile_doc']['size'];
        $fileNameCmps = explode(".", $fileName);
        $fileExtension = strtolower(end($fileNameCmps));

        // Specify the directory to save the uploaded file
        $uploadFileDir = './uploads/';

        // Create the directory if it doesn't exist
        if (!is_dir($uploadFileDir)) {
            mkdir($uploadFileDir, 0755, true); // Creates the directory with permissions
        }

        $newFileName = $doctor_id . '.' . $fileExtension; // Name the file with doctor_id
        $dest_path = $uploadFileDir . $newFileName;

        // Check file type and size
        $allowedfileExtensions = ['jpg', 'gif', 'png', 'jpeg'];
        if (in_array($fileExtension, $allowedfileExtensions) && $fileSize < 5000000) { // 5MB limit
            
            // Check if there is an existing profile document for the doctor
            $sql = "SELECT profile_doc FROM doctor_profile WHERE doctor_id = ?";
            $stmt = $conn->prepare($sql);
            
            if ($stmt === false) {
                die("Failed to prepare SQL statement: " . $conn->error);
            }

            $stmt->bind_param("s", $doctor_id);
            $stmt->execute();
            $stmt->bind_result($current_doc);
            $stmt->fetch();
            $stmt->close();

            // Delete the old profile document if it exists
            if ($current_doc && file_exists($current_doc)) {
                unlink($current_doc); // Delete the old document from the server
            }

            // Move the new uploaded file to the destination
            if (move_uploaded_file($fileTmpPath, $dest_path)) {
                // Prepare the SQL statement to update the profile_doc column
                $sql = "UPDATE doctor_profile SET profile_doc = ? WHERE doctor_id = ?";
                $stmt = $conn->prepare($sql);
                
                if ($stmt === false) {
                    die("Failed to prepare SQL statement: " . $conn->error);
                }

                // Bind parameters to the SQL query
                $stmt->bind_param("ss", $dest_path, $doctor_id);

                // Execute the statement
                if ($stmt->execute()) {
                    // Check if an existing document was replaced or if this is a new upload
                    if ($current_doc) {
                        $message = 'Profile document updated successfully.';
                    } else {
                        $message = 'Profile document uploaded successfully.';
                    }

                    echo json_encode([
                        'status' => true,
                        'message' => $message,
                        'profile_path' => $dest_path, // Return the file path
                    ], JSON_PRETTY_PRINT);
                } else {
                    echo json_encode([
                        'status' => false,
                        'message' => 'Failed to update profile document in the database: ' . $stmt->error,
                    ], JSON_PRETTY_PRINT);
                }

                // Close the statement
                $stmt->close();
            } else {
                echo json_encode([
                    'status' => false,
                    'message' => 'There was an error moving the uploaded file.',
                ], JSON_PRETTY_PRINT);
            }
        } else {
            echo json_encode([
                'status' => false,
                'message' => 'Invalid file type or file size exceeds limit.',
            ], JSON_PRETTY_PRINT);
        }
    } else {
        echo json_encode([
            'status' => false,
            'message' => 'No file uploaded or there was an upload error.',
        ], JSON_PRETTY_PRINT);
    }

    // Close the connection
    $conn->close();
} else {
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.',
    ], JSON_PRETTY_PRINT);
}
?>
