<?php
include 'con.php'; // Include your database connection file

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect the patient_id from the POST request
    $patient_id = $_POST['patient_id'] ?? null;

    if ($patient_id !== null) {
        // Prepare the SQL query to fetch pending appointments with date >= current date, and also fetch patient name
        $sql = "
            SELECT a.*, ap.profile_pic, ap.name 
            FROM appointments a
            JOIN addpatient ap ON a.patient_id = ap.patient_id
            WHERE a.patient_id = ? AND a.`date` >= CURDATE()
        ";
        
        $stmt = $conn->prepare($sql);
        if ($stmt === false) {
            echo json_encode([
                'status' => false,  // Set status to false for SQL preparation error
                'message' => 'Failed to prepare SQL statement.'
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Bind the patient_id parameter
        $stmt->bind_param("i", $patient_id);

        // Execute the query
        if ($stmt->execute()) {
            $result = $stmt->get_result();
            $appointments = $result->fetch_all(MYSQLI_ASSOC);

            // Return the appointments along with the patient's name and profile picture in JSON format
            echo json_encode([
                'status' => true,  // Set status to true if appointments are fetched successfully
                'message' => 'Pending appointments fetched successfully.',
                'data' => $appointments
            ], JSON_PRETTY_PRINT);
        } else {
            echo json_encode([
                'status' => false,  // Set status to false if query execution fails
                'message' => 'Failed to execute query.'
            ], JSON_PRETTY_PRINT);
        }

        // Close the statement and connection
        $stmt->close();
        $conn->close();
    } else {
        echo json_encode([
            'status' => false,  // Set status to false if patient_id is not provided
            'message' => 'patient_id is required.'
        ], JSON_PRETTY_PRINT);
    }
} else {
    echo json_encode([
        'status' => false,  // Set status to false for invalid request method
        'message' => 'Invalid request method.'
    ], JSON_PRETTY_PRINT);
}
?>
