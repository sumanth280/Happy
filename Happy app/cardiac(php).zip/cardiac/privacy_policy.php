<?php
// Include the connection file
if (file_exists('con.php')) {
    include 'con.php';
} else {
    die('Error: Connection file not found.');
}

// Function to display the privacy policy content
function display_privacy_policy() {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Privacy Policy - Happy App</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background: #fff;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1, h2, h3, h4 {
            color: #333;
        }
        p {
            color: #555;
        }
        ul {
            padding-left: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Privacy Policy</h1>
        <p>Welcome to Happy, an application designed to assist users in monitoring heart health through features like symptom tracking, condition analysis, appointment booking, medicine reminders, and health metric management.</p>
        
        <h2>Interpretation and Definitions</h2>
        <h3>Interpretation</h3>
        <p>Words with initial letters capitalized have meanings defined below. These definitions will have the same meaning regardless of whether they appear in singular or plural form.</p>
        
        <h3>Definitions</h3>
        <ul>
            <li><strong>Account:</strong> A unique account created for You to access our Service or parts of it.</li>
            <li><strong>Application:</strong> Refers to Happy, the software provided by the Company.</li>
            <li><strong>Company:</strong> Refers to the creators of Happy.</li>
            <li><strong>Device:</strong> Any device capable of accessing the Service, such as a computer, cellphone, or tablet.</li>
            <li><strong>Personal Data:</strong> Any information relating to an identified or identifiable individual.</li>
            <li><strong>Health Metrics:</strong> Specific health data such as blood pressure (BP), heart rate, pulse rate, and other related metrics.</li>
            <li><strong>Service:</strong> The Application.</li>
            <li><strong>You:</strong> The individual accessing or using the Service.</li>
        </ul>
        
        <h2>Collecting and Using Your Personal Data</h2>
        <h3>Types of Data Collected</h3>
        
        <h4>Normal Data</h4>
        <p>While using Our Service, We may ask You to provide identifiable information for better personalization. This data may include:</p>
        <ul>
            <li>Name</li>
            <li>Address</li>
            <li>Phone Number</li>
            <li>Height</li>
            <li>Weight</li>
        </ul>
        
        <h4>Health Metrics</h4>
        <p>For effective monitoring and analysis, we may collect and store health-related data, including but not limited to:</p>
        <ul>
            <li>Blood Pressure (BP)</li>
            <li>Heart Rate</li>
            <li>Pulse Rate</li>
            <li>Other relevant health data</li>
        </ul>
        
        <h4>Usage Data</h4>
        <p>Usage Data is collected automatically when using the Service. It may include information such as Your Device\'s IP address, browser type, browser version, the pages of our Service that You visit, the time and date of Your visit, time spent on those pages, unique device identifiers, and other diagnostic data.</p>
        
        <h4>Symptom Data</h4>
        <p>The app collects symptom information entered by the user. Based on selected symptoms and checkboxes, the app evaluates and displays possible health conditions to assist in understanding your heart health.</p>
        
        <h2>Features and Their Data Use</h2>
        <ul>
            <li><strong>Symptom Monitoring:</strong> Enables users to enter symptoms and provides condition insights based on checkbox options.</li>
            <li><strong>Appointment Booking:</strong> Collects details to help schedule and manage appointments with healthcare providers.</li>
            <li><strong>Medicine Reminders:</strong> Stores medication schedules to provide timely reminders.</li>
            <li><strong>Health Metrics:</strong> Tracks and analyzes metrics like blood pressure, heart rate, and pulse rate for personalized health insights.</li>
        </ul>
        
        <h2>Sharing Your Personal Data</h2>
        <ul>
            <li><strong>With Service Providers:</strong> To manage health data and provide functionality like reminders and reports.</li>
            <li><strong>For Business Transfers:</strong> During mergers, sales, or acquisitions.</li>
            <li><strong>With Your Consent:</strong> For any other purpose with your explicit consent.</li>
        </ul>
        
        <h2>Retention of Your Personal Data</h2>
        <p>Your data will be retained as necessary for the operation of features like condition monitoring, appointment scheduling, and health metric analysis. We ensure compliance with legal obligations and prioritize privacy and security.</p>
        
        <h2>Security of Your Personal Data</h2>
        <p>We implement commercially reasonable methods to secure your data but cannot guarantee absolute security.</p>
        
        <h2>Children\'s Privacy</h2>
        <p>The Service is not intended for individuals under the age of 15. If you are a parent or guardian aware of such data collection, please contact us.</p>
        
        <h2>Changes to this Privacy Policy</h2>
        <p>We may update this Privacy Policy and will notify you of any changes by posting the new policy on this page. Please review the policy periodically for updates.</p>
        
        <h2>Contact Us</h2>
        <p>If you have any questions about this Privacy Policy, contact us at <a href="mailto:nvmsumanth@gmail.com">nvmsumanth@gmail.com</a>.</p>
        
        <p>© 2024 Happy. All rights reserved.</p>
    </div>
</body>
</html>
<?php
}

// Call the function to display the privacy policy
display_privacy_policy();
?>
