<?php
include 'con.php'; // Include your database connection file

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect the data from the POST request
    $patient_id = $_POST['patient_id'] ?? null;
    $cbc_hb = $_POST['cbc_hb'] ?? null;
    $cbc_tlc = $_POST['cbc_tlc'] ?? null;
    $rft_creatinine = $_POST['rft_creatinine'] ?? null;
    $sgot = $_POST['sgot'] ?? null;
    $sgpt = $_POST['sgpt'] ?? null;
    $total_bilibubin = $_POST['total_bilibubin'] ?? null;
    $sodium = $_POST['sodium'] ?? null;
    $pottasium = $_POST['pottasium'] ?? null;
    $chloride = $_POST['chloride'] ?? null;
    $sodium_bicarbonate = $_POST['sodium_bicarbonate'] ?? null;

    // Check if required fields are provided
    if (!$patient_id || !$sodium_bicarbonate) {
        echo json_encode([
            'status' => false, // Status set to false
            'message' => 'Patient ID and Sodium Bicarbonate are required.',
        ], JSON_PRETTY_PRINT);
        exit;
    }

    // Function to generate a unique casesheet_id
    function generateUniqueCasesheetId($conn) {
        $is_unique = false;
        $casesheet_id = '';

        while (!$is_unique) {
            // Generate the casesheet_id (starts with 'C' followed by a 6-digit number)
            $casesheet_id = 'C' . str_pad(rand(1, 999999), 6, '0', STR_PAD_LEFT);

            // Check if the generated casesheet_id already exists in the table
            $check_sql = "SELECT COUNT(*) as count FROM investigation_routines WHERE casesheet_id = ?";
            $stmt = $conn->prepare($check_sql);
            $stmt->bind_param("s", $casesheet_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $row = $result->fetch_assoc();
            
            if ($row['count'] == 0) {
                $is_unique = true;  // No duplicate found, casesheet_id is unique
            }
        }

        return $casesheet_id;
    }

    // Generate a unique casesheet_id
    $casesheet_id = generateUniqueCasesheetId($conn);

    // Prepare the SQL statement to insert data into the investigation_routines table
    $sql = "INSERT INTO investigation_routines (
                patient_id,
                casesheet_id, 
                cbc_hb, 
                cbc_tlc, 
                rft_creatinine, 
                sgot, 
                sgpt, 
                total_bilibubin, 
                sodium, 
                pottasium, 
                chloride, 
                sodium_bicarbonate
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        echo json_encode([
            'status' => false, // Status set to false
            'message' => 'Failed to prepare SQL statement.',
        ], JSON_PRETTY_PRINT);
        exit;
    }

    // Bind parameters to the SQL query
    $stmt->bind_param("ssssssssssss", 
        $patient_id,
        $casesheet_id,  // Bind the generated casesheet_id
        $cbc_hb, 
        $cbc_tlc, 
        $rft_creatinine, 
        $sgot, 
        $sgpt, 
        $total_bilibubin, 
        $sodium, 
        $pottasium, 
        $chloride, 
        $sodium_bicarbonate
    );

    // Execute the statement
    if ($stmt->execute()) {
        echo json_encode([
            'status' => true, // Status set to true
            'message' => 'Data inserted successfully.',
            'casesheet_id' => $casesheet_id  // Return the generated casesheet_id
        ], JSON_PRETTY_PRINT);
    } else {
        echo json_encode([
            'status' => false, // Status set to false
            'message' => 'Failed to insert data.',
        ], JSON_PRETTY_PRINT);
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo json_encode([
        'status' => false, // Status set to false for invalid request method
        'message' => 'Invalid request method.',
    ], JSON_PRETTY_PRINT);
}
?>
