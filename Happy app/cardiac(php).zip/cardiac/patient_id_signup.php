<?php
include 'con.php'; // Include your database connection file

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Fetch patient_id from POST request
    $patient_id = $_POST['patient_id'];

    // Prepare the SQL statement to select only the desired columns,
    // and check that profile_set is 'no'
    $sql = "SELECT patient_id, name, age, gender, phone_number_1, profession, weight, height, bmi, phone_number_2, address 
            FROM addpatient WHERE patient_id = ? AND profile_set = 'no'";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $patient_id);

    // Execute the statement
    if ($stmt->execute()) {
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            // Fetch data as associative array
            $data = $result->fetch_assoc();
            echo json_encode([
                'status' => true,  // Change to boolean true
                'message' => 'Data fetched successfully.',
                'data' => $data,
            ], JSON_PRETTY_PRINT);
        } else {
            // Account already created or invalid patient ID
            echo json_encode([
                'status' => true,  // Still return true but with a different message
                'message' => 'Account already created or invalid patient ID.',
            ], JSON_PRETTY_PRINT);
        }
    } else {
        echo json_encode([
            'status' => false,  // Change to boolean false in case of failure
            'message' => 'Failed to execute query.',
        ], JSON_PRETTY_PRINT);
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo json_encode([
        'status' => false,  // Change to boolean false for invalid request method
        'message' => 'Invalid request method.',
    ], JSON_PRETTY_PRINT);
}
?>
