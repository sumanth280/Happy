<?php
include 'con.php'; // Include your database connection file

header('Content-Type: application/json');

// Function to generate unique special_casesheet_id
function generateSpecialCasesheetId($conn) {
    $prefix = chr(rand(65, 90)); // Generate a random uppercase letter (A-Z)
    $unique_id = $prefix . str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT); // Append 6-digit random number

    // Check if the generated ID already exists in the table
    $check_sql = "SELECT special_casesheet_id FROM investigation_special WHERE special_casesheet_id = ?";
    $stmt = $conn->prepare($check_sql);
    $stmt->bind_param("s", $unique_id);
    $stmt->execute();
    $result = $stmt->get_result();

    // If it exists, generate a new one
    if ($result->num_rows > 0) {
        return generateSpecialCasesheetId($conn); // Recursively generate a new ID
    } else {
        return $unique_id;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect the data from the POST request
    $patient_id = $_POST['patient_id'] ?? null;
    $h1ba1c = $_POST['h1ba1c'] ?? null;
    $triglycerides = $_POST['triglycerides'] ?? null;
    $ldl = $_POST['ldl'] ?? null;
    $hdl = $_POST['hdl'] ?? null;
    $bnp = $_POST['bnp'] ?? null;
    $tsh = $_POST['tsh'] ?? null;
    $ft3 = $_POST['ft3'] ?? null;
    $ft4 = $_POST['ft4'] ?? null;
    $ecg_findings = $_POST['ecg_findings'] ?? null;
    $echo_findings = $_POST['echo_findings'] ?? null;
    $usg_abdomen_findings = $_POST['usg_abdomen_findings'] ?? null;
    $stage = $_POST['stage'] ?? null;

    // Validate required fields
    if ($patient_id) {
        // Generate unique special_casesheet_id
        $special_casesheet_id = generateSpecialCasesheetId($conn);

        // Prepare the SQL statement to insert the data
        $sql = "INSERT INTO investigation_special (
                    special_casesheet_id, patient_id, h1ba1c, triglycerides, ldl, hdl, 
                    bnp, tsh, ft3, ft4, ecg_findings, echo_findings, 
                    usg_abdomen_findings, stage
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $stmt = $conn->prepare($sql);
        if ($stmt === false) {
            echo json_encode([
                'success' => false,
                'message' => 'Failed to prepare SQL statement.',
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Bind parameters to the SQL query
        $stmt->bind_param(
            "ssssssssssssss",
            $special_casesheet_id, $patient_id, $h1ba1c, $triglycerides, $ldl, $hdl,
            $bnp, $tsh, $ft3, $ft4, $ecg_findings, $echo_findings,
            $usg_abdomen_findings, $stage
        );

        // Execute the statement
        if ($stmt->execute()) {
            echo json_encode([
                'success' => true,
                'message' => 'Data inserted successfully.',
                'special_casesheet_id' => $special_casesheet_id // Return the generated ID in the response
            ], JSON_PRETTY_PRINT);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Failed to execute query.',
            ], JSON_PRETTY_PRINT);
        }

        // Close the statement and connection
        $stmt->close();
        $conn->close();
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Patient ID is required.',
        ], JSON_PRETTY_PRINT);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method.',
    ], JSON_PRETTY_PRINT);
}
?>
