<?php
include 'con.php'; // Include your database connection file

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect the input data
    $patient_id = $_POST['patient_id'];

    // Prepare the SQL statement to fetch data based on patient_id
    $sql = "SELECT s_no, patient_id, name, age, gender, phone_number_1, profession, weight, height, bmi, phone_number_2, address FROM addpatient WHERE patient_id = ?";
    $stmt = $conn->prepare($sql);

    // Check if the SQL was prepared correctly
    if ($stmt === false) {
        echo json_encode([
            'status' => false,  // Set status to false for SQL preparation error
            'message' => 'Error in SQL preparation: ' . $conn->error
        ], JSON_PRETTY_PRINT);
        exit;
    }

    // Bind parameters
    $stmt->bind_param("s", $patient_id);

    // Execute the statement
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if any records were found
    if ($result->num_rows > 0) {
        $data = $result->fetch_assoc();
        echo json_encode([
            'status' => true,  // Set status to true if data is found
            'message' => 'Patient data retrieved successfully.', // Success message
            'data' => $data
        ], JSON_PRETTY_PRINT);
    } else {
        echo json_encode([
            'status' => false,  // Set status to false if no patient is found
            'message' => 'No patient found with the given ID.' // No patient message
        ], JSON_PRETTY_PRINT);
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo json_encode([
        'status' => false,  // Set status to false for invalid request method
        'message' => 'Invalid request method.' // Invalid method message
    ], JSON_PRETTY_PRINT);
}
?>
