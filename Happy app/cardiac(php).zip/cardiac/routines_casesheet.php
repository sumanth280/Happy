<?php
include 'con.php'; // Include your database connection file

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect the patient_id from the POST request
    $patient_id = $_POST['patient_id'] ?? null;

    // Check if patient_id is provided
    if (!$patient_id) {
        echo json_encode([
            'status' => false, // Change to boolean
            'message' => 'Patient ID is required.',
        ], JSON_PRETTY_PRINT);
        exit;
    }

    // Prepare SQL query to fetch casesheet_id, name (from addpatient), and date (from investigation_routines)
    $sql = "SELECT 
                inv.casesheet_id, 
                pat.name, 
                DATE(inv.time_stamp) AS date
            FROM investigation_routines inv
            JOIN addpatient pat ON inv.patient_id = pat.patient_id
            WHERE inv.patient_id = ?";

    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        echo json_encode([
            'status' => false, // Change to boolean
            'message' => 'Failed to prepare SQL statement.',
        ], JSON_PRETTY_PRINT);
        exit;
    }

    // Bind the patient_id parameter
    $stmt->bind_param("s", $patient_id);

    // Execute the statement
    $stmt->execute();

    // Fetch the result
    $result = $stmt->get_result();
    $data = $result->fetch_all(MYSQLI_ASSOC);

    if ($data) {
        // Return the fetched data
        echo json_encode([
            'status' => true, // Change to boolean
            'message' => 'Records fetched successfully.', // Add success message
            'data' => $data,
        ], JSON_PRETTY_PRINT);
    } else {
        // Return an error message if no data is found
        echo json_encode([
            'status' => false, // Change to boolean
            'message' => 'No records found for the provided Patient ID.',
        ], JSON_PRETTY_PRINT);
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo json_encode([
        'status' => false, // Change to boolean
        'message' => 'Invalid request method.',
    ], JSON_PRETTY_PRINT);
}
?>
