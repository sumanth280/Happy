<?php
include 'con.php'; // Include your database connection file

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect the input data
    $medicine_id = $_POST['medicine_id'];
    $patient_id = $_POST['patient_id'];
    $medicine_name = $_POST['medicine_name'];
    $dosage = $_POST['dosage'];
    $days = $_POST['days'];
    $morning = $_POST['morning'];
    $afternoon = $_POST['afternoon'];
    $evening = $_POST['evening'];
    $night = $_POST['night'];
    $before_food = $_POST['before_food'];
    $after_food = $_POST['after_food'];
    $comments = $_POST['comments'];

    // Prepare the SQL statement to update the medicine details
    $sql = "UPDATE medication SET 
                medicine_name = ?, 
                dosage = ?, 
                days = ?, 
                morning = ?, 
                afternoon = ?, 
                evening = ?, 
                night = ?, 
                before_food = ?, 
                after_food = ?, 
                comments = ? 
            WHERE medicine_id = ? AND patient_id = ?";

    $stmt = $conn->prepare($sql);

    // Check if the SQL was prepared correctly
    if ($stmt === false) {
        echo json_encode([
            'status' => false,  // Set status to false in case of SQL preparation error
            'message' => 'Error in SQL preparation: ' . $conn->error
        ], JSON_PRETTY_PRINT);
        exit;
    }

    // Bind parameters
    $stmt->bind_param(
        "ssssssssssss", 
        $medicine_name, $dosage, $days, $morning, $afternoon, 
        $evening, $night, $before_food, $after_food, $comments, 
        $medicine_id, $patient_id
    );

    // Execute the statement
    if ($stmt->execute()) {
        echo json_encode([
            'status' => true,  // Set status to true if the update is successful
            'message' => 'Data updated successfully'
        ], JSON_PRETTY_PRINT);
    } else {
        echo json_encode([
            'status' => false,  // Set status to false if the update fails
            'message' => 'Failed to update data: ' . $stmt->error
        ], JSON_PRETTY_PRINT);
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo json_encode([
        'status' => false,  // Set status to false for invalid request method
        'message' => 'Invalid request method'
    ], JSON_PRETTY_PRINT);
}
?>
