<?php
// Include database connection
include 'con.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve patient_id and notification_id from the POST request
    $patient_id = isset($_POST['patient_id']) ? $_POST['patient_id'] : '';
    $notification_id = isset($_POST['notification_id']) ? $_POST['notification_id'] : '';

    if (empty($patient_id) || empty($notification_id)) {
        echo json_encode(['status' => false, 'message' => 'Patient ID and Notification ID are required']);
        exit;
    }

    try {
        // Query to update the status to 1 for the given patient_id and notification_id
        $query = "UPDATE alerts 
                  SET status = 1 
                  WHERE patient_id = ? 
                  AND notification_id = ? 
                  AND DATE(time_stamp) = CURDATE() 
                  AND status = 0";

        $stmt = $conn->prepare($query);
        $stmt->bind_param('ss', $patient_id, $notification_id);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            echo json_encode(['status' => true, 'message' => 'Alert status updated to 1']);
        } else {
            echo json_encode(['status' => false, 'message' => 'No matching alert found or status already updated']);
        }
    } catch (Exception $e) {
        echo json_encode(['status' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['status' => false, 'message' => 'Invalid request method']);
}
?>
