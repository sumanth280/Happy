<?php
include 'con.php'; // Include your database connection file

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect the patient_id from the POST request
    $patient_id = $_POST['patient_id'] ?? null;

    // Check if patient_id is provided
    if (!$patient_id) {
        echo json_encode([
            'status' => false,
            'message' => 'Patient ID is required.',
            'data' => null
        ], JSON_PRETTY_PRINT);
        exit;
    }

    // Prepare SQL statement to fetch data
    $sql = "SELECT * FROM risk_minor WHERE patient_id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        echo json_encode([
            'status' => false,
            'message' => 'Failed to prepare SQL statement for fetching data.',
            'data' => null
        ], JSON_PRETTY_PRINT);
        exit;
    }
    
    // Bind the patient_id parameter
    $stmt->bind_param("s", $patient_id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if the record exists
    if ($result->num_rows > 0) {
        $data = $result->fetch_assoc();
        echo json_encode([
            'status' => true,
            'message' => 'Data retrieved successfully.',
            'data' => $data
        ], JSON_PRETTY_PRINT);
    } else {
        echo json_encode([
            'status' => false,
            'message' => 'No data found for the provided Patient ID.',
            'data' => null
        ], JSON_PRETTY_PRINT);
    }

    // Close the statement
    $stmt->close();

    // Close the database connection
    if ($conn->close()) {
        // You may choose to return a message about the connection closure
    } else {
        echo json_encode([
            'status' => false,
            'message' => 'Failed to close database connection.',
            'data' => null
        ], JSON_PRETTY_PRINT);
    }
} else {
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method. Please use POST.',
        'data' => null
    ], JSON_PRETTY_PRINT);
}
?>
