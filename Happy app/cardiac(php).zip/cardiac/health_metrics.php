<?php
include 'con.php'; // Include your database connection file

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect the data from the POST request
    $patient_id = $_POST['patient_id'] ?? null;
    $pulse_rate = $_POST['pulse_rate'] ?? null;
    $spo2 = $_POST['spo2'] ?? null;
    $bp = $_POST['bp'] ?? null;
    $weight = $_POST['weight'] ?? null;
    $activity = $_POST['activity'] ?? null;
    $fluid_intake = $_POST['fluid_intake'] ?? null;
    $salt_intake = $_POST['salt_intake'] ?? null;
    $urine_output = $_POST['urine_output'] ?? null;

    // Validate required fields
    if ($patient_id && $pulse_rate && $spo2 && $bp && $weight && $activity && $fluid_intake && $salt_intake &&$urine_output) {
        // Proceed with the insert
        $sql_insert = "INSERT INTO health_metrics (
                        `patient_id`, `pulse_rate`, `spo2`, `bp`, `weight`, 
                        `activity`, `fluid_intake`, `salt_intake`, `urine_output`
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);";

        $stmt_insert = $conn->prepare($sql_insert);
        if ($stmt_insert === false) {
            echo json_encode([
                'status' => 'false',
                'message' => 'Failed to prepare SQL insert statement.',
            ], JSON_PRETTY_PRINT);
            exit;
        }

        $stmt_insert->bind_param(
            "sssssssss",
            $patient_id, $pulse_rate, $spo2, $bp, $weight, 
            $activity, $fluid_intake, $salt_intake, $urine_output
        );

        // Execute the statement
        if ($stmt_insert->execute()) {
            echo json_encode([
                'status' => 'true',
                'message' => 'Data inserted successfully.',
            ], JSON_PRETTY_PRINT);
        } else {
            echo json_encode([
                'status' => 'false',
                'message' => 'Failed to execute insert query.',
            ], JSON_PRETTY_PRINT);
        }

        // Close the insert statement
        $stmt_insert->close();
        $conn->close();
    } else {
        echo json_encode([
            'status' => 'false',
            'message' => 'Missing required fields.',
        ], JSON_PRETTY_PRINT);
    }
} else {
    echo json_encode([
        'status' => 'false',
        'message' => 'Invalid request method.',
    ], JSON_PRETTY_PRINT);
}
?>
