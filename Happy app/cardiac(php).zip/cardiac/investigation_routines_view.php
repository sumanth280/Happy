<?php
include 'con.php'; // Include your database connection file

header('Content-Type: application/json');

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect the data from the POST request
    $patient_id = $_POST['patient_id'] ?? null;
    $casesheet_id = $_POST['casesheet_id'] ?? null;

    // Check if patient_id and casesheet_id are provided
    if (!$patient_id || !$casesheet_id) {
        echo json_encode([
            'status' => false,  // Change to boolean false
            'message' => 'Patient ID and Casesheet ID are required.',  // Add message
        ], JSON_PRETTY_PRINT);
        exit;
    }

    // Prepare the SQL statement to fetch data based on the patient_id and casesheet_id
    $sql = "SELECT s_no, patient_id, cbc_hb, cbc_tlc, rft_creatinine, sgot, sgpt, total_bilibubin, sodium, pottasium, chloride, sodium_bicarbonate, time_stamp
            FROM investigation_routines 
            WHERE patient_id = ? AND casesheet_id = ?";

    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        echo json_encode([
            'status' => false,  // Change to boolean false
            'message' => 'Failed to prepare SQL statement: ' . $conn->error,  // Add message with error detail
        ], JSON_PRETTY_PRINT);
        exit;
    }

    // Bind the parameters
    $stmt->bind_param("ss", $patient_id, $casesheet_id);

    // Execute the statement
    $stmt->execute();

    // Fetch all the results
    $result = $stmt->get_result();
    $data = $result->fetch_all(MYSQLI_ASSOC);

    if ($data) {
        // Return the fetched data
        echo json_encode([
            'status' => true,  // Change to boolean true
            'message' => 'Data retrieved successfully.',  // Add success message
            'data' => $data,
        ], JSON_PRETTY_PRINT);
    } else {
        echo json_encode([
            'status' => false,  // Change to boolean false
            'message' => 'No data found for the provided Patient ID and Casesheet ID.',  // Add message
        ], JSON_PRETTY_PRINT);
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo json_encode([
        'status' => false,  // Change to boolean false
        'message' => 'Invalid request method.',  // Add message
    ], JSON_PRETTY_PRINT);
}
?>
