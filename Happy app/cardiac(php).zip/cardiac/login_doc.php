<?php
include 'con.php';

header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];

switch($method) {
    case 'POST':
        // Check if form data is sent using POST method
        if(isset($_POST['doctor_id']) && isset($_POST['password'])) {
            $doctor_id = $_POST['doctor_id'];
            $password = $_POST['password'];

            // Prepare and bind the SQL statement to check doctor_id and password in the doctor_profile table
            $stmt = $conn->prepare("SELECT * FROM doctor_profile WHERE doctor_id = ? AND password = ?");
            $stmt->bind_param("ss", $doctor_id, $password);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                // Fetch the doctor data
                $doctorData = $result->fetch_assoc();
                
                // Send success response with doctor profile data
                echo json_encode([
                    "status" => true, 
                    "message" => "Login successful", 
                    "data" => $doctorData
                ]);
            } else {
                echo json_encode(["status" => false, "message" => "Invalid doctor_id or password"]);
            }

            // Close the statement
            $stmt->close();
        } else {
            echo json_encode(["status" => false, "message" => "Invalid input"]);
        }
        break;

    default:
        echo json_encode(["status" => false, "message" => "Unsupported request method"]);
        break;
}

// Close the connection
$conn->close();
?>
