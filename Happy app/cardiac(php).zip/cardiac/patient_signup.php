<?php
include 'con.php'; // Include your database connection file

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect the data from the POST request
    $name = $_POST['name'] ?? null;
    $age = $_POST['age'] ?? null; // Expected format: YYYY-MM-DD
    $gender = $_POST['gender'] ?? null;
    $phone_number_1 = $_POST['phone_number_1'] ?? null;
    $profession = $_POST['profession'] ?? null;
    $weight = $_POST['weight'] ?? null;
    $height = $_POST['height'] ?? null;
    $phone_number_2 = $_POST['phone_number_2'] ?? null;
    $address = $_POST['address'] ?? null;
    $password = $_POST['password'] ?? null;
    $confirm_password = $_POST['confirm_password'] ?? null;

    // Check if any required field is missing
    if (!$name || !$age || !$gender || !$phone_number_1 || !$profession || !$weight || !$height || !$phone_number_2 || !$address || !$password || !$confirm_password) {
        echo json_encode([
            'status' => false, // Set to false in case of missing fields
            'message' => 'Please enter all required details.',
        ], JSON_PRETTY_PRINT);
        exit;
    }

    // Validate the password and confirm password match
    if ($password !== $confirm_password) {
        echo json_encode([
            'status' => false, // Set to false if passwords do not match
            'message' => 'Password and confirm password do not match.',
        ], JSON_PRETTY_PRINT);
        exit;
    }

    // Generate the patient ID based on the current timestamp in yymmddhhmi format
    $patient_id = date('ymdHi');

    // Set profile_pic to '0' (or default image file name) as a placeholder
    $profile_pic = '0';  // You can change this to 'default.jpg' if you're using a string for the image file name

    // Prepare the SQL statement to insert patient details
    $sql = "INSERT INTO addpatient (
                patient_id, name, age, gender, phone_number_1, profession, 
                weight, height, phone_number_2, address, password, profile_pic
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    // Prepare and bind parameters to the SQL statement
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssssssss", $patient_id, $name, $age, $gender, $phone_number_1, $profession, $weight, $height, $phone_number_2, $address, $password, $profile_pic);

    // Execute the statement
    if ($stmt->execute()) {
        echo json_encode([
            'status' => true, // Set to true if inserted successfully
            'message' => 'Account created successfully.',
            'patient_id' => $patient_id, // Display the generated patient_id
        ], JSON_PRETTY_PRINT);
    } else {
        echo json_encode([
            'status' => false, // Set to false in case of insertion failure
            'message' => 'Failed to execute query.',
        ], JSON_PRETTY_PRINT);
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo json_encode([
        'status' => false, // Set to false for invalid request method
        'message' => 'Invalid request method.',
    ], JSON_PRETTY_PRINT);
}
?>
