<?php
include 'con.php'; // Include your database connection file

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect the data from the POST request
    $doctor_id = $_POST['doctor_id']; // This should be provided and will not be changed
    $doc_name = $_POST['doc_name'] ?? null;
    $age = $_POST['age'] ?? null;
    $gender = $_POST['gender'] ?? null;
    $phone_number = $_POST['phone_number'] ?? null;
    $address = $_POST['address'] ?? null;

    // Check if doctor_id is provided
    if (!$doctor_id) {
        echo json_encode([
            'status' => false,
            'message' => 'Doctor ID is required.',
        ], JSON_PRETTY_PRINT);
        exit;
    }

    // Prepare the SQL statement to update the data
    $sql = "UPDATE doctor_profile SET 
                doc_name = COALESCE(?, doc_name), 
                age = COALESCE(?, age), 
                gender = COALESCE(?, gender), 
                phone_number = COALESCE(?, phone_number), 
                address = COALESCE(?, address) 
            WHERE doctor_id = ?";

    $stmt = $conn->prepare($sql);
    
    if ($stmt === false) {
        echo json_encode([
            'status' => false,
            'message' => 'Failed to prepare SQL statement.',
        ], JSON_PRETTY_PRINT);
        exit;
    }

    // Bind parameters to the SQL query
    $stmt->bind_param("ssssss", $doc_name, $age, $gender, $phone_number, $address, $doctor_id);

    // Execute the statement
    if ($stmt->execute()) {
        echo json_encode([
            'status' => true,
            'message' => 'Data updated successfully.',
        ], JSON_PRETTY_PRINT);
    } else {
        echo json_encode([
            'status' => false,
            'message' => 'Failed to update data.',
        ], JSON_PRETTY_PRINT);
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.',
    ], JSON_PRETTY_PRINT);
}
?>
