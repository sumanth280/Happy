<?php
include 'con.php'; // Include your database connection file

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect the data from the POST request
    $patient_id = $_POST['patient_id'] ?? null;
    $medicine_name = $_POST['medicine_name'] ?? null;
    $time_med = $_POST['time_med'] ?? null;
    $monday = $_POST['monday'] ?? 'no';
    $tuesday = $_POST['tuesday'] ?? 'no';
    $wednesday = $_POST['wednesday'] ?? 'no';
    $thursday = $_POST['thursday'] ?? 'no';
    $friday = $_POST['friday'] ?? 'no';
    $saturday = $_POST['saturday'] ?? 'no';
    $sunday = $_POST['sunday'] ?? 'no';

    // Validate required fields
    if ($patient_id && $medicine_name && $time_med) {
        // Generate a unique notification_id
        $notification_id = generateUniqueNotificationId($conn);

        // Prepare the SQL statement to insert the data
        $sql = "INSERT INTO notification (
                    patient_id, notification_id, medicine_name, time_med, 
                    monday, tuesday, wednesday, thursday, friday, saturday, sunday
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $stmt = $conn->prepare($sql);
        if ($stmt === false) {
            echo json_encode([
                'status' => false,  // Set status to false in case of SQL preparation error
                'message' => 'Error in SQL preparation: ' . $conn->error
            ], JSON_PRETTY_PRINT);
            exit;
        }

        $stmt->bind_param(
            "sssssssssss",
            $patient_id, $notification_id, $medicine_name, $time_med, 
            $monday, $tuesday, $wednesday, $thursday, $friday, $saturday, $sunday
        );

        // Execute the statement
        if ($stmt->execute()) {
            echo json_encode([
                'status' => true,  // Set status to true if data is inserted successfully
                'message' => 'Notification data inserted successfully',
                'notification_id' => $notification_id,
            ], JSON_PRETTY_PRINT);
        } else {
            echo json_encode([
                'status' => false,  // Set status to false if insertion fails
                'message' => 'Failed to insert data.',
            ], JSON_PRETTY_PRINT);
        }

        // Close the statement and connection
        $stmt->close();
        $conn->close();
    } else {
        echo json_encode([
            'status' => false,  // Set status to false if required fields are missing
            'message' => 'Missing required fields: patient_id, medicine_name, or time_med.',
        ], JSON_PRETTY_PRINT);
    }
} else {
    echo json_encode([
        'status' => false,  // Set status to false for invalid request method
        'message' => 'Invalid request method.',
    ], JSON_PRETTY_PRINT);
}

// Function to generate a unique notification_id
function generateUniqueNotificationId($conn) {
    $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $digits = '0123456789';
    $notification_id = '';
    do {
        $notification_id = $alphabet[rand(0, strlen($alphabet) - 1)] . sprintf('%06d', rand(0, 999999));
        // Check if the generated id already exists
        $sql = "SELECT COUNT(*) FROM notification WHERE notification_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $notification_id);
        $stmt->execute();
        $stmt->bind_result($count);
        $stmt->fetch();
        $stmt->close();
    } while ($count > 0); // Repeat if id exists
    return $notification_id;
}
?>
