<?php

// Include the database connection file
include 'con.php';

$response = ["status" => false, "message" => ""];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['patient_id']) && isset($_POST['date']) && isset($_POST['time']) && isset($_POST['comment'])) {
        $patient_id = mysqli_real_escape_string($conn, $_POST['patient_id']);
        $date = mysqli_real_escape_string($conn, $_POST['date']);
        $time = mysqli_real_escape_string($conn, $_POST['time']);
        $comment = mysqli_real_escape_string($conn, $_POST['comment']);

        // Here you could add additional checks for valid patient_id, etc.
        // For example, check if the patient_id exists in another table.

        $sql = "INSERT INTO appointments (patient_id, date, time, comments) VALUES ('$patient_id', '$date', '$time', '$comment')";

        if (mysqli_query($conn, $sql)) {
            $response["status"] = true;
            $response["message"] = "Appointment created successfully.";
        } else {
            $response["message"] = "Error: " . mysqli_error($conn);
        }
    } else {
        $response["message"] = "Invalid patient_id or data missing.";
    }
} else {
    $response["message"] = "Invalid request method.";
}

// Output the response as JSON
header('Content-Type: application/json');
echo json_encode($response);

// Close the database connection
mysqli_close($conn);
?>
