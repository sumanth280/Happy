<?php
include 'con.php'; // Include your database connection file

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect the data from the POST request
    $patient_id = $_POST['patient_id'] ?? null;
    $password = $_POST['password'] ?? null; // Current password
    $confirm_password = $_POST['confirm_password'] ?? null; // New password to update

    // Check if all required fields are provided
    if (!$patient_id || !$password || !$confirm_password) {
        echo json_encode([
            'status' => false,
            'message' => 'All fields (patient_id, password, confirm_password) are required.',
        ], JSON_PRETTY_PRINT);
        exit;
    }

    // Prepare the SQL statement to fetch the existing password for the patient
    $sql = "SELECT password FROM addpatient WHERE patient_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $patient_id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if the patient exists
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Check if the provided current password matches the existing password
        if ($password === $row['password']) {
            // Prepare the SQL statement to update both password and confirm_password with the new password
            $update_sql = "UPDATE addpatient SET password = ?, confirm_password = ? WHERE patient_id = ?";
            $update_stmt = $conn->prepare($update_sql);
            $update_stmt->bind_param("sss", $confirm_password, $confirm_password, $patient_id);

            // Execute the statement
            if ($update_stmt->execute()) {
                echo json_encode([
                    'status' => true,
                    'message' => 'Password updated successfully.',
                ], JSON_PRETTY_PRINT);
            } else {
                echo json_encode([
                    'status' => false,
                    'message' => 'Failed to update the password.',
                ], JSON_PRETTY_PRINT);
            }

            // Close the update statement
            $update_stmt->close();
        } else {
            echo json_encode([
                'status' => false,
                'message' => 'Current password does not match.',
            ], JSON_PRETTY_PRINT);
        }
    } else {
        echo json_encode([
            'status' => false,
            'message' => 'Patient not found.',
        ], JSON_PRETTY_PRINT);
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.',
    ], JSON_PRETTY_PRINT);
}
?>
