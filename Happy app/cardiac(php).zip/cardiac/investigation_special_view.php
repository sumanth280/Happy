<?php
include 'con.php'; // Include your database connection file

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect patient_id and special_casesheet_id from the POST request
    $patient_id = $_POST['patient_id'] ?? null;
    $special_casesheet_id = $_POST['special_casesheet_id'] ?? null;

    // Check if patient_id and special_casesheet_id are provided
    if (!$patient_id || !$special_casesheet_id) {
        echo json_encode([
            'status' => false,  // Change to boolean false
            'message' => 'Patient ID and Special Casesheet ID are required.',  // Add message
        ], JSON_PRETTY_PRINT);
        exit;
    }

    // Prepare SQL statement to fetch data based on patient_id and special_casesheet_id
    $sql = "SELECT 
                s_no, patient_id, h1ba1c, triglycerides, ldl, hdl, bnp, tsh, ft3, ft4, 
                ecg_findings, echo_findings, usg_abdomen_findings, stage, time_stamp
            FROM investigation_special 
            WHERE patient_id = ? AND special_casesheet_id = ?";

    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        echo json_encode([
            'status' => false,  // Change to boolean false
            'message' => 'Failed to prepare SQL statement: ' . $conn->error,  // Add message with error detail
        ], JSON_PRETTY_PRINT);
        exit;
    }

    // Bind the parameters
    $stmt->bind_param("ss", $patient_id, $special_casesheet_id);

    // Execute the statement
    $stmt->execute();

    // Fetch all the results
    $result = $stmt->get_result();
    $data = $result->fetch_all(MYSQLI_ASSOC);

    if ($data) {
        // Return the fetched data
        echo json_encode([
            'status' => true,  // Change to boolean true
            'message' => 'Data retrieved successfully.',  // Add success message
            'data' => $data,
        ], JSON_PRETTY_PRINT);
    } else {
        echo json_encode([
            'status' => false,  // Change to boolean false
            'message' => 'No data found for the provided Patient ID and Special Casesheet ID.',  // Add message
        ], JSON_PRETTY_PRINT);
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo json_encode([
        'status' => false,  // Change to boolean false
        'message' => 'Invalid request method.',  // Add message
    ], JSON_PRETTY_PRINT);
}
?>
