<?php
include 'con.php'; // Include your database connection file

header('Content-Type: application/json');

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect data from POST request
    $patient_id = $_POST['patient_id'] ?? null;
    $age = $_POST['age'] ?? null;
    $gender = $_POST['gender'] ?? null;
    $bmi = $_POST['bmi'] ?? null;
    $sbp = $_POST['sbp'] ?? null;
    $creatinine = $_POST['creatinine'] ?? null;
    $current_smoker = $_POST['current_smoker'] ?? null;
    $diabetes = $_POST['diabetes'] ?? null;
    $heart_failure = $_POST['heart_failure'] ?? null;
    $beta_blockers = $_POST['beta_blockers'] ?? null;
    $acei_arb = $_POST['acei_arb'] ?? null;
    $nyha = $_POST['nyha'] ?? null;

    // Validate required fields
    if (!$patient_id) {
        echo json_encode([
            'status' => false,
            'message' => 'Patient ID is required.',
        ], JSON_PRETTY_PRINT);
        exit;
    }

    // Debugging: Check if the 'diabetes' field is received correctly
    // You can log this for debugging purposes
    // file_put_contents('debug_log.txt', var_export($_POST, true), FILE_APPEND);

    // Prepare SQL to check if patient ID exists
    $check_sql = "SELECT * FROM risk_primary WHERE patient_id = ?";
    $stmt = $conn->prepare($check_sql);

    if ($stmt === false) {
        echo json_encode([
            'status' => false,
            'message' => 'Failed to prepare SQL statement.',
        ], JSON_PRETTY_PRINT);
        exit;
    }

    $stmt->bind_param("s", $patient_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Update existing data
        $sql = "UPDATE risk_primary SET 
                age = ?, gender = ?, bmi = ?, sbp = ?, creatinine = ?, current_smoker = ?, diabetes = ?, heart_failure = ?, beta_blockers = ?, acei_arb = ?, nyha = ?
                WHERE patient_id = ?";

        $stmt = $conn->prepare($sql);
        if ($stmt === false) {
            echo json_encode([
                'status' => false,
                'message' => 'Failed to prepare SQL statement for update.',
            ], JSON_PRETTY_PRINT);
            exit;
        }

        $stmt->bind_param("ssssssssssss", $age, $gender, $bmi, $sbp, $creatinine, $current_smoker, $diabetes, $heart_failure, $beta_blockers, $acei_arb, $nyha, $patient_id);

        if ($stmt->execute()) {
            echo json_encode([
                'status' => true,
                'message' => 'Data updated successfully.',
            ], JSON_PRETTY_PRINT);
        } else {
            echo json_encode([
                'status' => false,
                'message' => 'Failed to update data.',
            ], JSON_PRETTY_PRINT);
        }
    } else {
        // Insert new data
        $sql = "INSERT INTO risk_primary (patient_id, age, gender, bmi, sbp, creatinine, current_smoker, diabetes,heart_failure , beta_blockers, acei_arb, nyha)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $stmt = $conn->prepare($sql);
        if ($stmt === false) {
            echo json_encode([
                'status' => false,
                'message' => 'Failed to prepare SQL statement for insert.',
            ], JSON_PRETTY_PRINT);
            exit;
        }

        $stmt->bind_param("ssssssssssss", $patient_id, $age, $gender, $bmi, $sbp, $creatinine, $current_smoker, $diabetes, $heart_failure, $beta_blockers, $acei_arb, $nyha);

        if ($stmt->execute()) {
            echo json_encode([
                'status' => true,
                'message' => 'Data inserted successfully.',
            ], JSON_PRETTY_PRINT);
        } else {
            echo json_encode([
                'status' => false,
                'message' => 'Failed to insert data.',
            ], JSON_PRETTY_PRINT);
        }
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.',
    ], JSON_PRETTY_PRINT);
}
?>
