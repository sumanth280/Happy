<?php
include 'con.php'; // Include your database connection file

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect the data from the POST request
    $patient_id = $_POST['patient_id'] ?? null;

    if ($patient_id) {
        // Prepare the SQL statement to fetch data for the current date
        $sql = "SELECT * FROM symptom_monitoring 
                WHERE patient_id = ? 
                AND DATE(time_stamp) = CURDATE()";

        $stmt = $conn->prepare($sql);
        if ($stmt === false) {
            echo json_encode([
                'status' => false,  // Set status to false for SQL preparation error
                'message' => 'Failed to prepare SQL statement: ' . $conn->error,
            ], JSON_PRETTY_PRINT);
            exit;
        }

        $stmt->bind_param("s", $patient_id);

        // Execute the statement
        if ($stmt->execute()) {
            $result = $stmt->get_result();
            if ($result->num_rows > 0) {
                $data = $result->fetch_all(MYSQLI_ASSOC);
                echo json_encode([
                    'status' => true,  // Set status to true if data is found
                    'message' => 'Data retrieved successfully.',
                    'data' => $data,
                ], JSON_PRETTY_PRINT);
            } else {
                echo json_encode([
                    'status' => true,  // Set status to true even if no data is found
                    'message' => 'No data found for the given patient ID on the current date.',
                    'data' => [], // Return an empty array for clarity
                ], JSON_PRETTY_PRINT);
            }
        } else {
            echo json_encode([
                'status' => false,  // Set status to false if query execution fails
                'message' => 'Failed to execute query: ' . $stmt->error,
            ], JSON_PRETTY_PRINT);
        }

        // Close the statement and connection
        $stmt->close();
        $conn->close();
    } else {
        echo json_encode([
            'status' => false,  // Set status to false if patient ID is not provided
            'message' => 'Patient ID is required.',
        ], JSON_PRETTY_PRINT);
    }
} else {
    echo json_encode([
        'status' => false,  // Set status to false for invalid request method
        'message' => 'Invalid request method.',
    ], JSON_PRETTY_PRINT);
}
?>
