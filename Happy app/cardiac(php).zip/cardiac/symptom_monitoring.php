<?php
include 'con.php'; // Include your database connection file

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect the data from the POST request
    $patient_id = $_POST['patient_id'] ?? null;
    $shortness_of_breath = $_POST['shortness_of_breath'] ?? 'no';
    $cough = $_POST['cough'] ?? 'no';

    // Automatically set dependent fields to 'no' if the main symptoms are 'no'
    $while_working = ($shortness_of_breath === 'yes') ? ($_POST['while_working'] ?? null) : 'no';
    $while_rest = ($shortness_of_breath === 'yes') ? ($_POST['while_rest'] ?? null) : 'no';
    $occasional = ($cough === 'yes') ? ($_POST['occasional'] ?? null) : 'no';
    $frequent = ($cough === 'yes') ? ($_POST['frequent'] ?? null) : 'no';

    $fatigue_weakness = $_POST['fatigue_weakness'] ?? 'no';
    $chest_pain = $_POST['chest_pain'] ?? 'no';
    $palpatations = $_POST['palpatations'] ?? 'no';
    $abdomen_discomfort = $_POST['abdomen_discomfort'] ?? 'no';
    $confusion = $_POST['confusion'] ?? 'no';
    $weight_gain = $_POST['weight_gain'] ?? 'no';
    $sleep_difficulty = $_POST['sleep_difficulty'] ?? 'no';

    // Determine condition_status
    $condition_status = 'Good';
    if ($shortness_of_breath === 'yes' || $cough === 'yes') {
        if ($while_working === 'yes' || $occasional === 'yes') {
            $condition_status = 'Caution';
        } else {
            $condition_status = 'Warning';
        }
    }

    // Count the number of symptoms marked as 'yes'
    $symptoms = [
        $shortness_of_breath, $while_working, $while_rest, $cough, $occasional, $frequent,
        $fatigue_weakness, $chest_pain, $palpatations, $abdomen_discomfort, $confusion,
        $weight_gain, $sleep_difficulty
    ];

    $yes_count = count(array_filter($symptoms, function($symptom) {
        return $symptom === 'yes';
    }));

    // Prepare the SQL statement to insert the data
    $sql = "INSERT INTO symptom_monitoring (
                `patient_id`, `shortness_of_breath`, `while_working`, `while_rest`, 
                `cough`, `occasional`, `frequent`, `fatigue_weakness`, `chest_pain`, 
                `palpatations`, `abdomen_discomfort`, `confusion`, `weight_gain`, 
                `sleep_difficulty`, `condition_status`
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        echo json_encode([
            'status' => 'false',
            'message' => 'Failed to prepare SQL statement.',
        ], JSON_PRETTY_PRINT);
        exit;
    }

    $stmt->bind_param(
        "sssssssssssssss",
        $patient_id, $shortness_of_breath, $while_working, $while_rest,
        $cough, $occasional, $frequent, $fatigue_weakness, $chest_pain,
        $palpatations, $abdomen_discomfort, $confusion, $weight_gain,
        $sleep_difficulty, $condition_status
    );

    // Execute the statement
    if ($stmt->execute()) {
        $message = 'Symptoms saved successfully';
        if ($yes_count >= 2) {
            $message .= "\nWarning: Contact doctor immediately.";
        }

        echo json_encode([
            'status' => 'true',
            'message' => $message
        ], JSON_PRETTY_PRINT);
    } else {
        echo json_encode([
            'status' => 'false',
            'message' => 'Failed to execute query: ' . $stmt->error,
        ], JSON_PRETTY_PRINT);
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo json_encode([
        'status' => 'false',
        'message' => 'Invalid request method.',
    ], JSON_PRETTY_PRINT);
}
?>
