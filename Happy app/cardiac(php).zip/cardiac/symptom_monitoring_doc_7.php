<?php
include 'con.php'; // Include your database connection file

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect the data from the POST request
    $patient_id = $_POST['patient_id'] ?? null;
    $filter = $_POST['filter'] ?? null; // Dropdown input ('today', 'last_week', or 'date_range')
    $start_date = $_POST['start_date'] ?? null; // Used for 'date_range'
    $end_date = $_POST['end_date'] ?? null; // Used for 'date_range'

    if ($patient_id && $filter) {
        $data = [];

        if ($filter === 'today') {
            // Fetch entries for the current date
            $date = date('Y-m-d');
            $sql = "SELECT * FROM symptom_monitoring 
                    WHERE patient_id = ? 
                    AND DATE(time_stamp) = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ss", $patient_id, $date);

        } elseif ($filter === 'last_week') {
            // Fetch entries for the last 7 days including today
            $sql = "SELECT * FROM symptom_monitoring 
                    WHERE patient_id = ? 
                    AND DATE(time_stamp) >= DATE_SUB(CURDATE(), INTERVAL 6 DAY) 
                    AND DATE(time_stamp) <= CURDATE()";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $patient_id);

        } elseif ($filter === 'date_range' && $start_date && $end_date) {
            // Fetch entries between start date and end date
            $sql = "SELECT * FROM symptom_monitoring 
                    WHERE patient_id = ? 
                    AND DATE(time_stamp) BETWEEN ? AND ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sss", $patient_id, $start_date, $end_date);

        } else {
            echo json_encode([
                'status' => false,
                'message' => 'Invalid filter or missing date range.',
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Execute the query
        if ($stmt->execute()) {
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                // Fetch all data
                while ($row = $result->fetch_assoc()) {
                    $data[] = $row;
                }
            } else {
                $data = 'No data found for the selected filter.';
            }
        } else {
            echo json_encode([
                'status' => false,
                'message' => 'Failed to execute query.',
                'error' => $stmt->error,
            ], JSON_PRETTY_PRINT);
            exit;
        }

        $stmt->close();

        // Return the fetched data
        echo json_encode([
            'status' => true,
            'message' => 'Data fetched successfully.',
            'data' => $data,
        ], JSON_PRETTY_PRINT);

        $conn->close();
    } else {
        echo json_encode([
            'status' => false,
            'message' => 'Patient ID and filter are required.',
        ], JSON_PRETTY_PRINT);
    }
} else {
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method.',
    ], JSON_PRETTY_PRINT);
}
?>
