<?php
include 'con.php'; // Include your database connection file

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect the data from the POST request
    $patient_id = $_POST['patient_id'] ?? null;
    $medicine_name = $_POST['medicine_name'] ?? null;
    $dosage = $_POST['dosage'] ?? null;
    $days = $_POST['days'] ?? null;
    $morning = $_POST['morning'] ?? 'no'; // Default to 'no' if not provided
    $afternoon = $_POST['afternoon'] ?? 'no'; // Default to 'no' if not provided
    $night = $_POST['night'] ?? 'no'; // Default to 'no' if not provided
    $before_food = $_POST['before_food'] ?? 'no'; // Default to 'no' if not provided
    $after_food = $_POST['after_food'] ?? 'no'; // Default to 'no' if not provided
    $comments = $_POST['comments'] ?? null;

    // Validate required fields
    if ($patient_id && $medicine_name) {
        // Generate a unique medicine_id
        $medicine_id = generateUniqueMedicineId($conn);

        // Ensure only one of before_food or after_food is 'yes'
        if ($before_food === 'yes') {
            $after_food = 'no';
        } elseif ($after_food === 'yes') {
            $before_food = 'no';
        }

        // Prepare the SQL statement to insert the data
        $sql = "INSERT INTO medication (
                    patient_id, medicine_name, medicine_id, dosage, days, 
                    morning, afternoon, night, before_food, after_food, comments
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $stmt = $conn->prepare($sql);
        if ($stmt === false) {
            echo json_encode([
                'status' => false,  // Set status to false in case of SQL preparation error
                'message' => 'Error in SQL preparation: ' . $conn->error
            ], JSON_PRETTY_PRINT);
            exit;
        }

        $stmt->bind_param(
            "sssssssssss",
            $patient_id, $medicine_name, $medicine_id, $dosage, $days, 
            $morning, $afternoon, $night, $before_food, $after_food, $comments
        );

        // Execute the statement
        if ($stmt->execute()) {
            echo json_encode([
                'status' => true,  // Set status to true if data is inserted successfully
                'message' => 'Medicine added successfully',
                'medicine_id' => $medicine_id,
            ], JSON_PRETTY_PRINT);
        } else {
            echo json_encode([
                'status' => false,  // Set status to false if insertion fails
                'message' => 'Failed to insert data.',
            ], JSON_PRETTY_PRINT);
        }

        // Close the statement and connection
        $stmt->close();
        $conn->close();
    } else {
        echo json_encode([
            'status' => false,  // Set status to false if required fields are missing
            'message' => 'Missing required fields.',
        ], JSON_PRETTY_PRINT);
    }
} else {
    echo json_encode([
        'status' => false,  // Set status to false for invalid request method
        'message' => 'Invalid request method.',
    ], JSON_PRETTY_PRINT);
}

// Function to generate a unique medicine_id
function generateUniqueMedicineId($conn) {
    $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $digits = '0123456789';
    $medicine_id = '';
    do {
        $medicine_id = $alphabet[rand(0, strlen($alphabet) - 1)] . sprintf('%06d', rand(0, 999999));
        // Check if the generated id already exists
        $sql = "SELECT COUNT(*) FROM medication WHERE medicine_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $medicine_id);
        $stmt->execute();
        $stmt->bind_result($count);
        $stmt->fetch();
        $stmt->close();
    } while ($count > 0); // Repeat if id exists
    return $medicine_id;
}
?>
