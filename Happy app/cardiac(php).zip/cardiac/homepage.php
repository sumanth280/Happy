<?php
include 'con.php'; // Include your database connection file

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Prepare the SQL statement to fetch all patient_ids from the addpatient table
    $sql_addpatient = "SELECT patient_id, name, profile_pic FROM addpatient";
    $result_addpatient = $conn->query($sql_addpatient);

    // Check if any patients exist
    if ($result_addpatient->num_rows > 0) {
        $response = [];
        $s_no = 1;

        // Get the current date in 'Y-m-d' format
        $current_date = date('Y-m-d');

        // Loop through each patient from the addpatient table
        while ($addpatient_data = $result_addpatient->fetch_assoc()) {
            $patient_id = $addpatient_data['patient_id'];

            // Fetch data from symptom_monitoring table for the current patient_id and current day
            $sql_symptom = "SELECT condition_status FROM symptom_monitoring WHERE patient_id = ? AND DATE(time_stamp) = ?";
            $stmt_symptom = $conn->prepare($sql_symptom);
            
            // Check if the SQL was prepared correctly
            if ($stmt_symptom === false) {
                echo json_encode([
                    'status' => false,
                    'message' => 'Error in SQL for symptom_monitoring: ' . $conn->error
                ], JSON_PRETTY_PRINT);
                exit;
            }

            $stmt_symptom->bind_param("ss", $patient_id, $current_date);
            $stmt_symptom->execute();
            $result_symptom = $stmt_symptom->get_result();
            $symptom_data = $result_symptom->fetch_assoc();

            // Fetch the most recent stage data from investigation_special table based on time_stamp
            $sql_investigation = "SELECT stage 
                                  FROM investigation_special 
                                  WHERE patient_id = ? 
                                  ORDER BY time_stamp DESC LIMIT 1";
            $stmt_investigation = $conn->prepare($sql_investigation);
            
            // Check if the SQL was prepared correctly
            if ($stmt_investigation === false) {
                echo json_encode([
                    'status' => false,
                    'message' => 'Error in SQL for investigation_special: ' . $conn->error
                ], JSON_PRETTY_PRINT);
                exit;
            }

            $stmt_investigation->bind_param("s", $patient_id);
            $stmt_investigation->execute();
            $result_investigation = $stmt_investigation->get_result();
            $investigation_data = $result_investigation->fetch_assoc();

            // Combine all data under the same serial number
            $response[] = [
                's.no' => $s_no++,
                'patient_id' => $addpatient_data['patient_id'],
                'name' => $addpatient_data['name'] ?? '',
                'profile_pic' => $addpatient_data['profile_pic'] ?? 'No Profile Pic', // Include profile_pic
                'condition_status' => $symptom_data['condition_status'] ?? 'No Data',
                'stage' => $investigation_data['stage'] ?? 'No Data'
            ];

            // Close statement after each execution
            $stmt_symptom->close();
            $stmt_investigation->close();
        }

        // Output the combined data
        echo json_encode([
            'status' => true,
            'message' => 'Patient data fetched successfully.',
            'data' => $response
        ], JSON_PRETTY_PRINT);
    } else {
        // If no patients are found in the addpatient table
        echo json_encode([
            'status' => true,
            'message' => 'No patients found in the database.',
        ], JSON_PRETTY_PRINT);
    }

    // Close the connection
    $conn->close();
} else {
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method. Please use POST method.',
    ], JSON_PRETTY_PRINT);
}
?>
