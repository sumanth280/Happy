<?php
include 'con.php'; // Include your database connection file

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect the patient_id from the POST request
    $patient_id = $_POST['patient_id'] ?? null;

    if ($patient_id) {
        // Prepare the SQL statement to fetch all records for the given patient_id
        $sql = "SELECT medicine_name, medicine_id, dosage, days, morning, afternoon, night, before_food, after_food, comments, time_stamp 
                FROM medication 
                WHERE patient_id = ?";
        
        $stmt = $conn->prepare($sql);
        if ($stmt === false) {
            echo json_encode([
                'status' => false, // Set status to false for SQL preparation error
                'message' => 'Error in SQL preparation: ' . $conn->error
            ], JSON_PRETTY_PRINT);
            exit;
        }

        $stmt->bind_param("s", $patient_id);
        $stmt->execute();
        $result = $stmt->get_result();

        $medicines = [];
        $current_date = new DateTime(); // Get the current date and time

        while ($row = $result->fetch_assoc()) {
            // Extract date from time_stamp
            $assigned_date = new DateTime($row['time_stamp']);
            
            // Calculate the end date of the medication
            $end_date = clone $assigned_date;
            $end_date->modify("+{$row['days']} days");

            // Calculate days left, ensuring not to include the current day
            $interval = $current_date->diff($end_date);
            $days_left = $interval->days;

            // Adjust days left if the medication has ended
            if ($current_date > $end_date) {
                $days_left = 0;
            }

            // Add the medicine data with days_left to the array
            $row['days_left'] = $days_left;
            $medicines[] = $row;
        }

        // Check if any medicines are found
        if (count($medicines) > 0) {
            echo json_encode([
                'status' => true, // Set status to true if medicines are found
                'message' => 'Medicines found.',
                'medicines' => $medicines
            ], JSON_PRETTY_PRINT);
        } else {
            echo json_encode([
                'status' => false, // Set status to false if no medicines are found
                'message' => 'No medicines found for the provided patient_id.'
            ], JSON_PRETTY_PRINT);
        }

        // Close the statement and connection
        $stmt->close();
        $conn->close();
    } else {
        echo json_encode([
            'status' => false, // Set status to false if patient_id is missing
            'message' => 'Missing patient_id.'
        ], JSON_PRETTY_PRINT);
    }
} else {
    echo json_encode([
        'status' => false, // Set status to false if request method is not POST
        'message' => 'Invalid request method.'
    ], JSON_PRETTY_PRINT);
}
?>
