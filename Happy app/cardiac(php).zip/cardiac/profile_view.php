<?php
include 'con.php'; // Include your database connection file

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if patient_id is provided
    if (!isset($_POST['patient_id']) || empty($_POST['patient_id'])) {
        echo json_encode([
            'status' => 'error',
            'message' => 'patient_id is required.',
        ], JSON_PRETTY_PRINT);
        exit;
    }

    // Get the patient_id from the POST request
    $patient_id = $_POST['patient_id'];

    // Prepare the SQL statement to fetch the profile_pic and name for the given patient_id
    $sql = "SELECT profile_pic, name FROM addpatient WHERE patient_id = ?";

    $stmt = $conn->prepare($sql);
    
    // Check if the SQL was prepared correctly
    if ($stmt === false) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Error in SQL preparation: ' . $conn->error
        ], JSON_PRETTY_PRINT);
        exit;
    }

    $stmt->bind_param("s", $patient_id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if a profile picture and name were found
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        echo json_encode([
            'status' => 'success',
            'patient_id' => $patient_id,
            'name' => $row['name'], // Fetching the patient's name
            'profile_pic' => $row['profile_pic'] ?? 'No Profile Pic', // Fetching the profile picture
        ], JSON_PRETTY_PRINT);
    } else {
        // If no profile picture is found
        echo json_encode([
            'status' => 'error',
            'message' => 'No profile picture found for this patient_id.',
        ], JSON_PRETTY_PRINT);
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid request method.',
    ], JSON_PRETTY_PRINT);
}
?>
