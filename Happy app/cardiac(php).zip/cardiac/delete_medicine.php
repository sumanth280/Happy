<?php
include 'con.php'; // Include your database connection file

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect the input data
    $medicine_id = $_POST['medicine_id'];
    $patient_id = $_POST['patient_id'];

    // Prepare the SQL statement to delete the medicine record
    $sql = "DELETE FROM medication WHERE medicine_id = ? AND patient_id = ?";
    $stmt = $conn->prepare($sql);

    // Check if the SQL was prepared correctly
    if ($stmt === false) {
        echo json_encode([
            'status' => false,  // Set status to false in case of SQL preparation error
            'message' => 'Error in SQL preparation: ' . $conn->error
        ], JSON_PRETTY_PRINT);
        exit;
    }

    // Bind parameters
    $stmt->bind_param("ss", $medicine_id, $patient_id);

    // Execute the statement
    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            echo json_encode([
                'status' => true,  // Set status to true if the record is deleted successfully
                'message' => 'Record deleted successfully'
            ], JSON_PRETTY_PRINT);
        } else {
            echo json_encode([
                'status' => false,  // Set status to false if no record is found to delete
                'message' => 'No record found to delete'
            ], JSON_PRETTY_PRINT);
        }
    } else {
        echo json_encode([
            'status' => false,  // Set status to false if the deletion fails
            'message' => 'Failed to delete record: ' . $stmt->error
        ], JSON_PRETTY_PRINT);
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo json_encode([
        'status' => false,  // Set status to false for invalid request method
        'message' => 'Invalid request method'
    ], JSON_PRETTY_PRINT);
}
?>
