<?php
include 'con.php'; // Include your database connection file

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect the five required details from the POST request
    $name = $_POST['name'] ?? null;
    $age = $_POST['age'] ?? null; // Expected format: YYYY-MM-DD
    $gender = $_POST['gender'] ?? null;
    $phone_number_1 = $_POST['phone_number_1'] ?? null;
    $profession = $_POST['profession'] ?? null;

    // Validate required fields
    if (!$name || !$age || !$gender || !$phone_number_1 || !$profession) {
        echo json_encode([
            'status' => false, // Set to false in case of missing required fields
            'message' => 'Please fill in all required fields.'
        ]);
        exit;
    }

    // Generate the patient ID based on the current timestamp in yymmddhhmi format
    $patient_id = date('ymdHi');

    // Prepare the SQL statement with profile_pic set to 0
    $sql = "INSERT INTO addpatient (patient_id, name, age, gender, phone_number_1, profession, profile_pic) 
            VALUES (?, ?, ?, ?, ?, ?, ?)";

    // Debug: Check if the SQL statement was prepared successfully
    if (!$stmt = $conn->prepare($sql)) {
        echo json_encode([
            'status' => false, // Set to false in case of SQL preparation error
            'message' => 'SQL prepare error: ' . $conn->error,
        ]);
        exit;
    }

    // Bind parameters to the SQL statement, adding profile_pic = 0
    $profile_pic = 0; // Set profile_pic to 0
    $stmt->bind_param("sssssss", $patient_id, $name, $age, $gender, $phone_number_1, $profession, $profile_pic);

    // Execute the statement and check for errors
    if ($stmt->execute()) {
        echo json_encode([
            'status' => true, // Set to true if the patient ID is created successfully
            'message' => 'Patient ID created successfully',
            'patient_id' => $patient_id,
        ], JSON_PRETTY_PRINT);
    } else {
        echo json_encode([
            'status' => false, // Set to false in case of execution error
            'message' => 'Execution error: ' . $stmt->error,
        ], JSON_PRETTY_PRINT);
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo json_encode([
        'status' => false, // Set to false in case of invalid request method
        'message' => 'Invalid request method.',
    ], JSON_PRETTY_PRINT);
}
?>
